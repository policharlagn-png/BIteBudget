#!/bin/bash
# Double-click this file to launch BiteBudget (macOS)
# First time: right-click → Open to allow permissions

cd "$(dirname "$0")"

clear
echo ""
echo "  BiteBudget — Starting up..."
echo "================================"

# Check Node
if ! command -v node &> /dev/null; then
  echo ""
  echo "  Node.js not found."
  echo "  Install it from: https://nodejs.org"
  echo ""
  read -p "Press Enter to exit..."
  exit 1
fi
echo "  Node $(node -v) found"

# Kill ports
lsof -ti:3001 | xargs kill -9 2>/dev/null || true
lsof -ti:5173 | xargs kill -9 2>/dev/null || true
sleep 1

# Install + start backend
echo "  Installing backend dependencies..."
cd backend && npm install --silent 2>/dev/null

echo "  Starting backend server..."
if ./node_modules/.bin/nodemon --version &>/dev/null 2>&1; then
  node_modules/.bin/nodemon server.js &
else
  node server.js &
fi
BACKEND_PID=$!
cd ..

# Wait for backend health check
echo "  Waiting for backend..."
MAX_WAIT=20
COUNT=0
until curl -sf http://localhost:3001/api/health > /dev/null 2>&1; do
  sleep 1
  COUNT=$((COUNT+1))
  if [ $COUNT -ge $MAX_WAIT ]; then
    echo ""
    echo "  ERROR: Backend did not start. Check terminal output above."
    kill $BACKEND_PID 2>/dev/null || true
    read -p "Press Enter to exit..."
    exit 1
  fi
done
echo "  Backend ready."

# Install + start frontend
echo "  Installing frontend dependencies..."
cd frontend && npm install --silent 2>/dev/null

echo ""
echo "================================"
echo "  Open your browser and go to:"
echo ""
echo "      http://localhost:5173"
echo ""
echo "  Close this window to stop the app."
echo "================================"
echo ""

# Auto-open browser
if command -v open &>/dev/null; then
  sleep 2 && open http://localhost:5173 &
elif command -v xdg-open &>/dev/null; then
  sleep 2 && xdg-open http://localhost:5173 &
fi

npm run dev

trap "kill $BACKEND_PID 2>/dev/null; exit" EXIT INT TERM
