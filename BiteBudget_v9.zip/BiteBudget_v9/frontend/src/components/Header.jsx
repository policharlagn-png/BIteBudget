// src/components/Header.jsx
import React from 'react'

export default function Header() {
  return (
    <header className="bb-header">
      <div className="bb-logo">
        <span className="bb-logo-text">BiteBudget</span>
        <span style={{ fontSize:11, color:'var(--sage)', marginLeft:10, fontWeight:400, letterSpacing:'.3px', alignSelf:'flex-end', paddingBottom:3 }}>
          USA Grocery Intelligence
        </span>
      </div>
    </header>
  )
}
