// src/components/GoalsPanel.jsx
import React, { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { generateMealPlan } from '../utils/api.js'

const GOAL_OPTIONS = [
  { id:'muscle',   label:'Build Muscle',         desc:'High protein intake with a caloric surplus' },
  { id:'lose',     label:'Lose Weight',           desc:'Caloric deficit with maintained protein' },
  { id:'maintain', label:'Maintain Weight',       desc:'Balanced intake at your maintenance level' },
  { id:'athletic', label:'Athletic Performance',  desc:'Carbohydrate-forward diet for energy and endurance' },
  { id:'health',   label:'General Health',        desc:'Whole foods focus with balanced micronutrients' },
]

const ACTIVITY = [
  { id:'sedentary', label:'Sedentary',          desc:'Desk job, minimal movement outside of work', mult:1.2   },
  { id:'light',     label:'Lightly Active',     desc:'Light exercise 1 to 3 days per week',         mult:1.375 },
  { id:'moderate',  label:'Moderately Active',  desc:'Moderate exercise 3 to 5 days per week',      mult:1.55  },
  { id:'very',      label:'Very Active',        desc:'Hard training 6 to 7 days per week',           mult:1.725 },
  { id:'extra',     label:'Extremely Active',   desc:'Athlete or physically demanding job daily',    mult:1.9   },
]

const DIETS = ['No Restriction','High Protein','Vegan','Vegetarian','Keto','Paleo',
               'Pescatarian','Mediterranean','Intermittent Fasting','Gluten-Free']

// Convert lbs -> kg, inches -> cm
const lbsToKg  = lbs => lbs * 0.453592
const inchesToCm = inches => inches * 2.54
const feetInchesToCm = (ft, inch) => inchesToCm(ft * 12 + (+inch || 0))

function calcBMR({ weightLbs, heightFt, heightIn, age, sex }) {
  if (!weightLbs || !heightFt || !age) return null
  const kg = lbsToKg(weightLbs)
  const cm = feetInchesToCm(heightFt, heightIn)
  const base = 10 * kg + 6.25 * cm - 5 * age
  return Math.round(sex === 'female' ? base - 161 : base + 5)
}

function calcMacros(cals, goal) {
  if (goal === 'muscle')   return { protein: Math.round(cals*0.30/4), carbs: Math.round(cals*0.45/4), fat: Math.round(cals*0.25/9) }
  if (goal === 'lose')     return { protein: Math.round(cals*0.35/4), carbs: Math.round(cals*0.35/4), fat: Math.round(cals*0.30/9) }
  if (goal === 'athletic') return { protein: Math.round(cals*0.25/4), carbs: Math.round(cals*0.50/4), fat: Math.round(cals*0.25/9) }
  return                          { protein: Math.round(cals*0.25/4), carbs: Math.round(cals*0.45/4), fat: Math.round(cals*0.30/9) }
}

// ── MealPlanFull ─────────────────────────────────────────────────────
function MealPlanFull({ mealPlan, onRegenerate, loading }) {
  const [activeDay, setActiveDay] = useState(0)

  const day      = mealPlan.days?.[activeDay]
  const dayTotal = day ? (day.breakfast?.calories||0)+(day.lunch?.calories||0)+(day.dinner?.calories||0) : 0
  const dayCost  = day ? ((day.breakfast?.cost||0)+(day.lunch?.cost||0)+(day.dinner?.cost||0)).toFixed(2) : '0.00'
  const target   = mealPlan.calorieTarget || 2000
  const pct      = Math.min(100, Math.round((dayTotal / target) * 100))

  const MEALS = [
    { key:'breakfast', label:'Breakfast' },
    { key:'lunch',     label:'Lunch'     },
    { key:'dinner',    label:'Dinner'    },
  ]

  return (
    <div className="bb-card" style={{ padding:0, overflow:'hidden' }}>
      {/* Header */}
      <div style={{ background:'linear-gradient(135deg, var(--forest-deep), var(--forest))', padding:'16px 20px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <h3 style={{ fontFamily:"'Fraunces',serif", fontWeight:700, color:'white', fontSize:18 }}>7-Day Meal Plan</h3>
          <p style={{ fontSize:12, color:'rgba(255,255,255,.75)', marginTop:2 }}>
            Est. weekly cost: <strong style={{ color:'var(--mint)' }}>${mealPlan.estimatedCost}</strong>
            &nbsp; | &nbsp;
            Calorie target: <strong style={{ color:'var(--mint)' }}>{mealPlan.calorieTarget} kcal/day</strong>
          </p>
        </div>
        <button
          onClick={onRegenerate}
          disabled={loading}
          style={{ background:'rgba(255,255,255,.15)', color:'white', border:'1px solid rgba(255,255,255,.3)',
            fontSize:12, padding:'8px 16px', borderRadius:'var(--radius-sm)', cursor:'pointer',
            opacity: loading ? 0.6 : 1 }}>
          {loading ? 'Generating...' : 'Generate New Plan'}
        </button>
      </div>

      {/* Day tabs */}
      <div style={{ display:'flex', overflowX:'auto', borderBottom:'1px solid var(--border)', background:'var(--white)' }}>
        {mealPlan.days?.map((d, i) => (
          <button key={i} onClick={() => setActiveDay(i)}
            style={{ flexShrink:0, padding:'10px 18px', fontSize:13,
              fontWeight: activeDay===i ? 700 : 500,
              color: activeDay===i ? 'var(--forest-deep)' : 'var(--slate-light)',
              borderBottom: activeDay===i ? '3px solid var(--teal)' : '3px solid transparent',
              background:'none', cursor:'pointer', transition:'color .15s, border-color .15s',
              border:'none', borderBottomStyle:'solid', borderBottomWidth:3,
              borderBottomColor: activeDay===i ? 'var(--teal)' : 'transparent' }}>
            {d.day}
          </button>
        ))}
      </div>

      {/* Day content */}
      {day && (
        <div style={{ padding:'16px 20px' }} key={activeDay}>
          {/* Day stats */}
          <div style={{ display:'flex', gap:12, marginBottom:16, flexWrap:'wrap' }}>
            {[
              ['Calories', `${dayTotal} / ${target} kcal`],
              ['Protein',  `${day.totalProtein || '—'}g`],
              ['Carbs',    `${day.totalCarbs || '—'}g`],
              ['Fat',      `${day.totalFat || '—'}g`],
              ['Est. Cost',`$${dayCost}`],
            ].map(([l, v]) => (
              <div key={l} style={{ background:'var(--sage-pale)', borderRadius:'var(--radius-sm)',
                padding:'8px 14px', minWidth:90, textAlign:'center', border:'1px solid var(--border)' }}>
                <div style={{ fontSize:11, color:'var(--slate-light)', textTransform:'uppercase', letterSpacing:'.5px', marginBottom:2 }}>{l}</div>
                <div style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:14 }}>{v}</div>
              </div>
            ))}
          </div>

          {/* Calorie progress bar */}
          <div style={{ marginBottom:16 }}>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4, fontSize:12, color:'var(--slate-light)' }}>
              <span>Daily calorie target</span><span>{pct}%</span>
            </div>
            <div className="bb-progress-bar">
              <div className="bb-progress-fill" style={{ width:`${pct}%`,
                background: pct > 110 ? '#ef4444' : pct > 95 ? 'var(--teal)' : 'linear-gradient(90deg,var(--teal),var(--forest))' }} />
            </div>
          </div>

          {/* Meals */}
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {MEALS.map(({ key, label }) => {
              const meal = day[key]
              if (!meal) return null
              return (
                <div key={key} style={{ border:'1px solid var(--border)', borderRadius:'var(--radius-md)', overflow:'hidden' }}>
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
                    padding:'9px 14px', background:'var(--sage-pale)', borderBottom:'1px solid var(--border)' }}>
                    <span style={{ fontWeight:700, fontSize:12, color:'var(--forest-deep)',
                      textTransform:'uppercase', letterSpacing:'.6px' }}>{label}</span>
                    <div style={{ display:'flex', gap:14, fontSize:12, color:'var(--slate-light)' }}>
                      {meal.prepTime && <span>{meal.prepTime}</span>}
                      {meal.calories  && <span>{meal.calories} cal</span>}
                      {meal.protein   && <span>{meal.protein}g protein</span>}
                      {meal.cost != null && <span style={{ color:'var(--teal-dark)', fontWeight:600 }}>${typeof meal.cost === 'number' ? meal.cost.toFixed(2) : meal.cost}</span>}
                    </div>
                  </div>
                  <div style={{ padding:'12px 14px' }}>
                    <p style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15, marginBottom:8 }}>{meal.name}</p>
                    {meal.ingredients?.length > 0 && (
                      <div style={{ display:'flex', flexWrap:'wrap', gap:5 }}>
                        {meal.ingredients.map((ing, ii) => (
                          <span key={ii} style={{ background:'var(--sage-pale)', color:'var(--slate)',
                            fontSize:12, padding:'3px 10px', borderRadius:99, border:'1px solid var(--border)' }}>
                            {ing}
                          </span>
                        ))}
                      </div>
                    )}
                    {(meal.carbs || meal.fat) && (
                      <div style={{ display:'flex', gap:12, marginTop:8, fontSize:12, color:'var(--slate-light)' }}>
                        {meal.carbs && <span>Carbs: {meal.carbs}g</span>}
                        {meal.fat   && <span>Fat: {meal.fat}g</span>}
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Day nav */}
          <div style={{ display:'flex', justifyContent:'space-between', marginTop:14 }}>
            <button className="bb-btn bb-btn--soft" onClick={() => setActiveDay(d => Math.max(0, d-1))}
              disabled={activeDay===0} style={{ fontSize:13, padding:'8px 16px' }}>Previous day</button>
            <button className="bb-btn bb-btn--soft" onClick={() => setActiveDay(d => Math.min((mealPlan.days?.length||1)-1, d+1))}
              disabled={activeDay===(mealPlan.days?.length||1)-1} style={{ fontSize:13, padding:'8px 16px' }}>Next day</button>
          </div>
        </div>
      )}

      {/* Shopping list */}
      {mealPlan.shoppingList?.length > 0 && (
        <div style={{ borderTop:'1px solid var(--border)', padding:'16px 20px' }}>
          <h4 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:12, fontSize:14 }}>Weekly Shopping List</h4>
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {mealPlan.shoppingList.map((item, i) => (
              <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                fontSize:13, padding:'5px 0', borderBottom:'1px solid var(--border)' }}>
                <div>
                  <span style={{ fontWeight:500, color:'var(--slate)' }}>{item.item}</span>
                  <span style={{ color:'var(--slate-light)', marginLeft:10, fontSize:12 }}>{item.quantity}</span>
                  {item.store && item.store !== 'Any' && (
                    <span style={{ marginLeft:10, fontSize:11, color:'var(--teal-dark)', background:'var(--sage-pale)',
                      padding:'2px 8px', borderRadius:99, border:'1px solid var(--border)' }}>{item.store}</span>
                  )}
                </div>
                <span style={{ fontWeight:700, color:'var(--forest)' }}>${item.estimatedCost?.toFixed(2)}</span>
              </div>
            ))}
            <div style={{ display:'flex', justifyContent:'space-between', fontWeight:700, fontSize:14,
              paddingTop:8, marginTop:2 }}>
              <span style={{ color:'var(--forest-deep)' }}>Estimated Total</span>
              <span style={{ color:'var(--forest)' }}>${mealPlan.estimatedCost}</span>
            </div>
          </div>
        </div>
      )}


    </div>
  )
}

// ── Main GoalsPanel ──────────────────────────────────────────────────
export default function GoalsPanel({ goals, setGoals }) {
  const [step, setStep]     = useState(goals ? 3 : 0)
  const [profile, setProfile] = useState(goals?.profile || {
    weightLbs:'', heightFt:'', heightIn:'0', age:'', sex:'male'
  })
  const [goal, setGoal]     = useState(goals?.goal || '')
  const [activity, setActivity] = useState(goals?.activity || 'moderate')
  const [diet, setDiet]     = useState(goals?.diet || 'No Restriction')
  const [mealPlan, setMealPlan] = useState(goals?.mealPlan || null)
  const [budget, setBudget] = useState(goals?.budget || 75)

  const bmr      = calcBMR(profile)
  const actMult  = ACTIVITY.find(a => a.id === activity)?.mult || 1.55
  const tdee     = bmr ? Math.round(bmr * actMult) : null
  const caloDelta = goal === 'muscle' ? 300 : goal === 'lose' ? -400 : 0
  const caloTarget = tdee ? tdee + caloDelta : null
  const macros   = caloTarget ? calcMacros(caloTarget, goal) : null

  const { mutate: genPlan, isPending } = useMutation({
    mutationFn: () => {
      const goalsPayload = goal ? {
        goal, activity,
        tdee,
        calorieTarget: caloTarget,
        macros,
        diet,
      } : null

      return generateMealPlan({
        budget,
        householdSize: 1,
        dietaryRestrictions: diet !== 'No Restriction' ? [diet] : [],
        goals: goalsPayload,
        seed: Date.now(),   // always new plan
      })
    },
    onSuccess: (data) => {
      setMealPlan(data)
      if (goal) {
        setGoals({ profile, goal, activity, diet, budget, mealPlan: data, tdee, calorieTarget: caloTarget, macros })
      }
      setStep(3)
    },
  })

  const MacroBar = ({ label, g, kcal, color }) => (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
        <span className="bb-label" style={{ marginBottom:0 }}>{label}</span>
        <span style={{ fontSize:13, fontWeight:600, color:'var(--forest)' }}>
          {g}g <span style={{ color:'var(--slate-light)', fontWeight:400 }}>({kcal} kcal)</span>
        </span>
      </div>
      <div className="bb-progress-bar">
        <div className="bb-progress-fill" style={{ width:`${Math.min(100,(g/300)*100)}%`, background:color }} />
      </div>
    </div>
  )

  // ── Step 0: Body stats ──────────────────────────────────────────
  if (step === 0) return (
    <div className="bb-page fade-up">
      <div style={{ marginBottom:28 }}>
        <h1 className="bb-section-title" style={{ fontSize:26 }}>My Personal Goals — Build Your Profile</h1>
        <p className="bb-section-sub">Enter your stats to get a personalized calorie target, macro split, and meal plan tailored to your body and goals.</p>
      </div>

      <div className="bb-card" style={{ marginBottom:20 }}>
        <h2 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:16, marginBottom:16 }}>Body Measurements</h2>
        <div className="bb-grid-2" style={{ gap:14 }}>
          <div>
            <label className="bb-label">Weight (lbs)</label>
            <input className="bb-input" type="number" placeholder="e.g. 165"
              value={profile.weightLbs}
              onFocus={e => { if (+e.target.value === 0) setProfile(p => ({...p, weightLbs:''})) }}
              onBlur={e => { if (e.target.value === '') setProfile(p => ({...p, weightLbs:0})) }}
              onChange={e => setProfile(p => ({...p, weightLbs:e.target.value === '' ? '' : +e.target.value}))} />
          </div>
          <div>
            <label className="bb-label">Height</label>
            <div style={{ display:'flex', gap:8 }}>
              <input className="bb-input" type="number" placeholder="ft" style={{ width:'45%' }}
                value={profile.heightFt}
                onFocus={e => { if (+e.target.value === 0) setProfile(p => ({...p, heightFt:''})) }}
                onBlur={e => { if (e.target.value === '') setProfile(p => ({...p, heightFt:0})) }}
                onChange={e => setProfile(p => ({...p, heightFt:e.target.value === '' ? '' : +e.target.value}))} />
              <input className="bb-input" type="number" placeholder="in" min={0} max={11} style={{ width:'45%' }}
                value={profile.heightIn}
                onFocus={e => { if (+e.target.value === 0) setProfile(p => ({...p, heightIn:''})) }}
                onBlur={e => { if (e.target.value === '') setProfile(p => ({...p, heightIn:0})) }}
                onChange={e => setProfile(p => ({...p, heightIn:e.target.value === '' ? '' : +e.target.value}))} />
            </div>
          </div>
          <div>
            <label className="bb-label">Age</label>
            <input className="bb-input" type="number" placeholder="e.g. 28"
              value={profile.age}
              onFocus={e => { if (+e.target.value === 0) setProfile(p => ({...p, age:''})) }}
              onBlur={e => { if (e.target.value === '') setProfile(p => ({...p, age:0})) }}
              onChange={e => setProfile(p => ({...p, age:e.target.value === '' ? '' : +e.target.value}))} />
          </div>
          <div>
            <label className="bb-label">Sex</label>
            <select className="bb-select" value={profile.sex} onChange={e => setProfile(p => ({...p, sex:e.target.value}))}>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>
        </div>

        {bmr && (
          <div style={{ marginTop:16, padding:'12px 16px', background:'var(--sage-pale)',
            borderRadius:'var(--radius-sm)', display:'flex', gap:24, flexWrap:'wrap', borderLeft:'3px solid var(--teal)' }}>
            <div>
              <div style={{ fontSize:11, color:'var(--slate-light)', textTransform:'uppercase', letterSpacing:'.5px' }}>BMR</div>
              <div style={{ fontWeight:800, color:'var(--forest)', fontSize:22 }}>{bmr} kcal</div>
              <div style={{ fontSize:11, color:'var(--slate-light)' }}>at complete rest</div>
            </div>
            {tdee && (
              <div>
                <div style={{ fontSize:11, color:'var(--slate-light)', textTransform:'uppercase', letterSpacing:'.5px' }}>TDEE</div>
                <div style={{ fontWeight:800, color:'var(--forest)', fontSize:22 }}>{tdee} kcal</div>
                <div style={{ fontSize:11, color:'var(--slate-light)' }}>with activity ({ACTIVITY.find(a=>a.id===activity)?.label})</div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="bb-card" style={{ marginBottom:20 }}>
        <h2 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:16, marginBottom:14 }}>Activity Level</h2>
        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          {ACTIVITY.map(a => (
            <button key={a.id} onClick={() => setActivity(a.id)}
              style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'11px 14px',
                borderRadius:'var(--radius-sm)', border:`1.5px solid ${activity===a.id ? 'var(--teal)' : 'var(--border)'}`,
                background: activity===a.id ? 'var(--sage-pale)' : 'var(--white)', cursor:'pointer',
                transition:'all .15s', textAlign:'left' }}>
              <div>
                <div style={{ fontWeight:600, color:'var(--forest-deep)', fontSize:13 }}>{a.label}</div>
                <div style={{ fontSize:12, color:'var(--slate-light)' }}>{a.desc}</div>
              </div>
              {activity===a.id && <span style={{ color:'var(--teal)', fontWeight:700, fontSize:16 }}></span>}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display:'flex', gap:10 }}>
        <button className="bb-btn bb-btn--primary" style={{ flex:1, padding:'13px' }}
          onClick={() => setStep(1)}
          disabled={!profile.weightLbs || !profile.heightFt || !profile.age}>
          Continue to Goals
        </button>
      </div>
    </div>
  )

  // ── Step 1: Goal + Diet ─────────────────────────────────────────
  if (step === 1) return (
    <div className="bb-page fade-up">
      <div style={{ marginBottom:24 }}>
        <h1 className="bb-section-title" style={{ fontSize:26 }}>Set Your Goal</h1>
        <p className="bb-section-sub">Your goal determines your calorie target and how your macros are split across protein, carbs, and fat.</p>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:24 }}>
        {GOAL_OPTIONS.map(g => (
          <button key={g.id} onClick={() => setGoal(g.id)}
            style={{ display:'flex', alignItems:'center', gap:16, padding:'14px 18px',
              borderRadius:'var(--radius-md)', border:`2px solid ${goal===g.id ? 'var(--teal)' : 'var(--border)'}`,
              background: goal===g.id ? 'var(--sage-pale)' : 'var(--white)',
              cursor:'pointer', transition:'all .15s', textAlign:'left',
              boxShadow: goal===g.id ? 'var(--shadow-md)' : 'none' }}>
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15 }}>{g.label}</div>
              <div style={{ fontSize:13, color:'var(--slate-light)' }}>{g.desc}</div>
            </div>
            {goal===g.id && <span style={{ color:'var(--teal)', fontWeight:700, fontSize:18 }}></span>}
          </button>
        ))}
      </div>

      <div className="bb-card" style={{ marginBottom:24 }}>
        <h3 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15, marginBottom:12 }}>Diet Preference</h3>
        <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
          {DIETS.map(d => (
            <button key={d} className={`bb-pill ${diet===d ? 'active' : ''}`} onClick={() => setDiet(d)}>{d}</button>
          ))}
        </div>
      </div>

      <div style={{ display:'flex', gap:10 }}>
        <button className="bb-btn bb-btn--soft" onClick={() => setStep(0)} style={{ flex:1 }}>Back</button>
        <button className="bb-btn bb-btn--primary" onClick={() => setStep(2)} disabled={!goal} style={{ flex:2, padding:'13px' }}>
          Continue
        </button>
      </div>
    </div>
  )

  // ── Step 2: Budget + Preview + Generate ─────────────────────────
  if (step === 2) return (
    <div className="bb-page fade-up">
      <div style={{ marginBottom:24 }}>
        <h1 className="bb-section-title" style={{ fontSize:26 }}>
          {goal ? 'Your Targets' : 'Budget-Based Meal Plan'}
        </h1>
        <p className="bb-section-sub">
          {goal
            ? 'These targets are calculated from your body stats, activity level, and goal.'
            : 'No profile entered. Set a weekly grocery budget and we will build a nutritious plan around it.'}
        </p>
      </div>

      {/* Calorie target card */}
      {caloTarget && macros && (
        <>
          <div className="bb-card bb-card--green" style={{ marginBottom:16 }}>
            <div style={{ fontSize:12, opacity:.75, textTransform:'uppercase', letterSpacing:'.5px', marginBottom:4 }}>Daily Calorie Target</div>
            <div style={{ fontFamily:"'Fraunces',serif", fontSize:52, fontWeight:900, lineHeight:1 }}>{caloTarget}</div>
            <div style={{ fontSize:13, opacity:.7, marginTop:4 }}>kcal / day &nbsp;|&nbsp; {GOAL_OPTIONS.find(g=>g.id===goal)?.label}</div>
          </div>

          <div className="bb-card" style={{ marginBottom:16 }}>
            <h3 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15, marginBottom:16 }}>Daily Macro Targets</h3>
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              <MacroBar label="Protein"       g={macros.protein} kcal={macros.protein*4} color="linear-gradient(90deg,#52b788,#2d6a4f)" />
              <MacroBar label="Carbohydrates" g={macros.carbs}   kcal={macros.carbs*4}   color="linear-gradient(90deg,#fbbf24,#d97706)" />
              <MacroBar label="Fat"           g={macros.fat}     kcal={macros.fat*9}     color="linear-gradient(90deg,#a78bfa,#7c3aed)" />
            </div>
          </div>
        </>
      )}

      {/* Budget input */}
      <div className="bb-card" style={{ marginBottom:24 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
          <h3 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15 }}>Weekly Grocery Budget</h3>
          <span style={{ fontFamily:"'Fraunces',serif", fontSize:28, fontWeight:900, color:'var(--forest)' }}>${budget}</span>
        </div>
        <input type="range" min={25} max={250} step={5} value={budget}
          onChange={e => setBudget(+e.target.value)} style={{ width:'100%' }} />
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:12, color:'var(--slate-light)', marginTop:4 }}>
          <span>$25</span><span>$250</span>
        </div>
      </div>

      <div style={{ display:'flex', gap:10 }}>
        <button className="bb-btn bb-btn--soft" onClick={() => setStep(goal ? 1 : 0)} style={{ flex:1 }}>Back</button>
        <button className="bb-btn bb-btn--primary" style={{ flex:2, padding:'14px' }}
          onClick={() => genPlan()} disabled={isPending}>
          {isPending ? 'Generating plan...' : 'Generate My Meal Plan'}
        </button>
      </div>
    </div>
  )

  // ── Step 3: Dashboard ───────────────────────────────────────────
  const saved    = goals || {}
  const savedBMR = calcBMR(saved.profile || {})
  const savedMult = ACTIVITY.find(a => a.id === saved.activity)?.mult || 1.55
  const savedTDEE = savedBMR ? Math.round(savedBMR * savedMult) : null
  const savedCaloDelta = saved.goal === 'muscle' ? 300 : saved.goal === 'lose' ? -400 : 0
  const savedCalo = savedTDEE ? savedTDEE + savedCaloDelta : null
  const savedMacros = savedCalo ? calcMacros(savedCalo, saved.goal) : null

  const topFoods = {
    muscle:   ['Chicken breast','Greek yogurt','Eggs','Cottage cheese','Lentils','Canned tuna','Quinoa','Edamame'],
    lose:     ['Spinach','Broccoli','Cauliflower','Cucumber','Ground turkey','Blueberries','Oats','Celery'],
    maintain: ['Brown rice','Sweet potato','Salmon','Avocado','Almonds','Black beans','Oats','Bananas'],
    athletic: ['Oats','Bananas','Brown rice','Pasta','Chicken breast','Beets','Sweet potato','Dates'],
    health:   ['Kale','Blueberries','Salmon','Walnuts','Olive oil','Canned tomatoes','Garlic','Lentils'],
  }

  return (
    <div className="bb-page fade-up">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:24, flexWrap:'wrap', gap:12 }}>
        <div>
          <h1 className="bb-section-title" style={{ fontSize:26 }}>Your Dashboard</h1>
          <p className="bb-section-sub" style={{ marginBottom:0 }}>
            {saved.goal ? GOAL_OPTIONS.find(g=>g.id===saved.goal)?.label : 'Budget-Based Plan'}
            {saved.diet && saved.diet !== 'No Restriction' ? ` · ${saved.diet}` : ''}
            {saved.budget ? ` · $${saved.budget}/week` : ''}
          </p>
        </div>
        <button className="bb-btn bb-btn--soft" onClick={() => setStep(0)} style={{ fontSize:13 }}>Edit Profile</button>
      </div>

      {/* Stats summary */}
      {savedCalo && savedMacros && (
        <>
          <div className="bb-card bb-card--green" style={{ marginBottom:16, display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:16 }}>
            <div>
              <div style={{ fontSize:11, opacity:.75, textTransform:'uppercase', letterSpacing:'.5px' }}>Daily Calorie Target</div>
              <div style={{ fontFamily:"'Fraunces',serif", fontSize:52, fontWeight:900, lineHeight:1 }}>{savedCalo}</div>
              <div style={{ fontSize:12, opacity:.7, marginTop:4 }}>kcal / day</div>
            </div>
            <div style={{ display:'flex', gap:20, flexWrap:'wrap' }}>
              {savedBMR && <div style={{ textAlign:'center' }}>
                <div style={{ fontSize:11, opacity:.7, textTransform:'uppercase' }}>BMR</div>
                <div style={{ fontSize:22, fontWeight:700 }}>{savedBMR}</div>
                <div style={{ fontSize:11, opacity:.6 }}>kcal</div>
              </div>}
              {savedTDEE && <div style={{ textAlign:'center' }}>
                <div style={{ fontSize:11, opacity:.7, textTransform:'uppercase' }}>TDEE</div>
                <div style={{ fontSize:22, fontWeight:700 }}>{savedTDEE}</div>
                <div style={{ fontSize:11, opacity:.6 }}>kcal</div>
              </div>}
            </div>
          </div>

          <div className="bb-card" style={{ marginBottom:16 }}>
            <h3 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15, marginBottom:16 }}>Daily Macro Targets</h3>
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              <MacroBar label="Protein"       g={savedMacros.protein} kcal={savedMacros.protein*4} color="linear-gradient(90deg,#52b788,#2d6a4f)" />
              <MacroBar label="Carbohydrates" g={savedMacros.carbs}   kcal={savedMacros.carbs*4}   color="linear-gradient(90deg,#fbbf24,#d97706)" />
              <MacroBar label="Fat"           g={savedMacros.fat}     kcal={savedMacros.fat*9}     color="linear-gradient(90deg,#a78bfa,#7c3aed)" />
            </div>
          </div>
        </>
      )}

      {/* Recommended foods */}
      {saved.goal && (
        <div className="bb-card" style={{ marginBottom:16 }}>
          <h3 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15, marginBottom:12 }}>Best Foods for Your Goal</h3>
          <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
            {(topFoods[saved.goal] || topFoods.health).map(f => (
              <span key={f} style={{ background:'var(--sage-pale)', color:'var(--forest)', padding:'6px 14px',
                borderRadius:99, fontSize:13, fontWeight:500, border:'1px solid var(--border)' }}>{f}</span>
            ))}
          </div>
        </div>
      )}

      {/* Full meal plan */}
      {mealPlan
        ? <MealPlanFull mealPlan={mealPlan} loading={isPending} onRegenerate={() => genPlan()} />
        : (
          <div className="bb-card" style={{ textAlign:'center', padding:'32px 24px' }}>
            <p style={{ color:'var(--slate-light)', marginBottom:16, fontSize:14 }}>No meal plan generated yet.</p>
            <button className="bb-btn bb-btn--primary" onClick={() => setStep(2)} style={{ margin:'0 auto' }}>
              Generate Meal Plan
            </button>
          </div>
        )
      }
    </div>
  )
}
