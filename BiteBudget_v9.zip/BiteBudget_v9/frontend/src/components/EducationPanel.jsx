// src/components/EducationPanel.jsx
import React, { useState } from 'react'

// SVG icon components
const Icon = ({ d, color = 'currentColor', size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
)

const TOPIC_ICONS = {
  macros:     <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M12 2v10l4 4"/></svg>,
  micros:     <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2l3 7h7l-6 4 2 7-6-4-6 4 2-7-6-4h7z"/></svg>,
  protein:    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 4v16M18 4v16M6 12h12M4 8h4M16 8h4M4 16h4M16 16h4"/></svg>,
  weightloss: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/><path d="M8 12l3 3 5-5"/></svg>,
  diets:      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M3 12h18M3 18h18"/></svg>,
  energy:     <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>,
}

const TOPICS = [
  { id: 'macros',     label: 'Macronutrients'       },
  { id: 'micros',     label: 'Micronutrients'        },
  { id: 'protein',    label: 'Protein Deep Dive'     },
  { id: 'weightloss', label: 'Weight Loss 101'       },
  { id: 'diets',      label: 'Diet Guides'           },
  { id: 'energy',     label: 'Energy & Performance'  },
]

const DIETS_DATA = [
 { name:'High Protein', icon:'', best:'Building muscle, satiety, body recomposition',
 foods:['Chicken breast','Eggs','Greek yogurt','Cottage cheese','Lentils','Tuna','Tofu'],
 avoid:['Sugary drinks','White bread','Candy','Pastries'],
 tip:'Aim for 0.7–1g of protein per pound of bodyweight daily.' },
 { name:'Vegan', icon:'', best:'Heart health, environmental sustainability, weight loss',
 foods:['Legumes','Tofu','Tempeh','Nuts','Seeds','Whole grains','Fruits & vegetables'],
 avoid:['All animal products — meat, dairy, eggs, honey'],
 tip:'Supplement B12, Vitamin D, and Omega-3 (algae-based). Track iron intake.' },
 { name:'Pescatarian', icon:'', best:'Heart health, balanced omega-3s with plant-based flexibility',
 foods:['Fish','Shellfish','Eggs','Dairy','Legumes','Vegetables','Whole grains'],
 avoid:['Red meat','Poultry'],
 tip:'Fatty fish like salmon and sardines are the best omega-3 sources in any diet.' },
 { name:'Keto', icon:'', best:'Rapid fat loss, blood sugar control, mental clarity',
 foods:['Meat','Fish','Eggs','Cheese','Avocado','Nuts','Non-starchy vegetables'],
 avoid:['Bread','Pasta','Rice','Sugar','Most fruits','Legumes'],
 tip:'Keep carbs under 25g/day. Electrolytes (sodium, potassium, magnesium) are critical.' },
 { name:'Mediterranean', icon:'', best:'Longevity, heart health, cognitive function',
 foods:['Olive oil','Fish','Whole grains','Legumes','Nuts','Fruits & vegetables','Moderate wine'],
 avoid:['Processed meats','Added sugars','Refined grains','Processed oils'],
 tip:'Widely considered the most evidence-backed diet for overall long-term health.' },
 { name:'Intermittent Fasting', icon:'⏰', best:'Weight loss, insulin sensitivity, cellular repair (autophagy)',
 foods:['Eat anything — timing is the focus','Lean proteins during eating window','Plenty of water/coffee/tea during fast'],
 avoid:['Calories during fasting window','Sugary drinks that spike insulin'],
 tip:'16:8 (eat 8 hours, fast 16) is the most popular protocol. Start with 14:10.' },
 { name:'Paleo', icon:'', best:'Reducing inflammation, blood sugar stability, gut health',
 foods:['Meat','Fish','Eggs','Vegetables','Fruits','Nuts','Seeds','Tubers'],
 avoid:['Grains','Legumes','Dairy','Processed foods','Sugar','Vegetable oils'],
 tip:'Focus on food quality — grass-fed, wild-caught, and organic where possible.' },
]

const MACROS_DATA = [
 { name:'Protein', kcalPerG:4, icon:'', color:'#2d6a4f', desc:'Builds and repairs muscle tissue, enzymes, hormones, and immune cells.',
 sources:['Chicken breast (31g/100g)','Eggs (13g each)','Greek yogurt (10g/100g)','Lentils (9g/100g)','Tuna (25g/100g)','Black beans (8g/100g)'],
 forGoals:{ muscle:'1.6–2.2g per kg bodyweight', lose:'1.2–1.6g per kg to preserve muscle', maintain:'0.8–1.2g per kg', athletic:'1.4–1.7g per kg' } },
 { name:'Carbohydrates', kcalPerG:4, icon:'', color:'#d97706', desc:'Primary energy source for brain and muscles. Complex carbs provide sustained energy; simple carbs provide quick fuel.',
 sources:['Brown rice (45g/100g)','Oats (66g/100g)','Sweet potato (20g/100g)','Bananas (23g each)','Beans (22g/100g)','Whole wheat bread (43g/100g)'],
 forGoals:{ muscle:'45–55% of calories for recovery', lose:'30–40% of calories, focus on fiber', maintain:'45–55% of calories', athletic:'55–65% — carbs fuel performance' } },
 { name:'Fat', kcalPerG:9, icon:'', color:'#7c3aed', desc:'Essential for hormone production, brain health, fat-soluble vitamin absorption (A, D, E, K), and sustained energy.',
 sources:['Avocado (15g/100g)','Olive oil (100g/100g)','Almonds (49g/100g)','Salmon (13g/100g)','Egg yolks (9g each)','Chia seeds (31g/100g)'],
 forGoals:{ muscle:'20–30% of calories', lose:'30–40% of calories (very satiating)', maintain:'25–35% of calories', athletic:'20–30% of calories' } },
]

const MICROS_DATA = [
 { name:'Vitamin C', role:'Immune system, collagen synthesis, iron absorption', sources:'Bell peppers, citrus, strawberries, broccoli', deficiency:'Fatigue, weakened immunity, poor wound healing' },
 { name:'Iron', role:'Oxygen transport in red blood cells, energy production', sources:'Red meat, spinach, lentils, pumpkin seeds', deficiency:'Anemia, fatigue, weakness, pale skin' },
 { name:'Vitamin D', role:'Bone health, immune function, mood regulation', sources:'Sunlight, salmon, egg yolks, fortified milk', deficiency:'Weak bones, depression, immune issues, fatigue' },
 { name:'Magnesium', role:'Muscle function, sleep quality, 300+ enzyme reactions', sources:'Dark chocolate, almonds, spinach, black beans', deficiency:'Muscle cramps, insomnia, anxiety, constipation' },
 { name:'Zinc', role:'Testosterone production, immune defense, wound healing', sources:'Oysters, beef, pumpkin seeds, chickpeas', deficiency:'Poor immunity, slow healing, low testosterone' },
 { name:'B12', role:'Nerve function, red blood cell formation, DNA synthesis', sources:'Meat, fish, dairy, eggs (vegans must supplement)', deficiency:'Nerve damage, fatigue, anemia, memory issues' },
 { name:'Potassium', role:'Heart rhythm, blood pressure, muscle contractions', sources:'Bananas, sweet potatoes, avocado, salmon', deficiency:'Muscle weakness, cramps, irregular heartbeat' },
 { name:'Omega-3', role:'Brain health, inflammation reduction, heart health', sources:'Salmon, sardines, walnuts, chia seeds, flaxseed', deficiency:'Inflammation, depression, poor cognition' },
]

export default function EducationPanel({ goals }) {
 const [topic, setTopic] = useState('macros')
 const [selectedDiet, setSelectedDiet] = useState(null)
 const [selectedMacro, setSelectedMacro] = useState(null)
 const userGoal = goals?.goal

 return (
 <div style={{ height:'calc(100vh - 64px)', display:'flex', overflow:'hidden' }}>
 {/* Sidebar */}
 <div style={{ width:210, borderRight:'1px solid var(--border)', background:'var(--white)', overflowY:'auto', flexShrink:0 }}>
 <div style={{ padding:'16px 14px 12px', borderBottom:'1px solid var(--border)' }}>
 <div style={{ fontFamily:"'Sora',sans-serif", fontWeight:800, fontSize:15, color:'var(--forest-deep)' }}>Learn</div>
 <div style={{ fontSize:11, color:'var(--slate-light)', marginTop:2 }}>Nutrition education</div>
 </div>
 {TOPICS.map(t => (
 <button key={t.id} onClick={() => { setTopic(t.id); setSelectedDiet(null); setSelectedMacro(null) }}
 style={{ width:'100%', display:'flex', alignItems:'center', gap:12, padding:'12px 14px',
 borderBottom:'1px solid var(--border)', cursor:'pointer', transition:'all .15s', border:'none',
 background: topic===t.id ? 'var(--sage-pale)' : 'var(--white)',
 borderLeft: `3px solid ${topic===t.id ? 'var(--teal)' : 'transparent'}`,
 textAlign:'left' }}>
 <span style={{ color: topic===t.id ? 'var(--teal)' : 'var(--slate-light)', flexShrink:0 }}>{TOPIC_ICONS[t.id]}</span>
 <span style={{ fontSize:13, fontWeight: topic===t.id ? 700 : 500, color: topic===t.id ? 'var(--forest-deep)' : 'var(--slate)' }}>{t.label}</span>
 </button>
 ))}
 </div>

 {/* Content */}
 <div style={{ flex:1, overflowY:'auto', padding:'28px 32px' }}>

 {/* ── MACRONUTRIENTS ── */}
 {topic === 'macros' && (
 <div className="fade-up">
 <h2 className="bb-section-title"> Macronutrients</h2>
 <p className="bb-section-sub">The three macronutrients provide all of your dietary calories. Understanding them is the foundation of any nutrition plan.</p>

 <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
 {MACROS_DATA.map(m => (
 <div key={m.name} className="bb-card" style={{ cursor:'pointer', transition:'all .15s' }}
 onClick={() => setSelectedMacro(selectedMacro===m.name ? null : m.name)}>
 <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
 <div style={{ display:'flex', gap:14, alignItems:'flex-start' }}>
 <div style={{ width:52, height:52, borderRadius:'50%', background:`${m.color}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:24, flexShrink:0 }}>{m.icon}</div>
 <div>
 <div style={{ fontWeight:800, fontSize:17, color:'var(--forest-deep)' }}>{m.name}</div>
 <div style={{ fontSize:12, color:'var(--slate-light)', marginTop:1 }}>{m.kcalPerG} kcal per gram</div>
 <p style={{ fontSize:14, color:'var(--slate)', marginTop:6, lineHeight:1.5 }}>{m.desc}</p>
 </div>
 </div>
 <span style={{ color:'var(--teal)', fontSize:18, flexShrink:0 }}>{selectedMacro===m.name ? '▲' : '▼'}</span>
 </div>

 {selectedMacro===m.name && (
 <div style={{ marginTop:16, paddingTop:16, borderTop:'1px solid var(--border)' }} className="fade-up">
 <div className="bb-grid-2" style={{ gap:16 }}>
 <div>
 <div className="bb-label">Best Food Sources</div>
 <ul style={{ listStyle:'none', display:'flex', flexDirection:'column', gap:4 }}>
 {m.sources.map(s => <li key={s} style={{ fontSize:13, color:'var(--slate)', display:'flex', gap:6 }}><span style={{ color:'var(--teal)' }}>•</span>{s}</li>)}
 </ul>
 </div>
 <div>
 <div className="bb-label">Recommended Intake by Goal</div>
 {Object.entries(m.forGoals).map(([g, rec]) => (
 <div key={g} style={{ marginBottom:6, padding:'6px 10px', borderRadius:'var(--radius-sm)',
 background: userGoal===g ? 'var(--sage-pale)' : 'transparent',
 border: `1px solid ${userGoal===g ? 'var(--teal)' : 'transparent'}` }}>
 <div style={{ fontSize:11, fontWeight:700, color:'var(--teal-dark)', textTransform:'capitalize' }}>{g.replace('lose','Lose Weight').replace('muscle','Build Muscle').replace('maintain','Maintain').replace('athletic','Athletic')}</div>
 <div style={{ fontSize:13, color:'var(--slate)' }}>{rec}</div>
 </div>
 ))}
 </div>
 </div>
 </div>
 )}
 </div>
 ))}
 </div>
 </div>
 )}

 {/* ── MICRONUTRIENTS ── */}
 {topic === 'micros' && (
 <div className="fade-up">
 <h2 className="bb-section-title"> Micronutrients</h2>
 <p className="bb-section-sub">Vitamins and minerals that your body needs in small amounts — but their deficiency causes major problems.</p>
 <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
 {MICROS_DATA.map(m => (
 <div key={m.name} className="bb-card">
 <div style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15, marginBottom:6 }}>{m.name}</div>
 <div style={{ marginBottom:6 }}>
 <span className="bb-label" style={{ display:'inline', marginRight:4 }}>Role:</span>
 <span style={{ fontSize:13, color:'var(--slate)' }}>{m.role}</span>
 </div>
 <div style={{ marginBottom:6 }}>
 <span className="bb-label" style={{ display:'inline', marginRight:4 }}>Sources:</span>
 <span style={{ fontSize:13, color:'var(--teal-dark)' }}>{m.sources}</span>
 </div>
 <div style={{ background:'#fff7ed', borderRadius:'var(--radius-sm)', padding:'6px 10px', fontSize:12, color:'#92400e' }}>
 ️ Deficiency: {m.deficiency}
 </div>
 </div>
 ))}
 </div>
 </div>
 )}

 {/* ── PROTEIN DEEP DIVE ── */}
 {topic === 'protein' && (
 <div className="fade-up">
 <h2 className="bb-section-title"> Protein Deep Dive</h2>
 <p className="bb-section-sub">Not all proteins are equal. Here's everything you need to know.</p>

 <div className="bb-card" style={{ marginBottom:16 }}>
 <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:10, fontSize:16 }}>Complete vs. Incomplete Proteins</h3>
 <div className="bb-grid-2" style={{ gap:14 }}>
 <div style={{ padding:14, background:'var(--sage-pale)', borderRadius:'var(--radius-sm)' }}>
 <div style={{ fontWeight:700, color:'var(--forest)', marginBottom:6 }}> Complete Proteins</div>
 <p style={{ fontSize:13, color:'var(--slate)', marginBottom:8 }}>Contain all 9 essential amino acids. Your body can't make these — you must eat them.</p>
 <ul style={{ listStyle:'none', display:'flex', flexDirection:'column', gap:3 }}>
 {['Chicken & turkey','Beef & pork','Eggs','Fish & seafood','Dairy (milk, yogurt, cheese)','Quinoa','Soy / edamame'].map(f => (
 <li key={f} style={{ fontSize:13, color:'var(--slate)', display:'flex', gap:6 }}><span style={{ color:'var(--teal)' }}>•</span>{f}</li>
 ))}
 </ul>
 </div>
 <div style={{ padding:14, background:'#fff7ed', borderRadius:'var(--radius-sm)' }}>
 <div style={{ fontWeight:700, color:'#92400e', marginBottom:6 }}>️ Incomplete Proteins</div>
 <p style={{ fontSize:13, color:'var(--slate)', marginBottom:8 }}>Missing one or more essential amino acids. Combine these to make a complete protein.</p>
 <ul style={{ listStyle:'none', display:'flex', flexDirection:'column', gap:3 }}>
 {['Rice + Beans = Complete ','Peanut butter + Bread = Complete ','Hummus + Pita = Complete ','Lentils + Rice = Complete '].map(f => (
 <li key={f} style={{ fontSize:13, color:'var(--slate)', display:'flex', gap:6 }}><span style={{ color:'#d97706' }}>•</span>{f}</li>
 ))}
 </ul>
 </div>
 </div>
 </div>

 <div className="bb-card" style={{ marginBottom:16 }}>
 <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:12, fontSize:16 }}>Protein by Goal</h3>
 {[
 { goal:'Build Muscle', range:'1.6–2.2g per kg', why:'Muscle protein synthesis requires surplus amino acids consistently available', icon:'' },
 { goal:'Lose Weight', range:'1.2–1.6g per kg', why:'Higher protein prevents muscle loss (catabolism) while in a caloric deficit', icon:'' },
 { goal:'Athletic Performance', range:'1.4–1.7g per kg', why:'Supports muscle repair between training sessions and adaption to exercise', icon:'' },
 { goal:'General Health', range:'0.8–1.0g per kg', why:'Minimum required for basic body function, immune health, and enzyme production', icon:'' },
 ].map(p => (
 <div key={p.goal} style={{ display:'flex', gap:14, alignItems:'flex-start', padding:'10px 0', borderBottom:'1px solid var(--border)' }}>
 <span style={{ fontSize:24 }}>{p.icon}</span>
 <div>
 <div style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:14 }}>{p.goal}: <span style={{ color:'var(--teal)' }}>{p.range}</span></div>
 <p style={{ fontSize:13, color:'var(--slate)', marginTop:3 }}>{p.why}</p>
 </div>
 </div>
 ))}
 </div>

 <div className="bb-card" style={{ background:'var(--sage-pale)', border:'none' }}>
 <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:8, fontSize:15 }}> Protein Timing</h3>
 <ul style={{ listStyle:'none', display:'flex', flexDirection:'column', gap:6 }}>
 {[
 'Eat protein every 3–4 hours to maximize muscle protein synthesis',
 'Post-workout: 20–40g within 2 hours helps muscle recovery',
 'Pre-sleep: casein protein (cottage cheese, Greek yogurt) feeds muscles overnight',
 'Spreading intake across meals outperforms eating it all at once',
 ].map(t => <li key={t} style={{ fontSize:13, color:'var(--forest)', display:'flex', gap:8 }}><span>→</span>{t}</li>)}
 </ul>
 </div>
 </div>
 )}

 {/* ── WEIGHT LOSS 101 ── */}
 {topic === 'weightloss' && (
 <div className="fade-up">
 <h2 className="bb-section-title"> Weight Loss 101</h2>
 <p className="bb-section-sub">The science of fat loss, explained simply. No gimmicks.</p>

 <div className="bb-card bb-card--green" style={{ marginBottom:16 }}>
 <h3 style={{ fontWeight:800, fontSize:20, marginBottom:8 }}>The #1 Rule: CICO</h3>
 <p style={{ opacity:.9, fontSize:15, lineHeight:1.6 }}>
 <strong>Calories In, Calories Out.</strong> Fat loss comes down to thermodynamics — consuming fewer calories than your body burns. Your body will burn stored fat to make up the difference. <em>Every</em> diet that works does so by creating a caloric deficit, whether the person knows it or not.
 </p>
 </div>

 <div className="bb-card" style={{ marginBottom:16 }}>
 <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:12, fontSize:16 }}>Understanding Your Calorie Needs</h3>
 {[
 { term:'BMR (Basal Metabolic Rate)', def:'Calories your body burns at complete rest — just to breathe, pump blood, and maintain organ function. This is your absolute minimum.' },
 { term:'TDEE (Total Daily Energy Expenditure)', def:'BMR × activity multiplier. This is how many calories you actually burn per day with your lifestyle.' },
 { term:'Caloric Deficit', def:'Eating 300–500 calories below TDEE per day → lose ~0.3–0.5kg per week. Sustainable and muscle-preserving.' },
 { term:'Caloric Surplus', def:'Eating 200–400 calories above TDEE → gradual muscle gain with minimal fat (lean bulk).' },
 ].map(item => (
 <div key={item.term} style={{ marginBottom:12, padding:'10px 14px', borderRadius:'var(--radius-sm)', background:'var(--sage-pale)' }}>
 <div style={{ fontWeight:700, color:'var(--forest)', marginBottom:4 }}>{item.term}</div>
 <p style={{ fontSize:13, color:'var(--slate)', lineHeight:1.5 }}>{item.def}</p>
 </div>
 ))}
 </div>

 <div className="bb-card" style={{ marginBottom:16 }}>
 <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:12, fontSize:16 }}>What Actually Works</h3>
 <div className="bb-grid-2" style={{ gap:12 }}>
 {[
 { icon:'', title:'Proven Strategies', items:['Track calories (even roughly)', 'Eat high-volume, low-calorie foods', 'Prioritize protein (fills you up)', 'Don\'t drink your calories', 'Resistance train to preserve muscle', 'Sleep 7–9 hours (affects hunger hormones)'] },
 { icon:'', title:'Common Myths', items:['"Cardio alone burns fat"','Spot reduction (crunches = flat stomach)','Metabolism "boosting" supplements','Cutting carbs is magic (it\'s just fewer calories)','Meal timing matters more than total intake','You must avoid fat to lose fat'] },
 ].map(c => (
 <div key={c.title} style={{ padding:14, borderRadius:'var(--radius-sm)', background: c.icon==='' ? 'var(--sage-pale)' : '#fef2f2', border:`1px solid ${c.icon==='' ? 'var(--border)' : '#fecaca'}` }}>
 <div style={{ fontWeight:700, marginBottom:8, color: c.icon==='' ? 'var(--forest)' : '#991b1b' }}>{c.icon} {c.title}</div>
 {c.items.map(i => <div key={i} style={{ fontSize:13, color:'var(--slate)', marginBottom:4, display:'flex', gap:6 }}><span>{c.icon==='' ? '→' : ''}</span>{i}</div>)}
 </div>
 ))}
 </div>
 </div>

 <div className="bb-card" style={{ background:'var(--sage-pale)', border:'none' }}>
 <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:8, fontSize:15 }}> Rule of Thumb Numbers</h3>
 <div style={{ display:'flex', gap:16, flexWrap:'wrap' }}>
 {[['1 lb fat','= 3,500 calories'],['Safe deficit','300–500 cal/day'],['Healthy loss','.25–.5 kg/week'],['High protein','helps 2x']].map(([l,v])=>(
 <div key={l} style={{ textAlign:'center', flex:1, minWidth:100 }}>
 <div style={{ fontFamily:"'Fraunces',serif", fontSize:22, fontWeight:700, color:'var(--forest)' }}>{v}</div>
 <div style={{ fontSize:12, color:'var(--slate-light)', marginTop:2 }}>{l}</div>
 </div>
 ))}
 </div>
 </div>
 </div>
 )}

 {/* ── DIET GUIDES ── */}
 {topic === 'diets' && (
 <div className="fade-up">
 <h2 className="bb-section-title">️ Diet Guides</h2>
 <p className="bb-section-sub">Every major diet explained — what it is, who it's for, and what to eat.</p>

 <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:20 }}>
 {DIETS_DATA.map(d => (
 <button key={d.name} className={`bb-pill ${selectedDiet===d.name ? 'active' : ''}`}
 onClick={() => setSelectedDiet(selectedDiet===d.name ? null : d.name)}>
 {d.icon} {d.name}
 </button>
 ))}
 </div>

 {selectedDiet ? (
 <div className="fade-up">
 {DIETS_DATA.filter(d => d.name===selectedDiet).map(d => (
 <div key={d.name}>
 <div className="bb-card bb-card--green" style={{ marginBottom:16 }}>
 <div style={{ fontSize:40, marginBottom:8 }}>{d.icon}</div>
 <h3 style={{ fontFamily:"'Fraunces',serif", fontSize:26, fontWeight:900, marginBottom:6 }}>{d.name}</h3>
 <p style={{ opacity:.85, fontSize:14 }}>Best for: <strong>{d.best}</strong></p>
 </div>
 <div className="bb-grid-2" style={{ gap:14, marginBottom:14 }}>
 <div className="bb-card">
 <div className="bb-label"> Eat These Foods</div>
 {d.foods.map(f => <div key={f} style={{ fontSize:13, color:'var(--slate)', marginBottom:5, display:'flex', gap:6 }}><span style={{ color:'var(--teal)' }}>•</span>{f}</div>)}
 </div>
 <div className="bb-card" style={{ background:'#fef2f2', borderColor:'#fecaca' }}>
 <div className="bb-label" style={{ color:'#dc2626' }}> Avoid</div>
 {d.avoid.map(f => <div key={f} style={{ fontSize:13, color:'var(--slate)', marginBottom:5, display:'flex', gap:6 }}><span style={{ color:'#dc2626' }}></span>{f}</div>)}
 </div>
 </div>
 <div className="bb-card" style={{ background:'var(--sage-pale)', border:'none' }}>
 <span style={{ fontSize:20 }}> </span><strong style={{ color:'var(--forest)' }}>Pro tip: </strong>
 <span style={{ fontSize:14, color:'var(--slate)' }}>{d.tip}</span>
 </div>
 </div>
 ))}
 </div>
 ) : (
 <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
 {DIETS_DATA.map(d => (
 <div key={d.name} className="bb-card" style={{ cursor:'pointer', display:'flex', gap:16, alignItems:'center' }}
 onClick={() => setSelectedDiet(d.name)}>
 <span style={{ fontSize:32 }}>{d.icon}</span>
 <div>
 <div style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15 }}>{d.name}</div>
 <div style={{ fontSize:13, color:'var(--slate-light)' }}>Best for: {d.best}</div>
 </div>
 <span style={{ marginLeft:'auto', color:'var(--teal)', fontSize:18 }}>→</span>
 </div>
 ))}
 </div>
 )}
 </div>
 )}

 {/* ── ENERGY & PERFORMANCE ── */}
 {topic === 'energy' && (
 <div className="fade-up">
 <h2 className="bb-section-title"> Energy & Athletic Performance</h2>
 <p className="bb-section-sub">How to eat for sustained energy, peak performance, and faster recovery.</p>

 <div className="bb-card" style={{ marginBottom:16 }}>
 <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:12, fontSize:16 }}>Pre-Workout Nutrition</h3>
 {[
 { time:'2–3 hours before', rec:'Full meal: carbs + protein + low fat', example:'Chicken, brown rice, vegetables', why:'Fully digest before exercise' },
 { time:'30–60 min before', rec:'Light snack: fast carbs + small protein', example:'Banana + peanut butter, rice cakes + honey', why:'Quick energy without GI distress' },
 { time:'During (60+ min)', rec:'30–60g carbs per hour', example:'Sports drink, banana, dates', why:'Maintain blood glucose for endurance' },
 ].map(p => (
 <div key={p.time} style={{ marginBottom:12, padding:'12px 14px', borderRadius:'var(--radius-sm)', background:'var(--sage-pale)', borderLeft:'3px solid var(--teal)' }}>
 <div style={{ fontWeight:700, color:'var(--forest)', fontSize:13 }}>{p.time}</div>
 <div style={{ fontSize:14, fontWeight:600, color:'var(--slate)', margin:'4px 0' }}>{p.rec}</div>
 <div style={{ fontSize:13, color:'var(--teal-dark)' }}>e.g. {p.example}</div>
 <div style={{ fontSize:12, color:'var(--slate-light)', marginTop:2 }}>{p.why}</div>
 </div>
 ))}
 </div>

 <div className="bb-card" style={{ marginBottom:16 }}>
 <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:12, fontSize:16 }}>Post-Workout Recovery</h3>
 <div className="bb-grid-2" style={{ gap:12 }}>
 <div style={{ padding:14, background:'var(--sage-pale)', borderRadius:'var(--radius-sm)' }}>
 <div style={{ fontWeight:700, color:'var(--forest)', marginBottom:8 }}> Within 30–60 minutes</div>
 {['20–40g protein (repair muscle)','Carbs to replenish glycogen','Plenty of water + electrolytes'].map(i=><div key={i} style={{ fontSize:13, color:'var(--slate)', marginBottom:4 }}>→ {i}</div>)}
 </div>
 <div style={{ padding:14, background:'#fff7ed', borderRadius:'var(--radius-sm)' }}>
 <div style={{ fontWeight:700, color:'#92400e', marginBottom:8 }}>️ Don't skip this</div>
 {['Skipping post-workout protein blunts muscle gains','Dehydration reduces performance 10–20%','Under-eating carbs extends soreness'].map(i=><div key={i} style={{ fontSize:13, color:'var(--slate)', marginBottom:4 }}>→ {i}</div>)}
 </div>
 </div>
 </div>

 <div className="bb-card" style={{ background:'var(--sage-pale)', border:'none' }}>
 <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:10, fontSize:15 }}> Best Performance Foods</h3>
 <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
 {['Oats','Bananas','Beets (boosts endurance)','Salmon (omega-3)','Sweet potato','Cherries (reduces soreness)','Spinach (iron for O₂)','Eggs','Chocolate milk (recovery)','Watermelon (citrulline)'].map(f=>(
 <span key={f} style={{ background:'var(--white)', border:'1px solid var(--border)', color:'var(--forest)', padding:'5px 12px', borderRadius:99, fontSize:13 }}>{f}</span>
 ))}
 </div>
 </div>
 </div>
 )}

 </div>
 </div>
 )
}
