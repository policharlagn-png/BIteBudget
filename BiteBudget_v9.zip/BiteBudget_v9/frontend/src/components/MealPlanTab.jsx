// src/components/MealPlanTab.jsx  — MEAL PLANNER (Family)
import React, { useState, useRef, useEffect, Component } from 'react'
import { useMutation } from '@tanstack/react-query'
import { generateMealPlan, geocodeAddress } from '../utils/api.js'

// ── Error Boundary ────────────────────────────────────────────────────
class ErrorBoundary extends Component {
  constructor(props) { super(props); this.state = { error: null }; }
  static getDerivedStateFromError(error) { return { error }; }
  render() {
    if (this.state.error) return (
      <div style={{ padding:32, textAlign:'center' }}>
        <p style={{ color:'#dc2626', marginBottom:8, fontWeight:600 }}>Something went wrong rendering the meal plan.</p>
        <p style={{ color:'var(--slate-light)', fontSize:12, marginBottom:20, fontFamily:'monospace' }}>{this.state.error?.message}</p>
        <button className="bb-btn bb-btn--primary" onClick={() => { this.setState({ error: null }); this.props.onReset(); }}>
          Generate New Plan
        </button>
      </div>
    )
    return this.props.children
  }
}

const ACTIVITY_LEVELS = [
  { id:'sedentary', label:'Sedentary',         desc:'Minimal movement' },
  { id:'light',     label:'Lightly Active',    desc:'1-3 days/week' },
  { id:'moderate',  label:'Moderately Active', desc:'3-5 days/week' },
  { id:'very',      label:'Very Active',       desc:'6-7 days/week' },
]

const DIET_OPTIONS = [
  'No Restriction','Vegan','Vegetarian','Keto','Gluten-Free',
  'High Protein','Mediterranean','Pescatarian','Dairy-Free','Nut-Free',
]

let idCounter = 1
function newMember() {
  return { id: idCounter++, name: '', activity: 'moderate', dietary: 'No Restriction' }
}

// ── Family Member Card ────────────────────────────────────────────────
function MemberCard({ member, onChange, onRemove, index }) {
  return (
    <div style={{
      border: '1.5px solid var(--border)',
      borderRadius:'var(--radius-md)', padding:'14px 16px', marginBottom:12,
      background:'var(--white)'
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12 }}>
        <div style={{ width:32, height:32, borderRadius:'50%',
          background:'var(--sage-pale)', border:'1.5px solid var(--border)',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:13, fontWeight:700, color:'var(--forest-deep)', flexShrink:0 }}>
          {index + 1}
        </div>
        <input className="bb-input"
          placeholder={`Member ${index + 1} name (optional)`}
          value={member.name}
          onChange={e => onChange({ ...member, name: e.target.value })}
          style={{ flex:1, marginBottom:0, padding:'6px 10px', fontSize:13 }}
        />
        <button onClick={onRemove}
          style={{ background:'none', border:'none', cursor:'pointer', color:'#dc2626', fontSize:20, padding:'0 4px', flexShrink:0 }}>
          x
        </button>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
        <div>
          <label className="bb-label" style={{ fontSize:11 }}>Activity Level</label>
          <select className="bb-select" value={member.activity}
            onChange={e => onChange({ ...member, activity: e.target.value })}
            style={{ padding:'7px 10px', fontSize:13 }}>
            {ACTIVITY_LEVELS.map(a => (
              <option key={a.id} value={a.id}>{a.label} — {a.desc}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="bb-label" style={{ fontSize:11 }}>Dietary Restriction</label>
          <select className="bb-select" value={member.dietary}
            onChange={e => onChange({ ...member, dietary: e.target.value })}
            style={{ padding:'7px 10px', fontSize:13 }}>
            {DIET_OPTIONS.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  )
}

// ── Embedded store map ────────────────────────────────────────────────
function EmbeddedStoreMap({ mealPlan, location }) {
  const mapRef    = useRef(null)
  const mapObjRef = useRef(null)
  const nearbyStores = (mealPlan?.nearbyStores || []).filter(s =>
    !s.type || s.type === 'grocery' || s.type === 'market' || s.type === 'snap_retailer'
  )
  useEffect(() => {
    if (!location || !mapRef.current || nearbyStores.length === 0) return
    const GOOGLE_KEY = 'AIzaSyAZ4my0W6cTNisJuXcsVwNsApSSvWASFrs'
    const init = () => {
      if (mapObjRef.current) return
      const center = { lat:location.lat, lng:location.lng }
      const map = new window.google.maps.Map(mapRef.current, {
        center, zoom:13, mapTypeControl:false, fullscreenControl:false, streetViewControl:false,
      })
      mapObjRef.current = map
      new window.google.maps.Marker({
        position:center, map,
        icon:{ path:window.google.maps.SymbolPath.CIRCLE, scale:9, fillColor:'#3b82f6', fillOpacity:1, strokeColor:'#fff', strokeWeight:2 },
        title:'Your Location'
      })
      nearbyStores.forEach((store, idx) => {
        const marker = new window.google.maps.Marker({
          position:{ lat:store.lat, lng:store.lng }, map,
          title:store.name,
          label:{ text:String(idx+1), color:'white', fontWeight:'bold', fontSize:'12px' },
          icon:{ path:window.google.maps.SymbolPath.BACKWARD_CLOSED_ARROW, scale:8, fillColor:'#52b788', fillOpacity:1, strokeColor:'#fff', strokeWeight:2 }
        })
        const info = new window.google.maps.InfoWindow({
          content:`<div style="font-family:sans-serif;padding:4px"><strong>#${idx+1} ${store.name}</strong><div style="font-size:12px;color:#666;margin-top:2px">${store.address||''}</div>${store.rating?`<div style="font-size:12px;color:#f59e0b">★ ${store.rating}</div>`:''}</div>`
        })
        marker.addListener('click', () => info.open(map, marker))
      })
    }
    if (window.google?.maps) { init(); return }
    if (!document.querySelector('script[data-gmaps]')) {
      const s = document.createElement('script')
      s.src=`https://maps.googleapis.com/maps/api/js?key=${GOOGLE_KEY}&libraries=places`
      s.async=true; s.dataset.gmaps='1'; s.onload=init
      document.head.appendChild(s)
    } else {
      document.querySelector('script[data-gmaps]').addEventListener('load', init)
    }
  }, [location?.lat, location?.lng, nearbyStores.length])

  if (!location || nearbyStores.length === 0) return null
  return (
    <div className="bb-card" style={{ marginTop:16, padding:0, overflow:'hidden' }}>
      <div style={{ padding:'14px 18px', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <h3 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15 }}>Grocery Stores Near You</h3>
          <p style={{ fontSize:12, color:'var(--slate-light)', marginTop:2 }}>
            {nearbyStores.length} grocery and market locations ranked by nutrition score
          </p>
        </div>
        <a href={`https://www.google.com/maps/search/grocery+store+near+${encodeURIComponent(location.display||location.displayName||'')}`}
          target="_blank" rel="noopener noreferrer"
          style={{ fontSize:12, color:'var(--teal-dark)', fontWeight:600, textDecoration:'none' }}>
          Open in Maps
        </a>
      </div>
      <div ref={mapRef} style={{ width:'100%', height:320 }} />
      <div style={{ padding:'14px 18px' }}>
        {nearbyStores.map((store, i) => (
          <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
            padding:'8px 0', borderBottom: i < nearbyStores.length-1 ? '1px solid var(--border)' : 'none' }}>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <div style={{ width:22, height:22, borderRadius:'50%', background:'var(--teal)', color:'white',
                fontSize:11, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                {i+1}
              </div>
              <div>
                <div style={{ fontWeight:600, fontSize:13, color:'var(--forest-deep)' }}>{store.name}</div>
                <div style={{ fontSize:11, color:'var(--slate-light)' }}>{store.address}</div>
              </div>
            </div>
            {store.rating && <span style={{ fontSize:12, color:'#d97706', fontWeight:600 }}>★ {store.rating}</span>}
          </div>
        ))}
      </div>
    </div>
  )
}

// ── MealCard ──────────────────────────────────────────────────────────
function MealCard({ label, meal }) {
  const [open, setOpen] = useState(true)
  if (!meal) return null
  return (
    <div style={{ border:'1px solid var(--border)', borderRadius:'var(--radius-md)', overflow:'hidden', marginBottom:10 }}>
      <button onClick={() => setOpen(o => !o)} style={{
        display:'flex', alignItems:'center', justifyContent:'space-between', width:'100%',
        padding:'10px 14px', background:'var(--sage-pale)',
        borderBottom: open ? '1px solid var(--border)' : 'none', textAlign:'left'
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <span style={{ fontWeight:700, fontSize:12, color:'var(--forest-deep)', textTransform:'uppercase', letterSpacing:'.6px' }}>{label}</span>
          <span style={{ fontWeight:600, color:'var(--slate)', fontSize:14 }}>{meal.name}</span>
        </div>
        <div style={{ display:'flex', gap:10, fontSize:12, color:'var(--slate-light)', alignItems:'center' }}>
          {meal.calories && <span style={{ fontWeight:600, color:'var(--forest)' }}>{meal.calories} cal</span>}
          {meal.protein  && <span>{meal.protein}g protein</span>}
          {meal.cost != null && <span style={{ color:'var(--teal-dark)', fontWeight:700 }}>${typeof meal.cost === 'number' ? meal.cost.toFixed(2) : meal.cost}</span>}
          <span style={{ fontSize:16 }}>{open ? '▲' : '▼'}</span>
        </div>
      </button>
      {open && (
        <div style={{ padding:'12px 14px' }}>
          {meal.ingredients?.length > 0 && (
            <div style={{ display:'flex', flexWrap:'wrap', gap:5, marginBottom:8 }}>
              {meal.ingredients.map((ing, i) => (
                <span key={i} style={{ background:'var(--sage-pale)', color:'var(--slate)',
                  fontSize:12, padding:'3px 10px', borderRadius:99, border:'1px solid var(--border)' }}>
                  {ing}
                </span>
              ))}
            </div>
          )}
          <div style={{ display:'flex', gap:14, fontSize:12, color:'var(--slate-light)', flexWrap:'wrap' }}>
            {meal.prepTime && <span>Prep: {meal.prepTime}</span>}
            {meal.carbs && <span>Carbs: {meal.carbs}g</span>}
            {meal.fat && <span>Fat: {meal.fat}g</span>}
          </div>
        </div>
      )}
    </div>
  )
}

// ── Plan View ─────────────────────────────────────────────────────────
function MealPlanView({ mealPlan, onRegenerate, loading, address, budget, location, familyMembers }) {
  const [activeDay, setActiveDay] = useState(0)
  const day = mealPlan.days?.[activeDay]
  const dayTotal = day ? (day.breakfast?.calories||0)+(day.lunch?.calories||0)+(day.dinner?.calories||0)+(day.snack?.calories||0) : 0
  const dayCost  = day ? ((day.breakfast?.cost||0)+(day.lunch?.cost||0)+(day.dinner?.cost||0)+(day.snack?.cost||0)).toFixed(2) : '0.00'

  return (
    <>
      <div className="bb-card" style={{ padding:0, overflow:'hidden' }}>
        <div style={{ background:'linear-gradient(135deg, var(--forest-deep), var(--forest))',
          padding:'18px 22px', display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:10 }}>
          <div>
            <h3 style={{ fontFamily:"'Sora',sans-serif", fontWeight:800, color:'white', fontSize:20 }}>
              Family 7-Day Meal Plan
            </h3>
            <p style={{ fontSize:12, color:'rgba(255,255,255,.75)', marginTop:3 }}>
              {address && <span>{address} · </span>}
              <strong style={{ color:'var(--mint)' }}>{familyMembers?.length || 1} member{(familyMembers?.length||1)>1?'s':''}</strong>
              {' · '}<strong style={{ color:'var(--mint)' }}>${budget}/week</strong>
              {' · '}Est: <strong style={{ color:'var(--mint)' }}>${mealPlan.estimatedCost}</strong>
            </p>
            {familyMembers?.length > 0 && (
              <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginTop:6 }}>
                {familyMembers.map((m, i) => (
                  <span key={i} style={{ fontSize:10, background:'rgba(255,255,255,.15)', color:'white',
                    padding:'2px 8px', borderRadius:99, border:'1px solid rgba(255,255,255,.3)' }}>
                    {m.name || `Member ${i+1}`}{m.dietary !== 'No Restriction' ? ` (${m.dietary})` : ''}
                  </span>
                ))}
              </div>
            )}
          </div>
          <button onClick={onRegenerate} disabled={loading}
            style={{ background:'rgba(255,255,255,.15)', color:'white', border:'1px solid rgba(255,255,255,.35)',
              fontSize:13, fontWeight:600, padding:'9px 18px', borderRadius:'var(--radius-sm)', cursor:'pointer',
              opacity:loading ? 0.6 : 1, whiteSpace:'nowrap' }}>
            {loading ? 'Generating...' : 'New Plan'}
          </button>
        </div>

        <div style={{ display:'flex', overflowX:'auto', borderBottom:'1px solid var(--border)', background:'var(--white)' }}>
          {mealPlan.days?.map((d, i) => (
            <button key={i} onClick={() => setActiveDay(i)} style={{
              flexShrink:0, padding:'11px 16px', fontSize:13, fontWeight:activeDay===i ? 700 : 500,
              color:activeDay===i ? 'var(--forest-deep)' : 'var(--slate-light)',
              background:'none', cursor:'pointer', border:'none',
              borderBottomStyle:'solid', borderBottomWidth:3,
              borderBottomColor:activeDay===i ? 'var(--teal)' : 'transparent',
            }}>{d.day}</button>
          ))}
        </div>

        {day && (
          <div style={{ padding:'18px 22px' }} key={activeDay}>
            <div style={{ display:'flex', gap:10, marginBottom:16, flexWrap:'wrap' }}>
              {[['Calories',`${dayTotal} kcal`],['Protein',`${day.totalProtein||'—'}g`],
                ['Carbs',`${day.totalCarbs||'—'}g`],['Fat',`${day.totalFat||'—'}g`],['Day Cost',`$${dayCost}`]
              ].map(([l,v]) => (
                <div key={l} style={{ background:'var(--sage-pale)', borderRadius:'var(--radius-sm)',
                  padding:'9px 16px', minWidth:90, textAlign:'center', border:'1px solid var(--border)', flex:'1 1 80px' }}>
                  <div style={{ fontSize:11, color:'var(--slate-light)', textTransform:'uppercase', letterSpacing:'.5px', marginBottom:3 }}>{l}</div>
                  <div style={{ fontWeight:800, color:'var(--forest-deep)', fontSize:15 }}>{v}</div>
                </div>
              ))}
            </div>
            <MealCard label="Breakfast" meal={day.breakfast} />
            <MealCard label="Lunch"     meal={day.lunch} />
            <MealCard label="Dinner"    meal={day.dinner} />
            {day.snack && <MealCard label="Snack / Dessert" meal={day.snack} />}
            <div style={{ display:'flex', justifyContent:'space-between', marginTop:12 }}>
              <button className="bb-btn bb-btn--soft" onClick={() => setActiveDay(d => Math.max(0,d-1))}
                disabled={activeDay===0} style={{ fontSize:13, padding:'8px 16px' }}>Previous</button>
              <button className="bb-btn bb-btn--soft" onClick={() => setActiveDay(d => Math.min((mealPlan.days?.length||1)-1,d+1))}
                disabled={activeDay===(mealPlan.days?.length||1)-1} style={{ fontSize:13, padding:'8px 16px' }}>Next</button>
            </div>
          </div>
        )}

        {mealPlan.shoppingList?.length > 0 && (
          <div style={{ borderTop:'1px solid var(--border)', padding:'18px 22px' }}>
            <h4 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:12, fontSize:15 }}>Weekly Cost Estimate</h4>
            <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
              {mealPlan.shoppingList.map((item, i) => (
                <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                  fontSize:13, padding:'6px 0', borderBottom:'1px solid var(--border)' }}>
                  <div>
                    <span style={{ fontWeight:600, color:'var(--slate)' }}>{item.item}</span>
                    {item.store && item.store !== 'Any' && (
                      <span style={{ marginLeft:8, fontSize:11, color:'var(--teal-dark)', background:'var(--sage-pale)',
                        padding:'2px 8px', borderRadius:99, border:'1px solid var(--border)' }}>{item.store}</span>
                    )}
                  </div>
                  <span style={{ fontWeight:700, color:'var(--forest)' }}>${(item.estimatedCost||0).toFixed(2)}</span>
                </div>
              ))}
              {(() => {
                const sub = mealPlan.shoppingList.reduce((s,i) => s+(i.estimatedCost||0), 0)
                const tax = sub * 0.15 * 0.0725
                const tot = sub + tax
                return (
                  <div style={{ marginTop:8, paddingTop:8, borderTop:'2px solid var(--border)' }}>
                    <div style={{ display:'flex', justifyContent:'space-between', fontSize:13, color:'var(--slate-light)', marginBottom:4 }}>
                      <span>Subtotal</span><span>${sub.toFixed(2)}</span>
                    </div>
                    <div style={{ display:'flex', justifyContent:'space-between', fontSize:13, color:'var(--slate-light)', marginBottom:8 }}>
                      <span>Est. Tax</span><span>${tax.toFixed(2)}</span>
                    </div>
                    <div style={{ display:'flex', justifyContent:'space-between', fontWeight:800, fontSize:16 }}>
                      <span style={{ color:'var(--forest-deep)' }}>Total (with tax)</span>
                      <span style={{ color:'var(--forest)' }}>${tot.toFixed(2)}</span>
                    </div>
                  </div>
                )
              })()}
            </div>
          </div>
        )}
      </div>
      <EmbeddedStoreMap mealPlan={mealPlan} location={location} />
    </>
  )
}

// ── Main: Meal Planner ────────────────────────────────────────────────
export default function MealPlanTab({ address, setAddress, location, setLocation, budget, setBudget, goals, mealPlan, setMealPlan, onViewMap }) {
  const [addrInput, setAddrInput]         = useState(address || '')
  const [addrError, setAddrError]         = useState('')
  const [geocoding, setGeocoding]         = useState(false)
  const [genError, setGenError]           = useState('')
  const [familyMembers, setFamilyMembers] = useState(() => [newMember()])
  const [, forceUpdate]                   = useState(0)

  const addMember    = () => { setFamilyMembers(ms => [...ms, newMember()]); forceUpdate(n => n+1) }
  const updateMember = (id, updated) => setFamilyMembers(ms => ms.map(m => m.id===id ? updated : m))
  const removeMember = (id) => setFamilyMembers(ms => ms.length > 1 ? ms.filter(m => m.id !== id) : ms)

  const allRestrictions = [...new Set(
    familyMembers.map(m => m.dietary).filter(d => d && d !== 'No Restriction')
  )]

  const goalsPayload = goals?.goal ? {
    goal:goals.goal, activity:goals.activity,
    tdee:goals.tdee, calorieTarget:goals.calorieTarget,
    macros:goals.macros, diet:goals.diet,
  } : null

  const { mutate: genPlan, isPending } = useMutation({
    mutationFn: () => {
      const memberSummaries = familyMembers.map(m => ({
        name:     m.name || undefined,
        activity: m.activity,
        dietary:  m.dietary,
      }))
      return generateMealPlan({
        budget,
        householdSize: familyMembers.length,
        familyMembers: memberSummaries,
        dietaryRestrictions: allRestrictions,
        goals: goalsPayload,
        lat:  location?.lat  || null,
        lng:  location?.lng  || null,
        locationAddress: address || addrInput,
        seed: Date.now(),
        familyPlan: true,
      })
    },
    onSuccess: data => { setGenError(''); setMealPlan(data) },
    onError: (err) => {
      console.error(err)
      const status = err?.response?.status
      const serverMsg = err?.response?.data?.error
      if (!status || err?.code === 'ERR_NETWORK' || String(err).includes('503') || String(err).includes('ECONNREFUSED')) {
        setGenError('Cannot reach the server. Make sure the backend is running: open a terminal and run bash start.sh from the BiteBudget folder.')
      } else if (serverMsg) {
        setGenError('Server error: ' + serverMsg)
      } else {
        setGenError('Generation failed — please try again.')
      }
    },
  })

  const handleGenerate = async () => {
    setAddrError(''); setGenError('')
    if (!addrInput.trim()) { setAddrError('Please enter your address, city, or zip code first.'); return }
    setGeocoding(true)
    try {
      const result = await geocodeAddress(addrInput.trim())
      const loc = { ...result, display: result.displayName || addrInput }
      setLocation(loc); setAddress(addrInput.trim())
      setGeocoding(false)
      genPlan()
    } catch {
      setGeocoding(false)
      setAddrError('Address not found — try a city name or zip code.')
    }
  }

  const busy = geocoding || isPending

  // ── Setup screen ─────────────────────────────────────────────────────
  if (!mealPlan) return (
    <div className="bb-page fade-up" style={{ maxWidth:660, margin:'0 auto' }}>
      <div style={{ marginBottom:24 }}>
        <h1 className="bb-section-title" style={{ fontSize:26 }}>Meal Planner</h1>
        <p className="bb-section-sub">
          Add your family members and we will build a personalized 7-day meal plan for everyone,
          accounting for each person's dietary needs and activity level.
        </p>
      </div>

      {/* Location */}
      <div className="bb-card">
        <h2 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:16, marginBottom:4 }}>Your Location</h2>
        <p style={{ fontSize:13, color:'var(--slate-light)', marginBottom:12 }}>
          We'll find real grocery stores near your zip code or address to base prices on.
        </p>
        <label className="bb-label">Address, city, or zip code</label>
        <input className="bb-input" type="text"
          placeholder="e.g. Austin TX  or  90210  or  123 Main St Chicago"
          value={addrInput}
          onChange={e => { setAddrInput(e.target.value); setAddrError('') }}
          onKeyDown={e => e.key === 'Enter' && !busy && handleGenerate()}
        />
        {addrError && <p style={{ fontSize:12, color:'#dc2626', marginTop:6 }}>{addrError}</p>}
        {location && <p style={{ fontSize:12, color:'var(--teal-dark)', marginTop:6, fontWeight:600 }}>Located: {location.display || location.displayName}</p>}
      </div>

      {/* Budget */}
      <div className="bb-card">
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
          <div>
            <h2 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:16 }}>Weekly Grocery Budget</h2>
            <p style={{ fontSize:12, color:'var(--slate-light)', marginTop:2 }}>
              For {familyMembers.length} family member{familyMembers.length>1?'s':''}
            </p>
          </div>
          <span style={{ fontFamily:"'Sora',sans-serif", fontSize:36, fontWeight:800, color:'var(--forest)' }}>${budget}</span>
        </div>
        <input type="range" min={25} max={400} step={5} value={budget}
          onChange={e => setBudget(+e.target.value)} style={{ width:'100%' }} />
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:12, color:'var(--slate-light)', marginTop:6 }}>
          <span>$25/week</span><span>$400/week</span>
        </div>
      </div>

      {/* Family members */}
      <div className="bb-card">
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
          <div>
            <h2 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:16 }}>Family Members</h2>
            <p style={{ fontSize:12, color:'var(--slate-light)', marginTop:2 }}>
              Add each person in your household
            </p>
          </div>
          <button className="bb-btn bb-btn--soft" onClick={addMember}
            style={{ fontSize:13, padding:'7px 14px', whiteSpace:'nowrap' }}>
            + Add Member
          </button>
        </div>

        {familyMembers.map((m, i) => (
          <MemberCard key={m.id} member={m} index={i}
            onChange={updated => updateMember(m.id, updated)}
            onRemove={() => removeMember(m.id)}
          />
        ))}


      </div>

      {goals?.goal && (
        <div style={{ background:'var(--sage-pale)', border:'1.5px solid var(--teal)', borderRadius:'var(--radius-md)',
          padding:'14px 18px', marginBottom:20, fontSize:13 }}>
          <div style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:4 }}>
            Personal goals from My Personal Goals applied to this plan:
          </div>
          <div style={{ color:'var(--slate)', display:'flex', gap:16, flexWrap:'wrap' }}>
            <span>Goal: {goals.goal}</span>
            <span>Activity: {goals.activity}</span>
            {goals.calorieTarget && <span>{goals.calorieTarget} kcal/day</span>}
            {goals.macros && <span>{goals.macros.protein}g protein/day</span>}
          </div>
        </div>
      )}

      <button className="bb-btn bb-btn--primary" style={{ width:'100%', padding:'16px', fontSize:16 }}
        onClick={handleGenerate} disabled={busy}>
        {geocoding ? 'Finding your location...'
          : isPending ? 'Generating your meal plan...'
          : `Generate Meal Plan (${familyMembers.length} member${familyMembers.length>1?'s':''})`}
      </button>

      {genError && <p style={{ color:'#dc2626', textAlign:'center', marginTop:10, fontSize:13 }}>{genError}</p>}
      {isPending && (
        <p style={{ textAlign:'center', fontSize:13, color:'var(--slate-light)', marginTop:10 }}>
          Building your personalized plan — this takes about 15-30 seconds...
        </p>
      )}
    </div>
  )

  // ── Plan view ─────────────────────────────────────────────────────────
  return (
    <div className="bb-page fade-up">
      <ErrorBoundary onReset={() => { setMealPlan(null); genPlan() }}>
        <MealPlanView
          mealPlan={mealPlan} onRegenerate={() => genPlan()}
          loading={isPending} address={address} budget={budget}
          location={location} familyMembers={familyMembers}
        />
      </ErrorBoundary>
      {genError && <p style={{ color:'#dc2626', textAlign:'center', marginTop:10, fontSize:13 }}>{genError}</p>}
      <div style={{ display:'flex', gap:10, marginTop:14, justifyContent:'center', flexWrap:'wrap' }}>
        <button className="bb-btn bb-btn--soft" style={{ fontSize:13 }} onClick={() => setMealPlan(null)}>
          Change Members / Budget / Location
        </button>
        <button className="bb-btn bb-btn--soft" style={{ fontSize:13 }} onClick={onViewMap}>
          View Full Food Map
        </button>
      </div>
    </div>
  )
}
