// src/components/FoodMap.jsx
// Uses Google Maps JavaScript API — loaded dynamically with your key
import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useQuery } from '@tanstack/react-query'
import { fetchStores } from '../utils/api.js'

const GOOGLE_KEY = 'AIzaSyAZ4my0W6cTNisJuXcsVwNsApSSvWASFrs'

const SCORE_COLOR = s => s >= 75 ? '#2d6a4f' : s >= 50 ? '#d97706' : '#dc2626'
const TYPE_LABEL  = {
  food_bank:     'Food Bank',
  market:        'Farmers Market',
  snap_retailer: 'SNAP Retailer',
  grocery:       'Grocery Store',
  default:       'Store',
}

const CHAIN_MULTS = {
  walmart: 0.82, aldi: 0.80, lidl: 0.81, kroger: 0.92,
  publix: 1.05, target: 0.97, costco: 0.85, 'trader joe': 0.95,
  meijer: 0.91, 'h-e-b': 0.88, wegmans: 1.04, safeway: 1.00,
  albertsons: 1.00, 'whole foods': 1.30, sprouts: 1.18,
  'save-a-lot': 0.83, 'food lion': 0.90, giant: 1.01,
}

function getStoreMult(name = '') {
  const lower = name.toLowerCase()
  for (const [key, mult] of Object.entries(CHAIN_MULTS)) {
    if (lower.includes(key)) return mult
  }
  return 1.0
}

const BASE_PRICES = {
  'Milk (1 gal)': 3.99, 'Eggs (dozen)': 3.49, 'Bread': 2.79,
  'Chicken breast (1lb)': 4.99, 'Apples (3lb)': 4.29, 'Spinach': 2.49,
  'Brown rice (2lb)': 3.29, 'Black beans (can)': 1.29, 'Oats (42oz)': 3.99,
  'Canned tuna': 1.49, 'Bananas': 0.89, 'Sweet potatoes (3lb)': 3.49,
  'Greek yogurt': 4.99, 'Peanut butter': 3.99, 'Broccoli': 2.29,
  'Salmon fillet (1lb)': 8.99, 'Avocado': 1.49, 'Lentils (1lb)': 2.49,
  'Canned tomatoes': 1.89, 'Olive oil': 6.99,
}

function getPrice(item, storeName) {
  const base   = BASE_PRICES[item] || 2.99
  const mult   = getStoreMult(storeName)
  const hash   = (item + storeName).split('').reduce((a, c) => a + c.charCodeAt(0), 0)
  const jitter = 0.93 + (hash % 100) / 700
  return +(base * mult * jitter).toFixed(2)
}

// ── Load Google Maps script once ─────────────────────────────────────
let googleMapsPromise = null
function loadGoogleMaps() {
  if (googleMapsPromise) return googleMapsPromise
  if (window.google?.maps) return Promise.resolve()

  googleMapsPromise = new Promise((resolve, reject) => {
    const script    = document.createElement('script')
    script.src      = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_KEY}&libraries=places`
    script.async    = true
    script.defer    = true
    script.onload   = resolve
    script.onerror  = () => reject(new Error('Failed to load Google Maps'))
    document.head.appendChild(script)
  })
  return googleMapsPromise
}

export default function FoodMap({ cart, setCart, location: propLocation, setLocation: propSetLocation, address: propAddress, setAddress: propSetAddress }) {
  const mapContainerRef = useRef(null)
  const mapRef          = useRef(null)
  const markersRef      = useRef([])
  const userMarkerRef   = useRef(null)
  const infoWindowRef   = useRef(null)
  const [mapReady, setMapReady]       = useState(false)
  const [mapError, setMapError]       = useState('')

  // Use shared location from App if provided, fall back to local state
  const [localAddress, setLocalAddress] = useState(propAddress || '')
  const [localLocation, setLocalLocation] = useState(propLocation || null)

  // Keep in sync with prop changes (e.g. location set from Meal Planner)
  const address  = propAddress  !== undefined ? propAddress  : localAddress
  const location = propLocation !== undefined ? propLocation : localLocation

  const setAddress = (val) => {
    setLocalAddress(val)
    if (propSetAddress) propSetAddress(val)
  }
  const setLocation = (val) => {
    setLocalLocation(val)
    if (propSetLocation) propSetLocation(val)
  }
  const [searching, setSearching]       = useState(false)
  const [error, setError]               = useState('')
  const [ebtOnly, setEbtOnly]           = useState(false)
  const [selectedStore, setSelectedStore] = useState(null)
  const [showCompare, setShowCompare]   = useState(false)
  const [compareItems, setCompareItems] = useState([
    'Milk (1 gal)', 'Eggs (dozen)', 'Bread', 'Chicken breast (1lb)', 'Spinach',
  ])
  const [newItem, setNewItem] = useState('')
  const [suggestions, setSuggestions]   = useState([])
  const [sugOpen, setSugOpen]           = useState(false)
  const [sugHighlight, setSugHighlight] = useState(0)
  const autocompleteRef = useRef(null)
  const searchWrapRef   = useRef(null)

  // ── Load Google Maps + init map ────────────────────────────────────
  useEffect(() => {
    loadGoogleMaps()
      .then(() => {
        if (!mapContainerRef.current) return
        if (mapRef.current) return

        const map = new window.google.maps.Map(mapContainerRef.current, {
          center:            { lat: 39.5, lng: -98.35 },
          zoom:              4,
          mapTypeControl:    false,
          fullscreenControl: false,
          streetViewControl: false,
          styles: [
            { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
          ],
        })

        infoWindowRef.current = new window.google.maps.InfoWindow()
        mapRef.current        = map
        setMapReady(true)
      })
      .catch(err => {
        console.error(err)
        setMapError('Google Maps failed to load. Check your API key.')
      })
  }, [])

  // ── Autocomplete suggestions for address search ─────────────────────
  useEffect(() => {
    if (!mapReady) return
    autocompleteRef.current = new window.google.maps.places.AutocompleteService()
  }, [mapReady])

  const fetchSuggestions = (val) => {
    if (!val.trim() || !autocompleteRef.current) { setSuggestions([]); return }
    autocompleteRef.current.getPlacePredictions(
      { input: val, componentRestrictions: { country: 'us' }, types: ['geocode', 'establishment'] },
      (predictions, status) => {
        if (status === 'OK' && predictions) {
          setSuggestions(predictions.map(p => p.description))
          setSugOpen(true)
          setSugHighlight(0)
        } else {
          setSuggestions([])
        }
      }
    )
  }

  // Close suggestion dropdown when clicking outside
  useEffect(() => {
    const handler = (e) => {
      if (searchWrapRef.current && !searchWrapRef.current.contains(e.target)) {
        setSugOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  // ── Store query ────────────────────────────────────────────────────
  const { data, isLoading } = useQuery({
    queryKey: ['stores', location?.lat, location?.lng, ebtOnly],
    queryFn:  () => fetchStores({ lat: location.lat, lng: location.lng, radius: 8000, ebt: ebtOnly }),
    enabled:  !!location && mapReady,
  })

  // ── Pan to user + blue dot ─────────────────────────────────────────
  useEffect(() => {
    if (!location || !mapRef.current) return
    const pos = { lat: location.lat, lng: location.lng }
    mapRef.current.panTo(pos)
    mapRef.current.setZoom(13)

    if (userMarkerRef.current) userMarkerRef.current.setMap(null)
    userMarkerRef.current = new window.google.maps.Marker({
      position: pos,
      map:      mapRef.current,
      title:    'Your Location',
      icon: {
        path:          window.google.maps.SymbolPath.CIRCLE,
        scale:         10,
        fillColor:     '#1b4332',
        fillOpacity:   1,
        strokeColor:   '#ffffff',
        strokeWeight:  3,
      },
    })
  }, [location, mapReady])

  // ── Drop store markers ─────────────────────────────────────────────
  useEffect(() => {
    if (!mapRef.current || !data?.stores) return

    // Clear old markers
    markersRef.current.forEach(m => m.setMap(null))
    markersRef.current = []

    data.stores.forEach(store => {
      if (!store.lat || !store.lng) return

      const color = SCORE_COLOR(store.nutritionScore || 65)
      const score = store.nutritionScore || '?'

      // Custom colored label marker
      const marker = new window.google.maps.Marker({
        position: { lat: store.lat, lng: store.lng },
        map:      mapRef.current,
        title:    store.name,
        icon: {
          url: `data:image/svg+xml;utf8,${encodeURIComponent(`
            <svg xmlns="http://www.w3.org/2000/svg" width="44" height="28">
              <rect width="44" height="28" rx="5" fill="${color}" stroke="white" stroke-width="2"/>
              <text x="22" y="19" font-family="Arial,sans-serif" font-size="12" font-weight="bold"
                fill="white" text-anchor="middle">${score}</text>
            </svg>
          `)}`,
          scaledSize: new window.google.maps.Size(44, 28),
          anchor:     new window.google.maps.Point(22, 14),
        },
      })

      marker.addListener('click', () => {
        setSelectedStore(store)

        const distMi = store.distance
          ? `${(store.distance / 1609.34).toFixed(1)} mi away`
          : ''

        infoWindowRef.current.setContent(`
          <div style="font-family:system-ui,sans-serif;min-width:200px;padding:4px 2px">
            <p style="font-weight:700;font-size:14px;margin:0 0 4px;color:#1b4332">${store.name}</p>
            <p style="color:#555;font-size:12px;margin:0 0 8px">${store.address}</p>
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:6px">
              <span style="background:${color};color:white;padding:2px 10px;border-radius:99px;font-size:11px;font-weight:600">
                Score: ${score}/100
              </span>
              ${store.acceptsEBT ? '<span style="background:#1b4332;color:white;padding:2px 10px;border-radius:99px;font-size:11px">EBT accepted</span>' : ''}
              ${store.isFree     ? '<span style="background:#40916c;color:white;padding:2px 10px;border-radius:99px;font-size:11px">Free</span>' : ''}
            </div>
            ${store.rating ? `<p style="color:#888;font-size:12px;margin:0 0 2px">${store.rating} stars (${store.ratingCount?.toLocaleString() || 0} reviews)</p>` : ''}
            ${store.openNow !== null ? `<p style="font-size:12px;color:${store.openNow ? '#2d6a4f' : '#dc2626'};margin:0 0 4px">${store.openNow ? 'Open now' : 'Closed now'}</p>` : ''}
            ${distMi ? `<p style="color:#aaa;font-size:11px;margin:0">${distMi}</p>` : ''}
          </div>
        `)
        infoWindowRef.current.open(mapRef.current, marker)
      })

      markersRef.current.push(marker)
    })
  }, [data, mapReady])

  // ── Pan to selected store ──────────────────────────────────────────
  useEffect(() => {
    if (selectedStore && mapRef.current) {
      mapRef.current.panTo({ lat: selectedStore.lat, lng: selectedStore.lng })
      mapRef.current.setZoom(15)
    }
  }, [selectedStore])

  // ── Address search using Google Geocoding ──────────────────────────
  const handleSearch = async (e) => {
    e.preventDefault()
    if (!address.trim() || !mapReady) return
    setSearching(true); setError('')

    try {
      const geocoder = new window.google.maps.Geocoder()
      geocoder.geocode(
        { address, componentRestrictions: { country: 'US' } },
        (results, status) => {
          if (status === 'OK' && results[0]) {
            const loc = results[0].geometry.location
            setLocation({
              lat:         loc.lat(),
              lng:         loc.lng(),
              displayName: results[0].formatted_address,
            })
          } else {
            setError('Address not found. Try including city and state.')
          }
          setSearching(false)
        }
      )
    } catch {
      setError('Geocoding failed.')
      setSearching(false)
    }
  }

  const handleGPS = () => {
    if (!navigator.geolocation) { setError('GPS not available.'); return }
    setSearching(true)
    navigator.geolocation.getCurrentPosition(
      pos => {
        setLocation({
          lat:         pos.coords.latitude,
          lng:         pos.coords.longitude,
          displayName: 'Your Location',
        })
        setSearching(false)
      },
      () => { setError('Could not get your location.'); setSearching(false) }
    )
  }

  const addCompareItem = () => {
    const t = newItem.trim()
    if (t && !compareItems.includes(t)) { setCompareItems(c => [...c, t]); setNewItem('') }
  }

  const stores     = data?.stores || []
  const storeTotal = s => compareItems.reduce((sum, item) => sum + getPrice(item, s.name), 0)

  // ── Render ─────────────────────────────────────────────────────────
  return (
    <div style={{ height: 'calc(100vh - 64px)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* Search bar */}
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '10px 16px', display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', flexShrink: 0 }}>
        <form onSubmit={handleSearch} style={{ display: 'flex', gap: 8, flex: 1, minWidth: 200 }}>
          <div ref={searchWrapRef} style={{ flex: 1, position: 'relative' }}>
            <input
              className="bb-input"
              placeholder="Enter US city, address, or zip code..."
              value={address}
              onChange={e => {
                setAddress(e.target.value)
                fetchSuggestions(e.target.value)
              }}
              onKeyDown={e => {
                if (!sugOpen || suggestions.length === 0) return
                if (e.key === 'ArrowDown') { e.preventDefault(); setSugHighlight(h => Math.min(h+1, suggestions.length-1)) }
                else if (e.key === 'ArrowUp') { e.preventDefault(); setSugHighlight(h => Math.max(h-1, 0)) }
                else if (e.key === 'Enter') { e.preventDefault(); setAddress(suggestions[sugHighlight]); setSugOpen(false) }
                else if (e.key === 'Escape') setSugOpen(false)
              }}
              onFocus={() => suggestions.length > 0 && setSugOpen(true)}
              autoComplete="off"
              style={{ width: '100%' }}
            />
            {sugOpen && suggestions.length > 0 && (
              <div style={{
                position: 'absolute', top: 'calc(100% + 4px)', left: 0, right: 0, zIndex: 9999,
                background: 'var(--white)', border: '1.5px solid var(--teal)', borderRadius: 'var(--radius-md)',
                boxShadow: '0 8px 24px rgba(0,0,0,0.13)', overflow: 'hidden', maxHeight: 260, overflowY: 'auto'
              }}>
                {suggestions.map((sug, i) => (
                  <div
                    key={sug}
                    onMouseDown={() => { setAddress(sug); setSugOpen(false) }}
                    onMouseEnter={() => setSugHighlight(i)}
                    style={{
                      padding: '9px 14px', cursor: 'pointer', fontSize: 13,
                      background: i === sugHighlight ? 'var(--sage-pale)' : 'var(--white)',
                      borderBottom: i < suggestions.length-1 ? '1px solid var(--border)' : 'none',
                      color: 'var(--slate)', display: 'flex', alignItems: 'center', gap: 8
                    }}>
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{flexShrink:0}}>
                      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/>
                    </svg>
                    {sug}
                  </div>
                ))}
              </div>
            )}
          </div>
          <button className="bb-btn bb-btn--primary" type="submit"
            disabled={searching || !mapReady}
            style={{ padding: '9px 18px', whiteSpace: 'nowrap', flexShrink: 0 }}>
            {searching ? 'Searching...' : 'Search'}
          </button>
        </form>
        <button className="bb-btn bb-btn--soft" onClick={handleGPS} disabled={searching}
          style={{ padding: '9px 14px', whiteSpace: 'nowrap' }}>
          Use My Location
        </button>
        <button
          className={`bb-btn ${ebtOnly ? 'bb-btn--primary' : 'bb-btn--soft'}`}
          onClick={() => setEbtOnly(e => !e)}
          style={{ padding: '9px 14px', whiteSpace: 'nowrap', fontSize: 13 }}>
          {ebtOnly ? 'EBT Only (on)' : 'EBT Only'}
        </button>
        <button
          className={`bb-btn ${showCompare ? 'bb-btn--primary' : 'bb-btn--soft'}`}
          onClick={() => setShowCompare(s => !s)}
          style={{ padding: '9px 14px', whiteSpace: 'nowrap', fontSize: 13 }}>
          Price Compare
        </button>

        {(error || mapError) && (
          <span style={{ color: '#dc2626', fontSize: 13, width: '100%' }}>{error || mapError}</span>
        )}
        {location && (
          <span style={{ fontSize: 12, color: 'var(--teal-dark)', width: '100%' }}>
            Showing results near: {location.displayName}
          </span>
        )}
      </div>

      {/* Price compare panel */}
      {showCompare && (
        <div style={{ background: 'var(--sage-pale)', borderBottom: '1px solid var(--border)', padding: '14px 16px', overflowX: 'auto', flexShrink: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 style={{ fontWeight: 700, color: 'var(--forest-deep)', fontSize: 15 }}>Price Comparison by Store</h3>
          </div>

          {stores.length === 0
            ? <p style={{ color: 'var(--slate-light)', fontSize: 13 }}>Search a location to compare prices.</p>
            : (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, minWidth: 500 }}>
                  <thead>
                    <tr style={{ background: 'var(--white)' }}>
                      <th style={{ padding: '8px 12px', textAlign: 'left', fontWeight: 700, color: 'var(--forest-deep)', borderBottom: '2px solid var(--border)' }}>Item</th>
                      {stores.slice(0, 5).map(s => (
                        <th key={s.id} style={{ padding: '8px 10px', textAlign: 'center', fontWeight: 600, color: 'var(--forest)', borderBottom: '2px solid var(--border)', fontSize: 12 }}>
                          {s.name}
                          {s.acceptsEBT && <div style={{ fontSize: 10, color: 'var(--teal-dark)', fontWeight: 400 }}>EBT accepted</div>}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {compareItems.map((item, ri) => {
                      const prices = stores.slice(0, 5).map(s => getPrice(item, s.name))
                      const minP   = Math.min(...prices)
                      return (
                        <tr key={item} style={{ background: ri % 2 === 0 ? 'var(--white)' : 'transparent' }}>
                          <td style={{ padding: '8px 12px', color: 'var(--slate)' }}>
                            {item}
                            <button onClick={() => setCompareItems(c => c.filter(i => i !== item))}
                              style={{ marginLeft: 8, color: 'var(--slate-light)', fontSize: 11, cursor: 'pointer', background: 'none', border: 'none' }}>
                              remove
                            </button>
                          </td>
                          {prices.map((p, pi) => (
                            <td key={pi} style={{ padding: '8px 10px', textAlign: 'center',
                              background: p === minP ? 'rgba(82,183,136,0.12)' : 'transparent',
                              fontWeight: p === minP ? 700 : 400,
                              color: p === minP ? 'var(--forest)' : 'var(--slate)' }}>
                              ${p}
                              {p === minP && <div style={{ fontSize: 10, color: 'var(--teal)' }}>best price</div>}
                            </td>
                          ))}
                        </tr>
                      )
                    })}
                    <tr style={{ background: 'var(--sage-pale)', fontWeight: 700 }}>
                      <td style={{ padding: '10px 12px', color: 'var(--forest-deep)' }}>Total</td>
                      {stores.slice(0, 5).map(s => {
                        const total  = storeTotal(s)
                        const allT   = stores.slice(0, 5).map(x => storeTotal(x))
                        const isBest = total === Math.min(...allT)
                        return (
                          <td key={s.id} style={{ padding: '10px', textAlign: 'center',
                            color: isBest ? 'var(--forest)' : 'var(--slate)',
                            background: isBest ? 'rgba(82,183,136,0.18)' : 'transparent' }}>
                            ${total.toFixed(2)}
                            {isBest && <div style={{ fontSize: 10, color: 'var(--teal-dark)' }}>lowest total</div>}
                          </td>
                        )
                      })}
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
        </div>
      )}

      {/* Map + Store list */}
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>

        {/* Google Map container */}
        <div style={{ flex: 1, position: 'relative', padding: 12, minWidth: 0 }}>
          <div
            ref={mapContainerRef}
            style={{
              width:        '100%',
              height:       '100%',
              minHeight:    400,
              borderRadius: 'var(--radius-lg)',
              boxShadow:    'var(--shadow-md)',
              overflow:     'hidden',
            }}
          />

          {/* Loading overlay */}
          {isLoading && (
            <div style={{ position: 'absolute', top: 12, left: 12, right: 12, bottom: 12,
              background: 'rgba(255,255,255,0.75)', display: 'flex', alignItems: 'center',
              justifyContent: 'center', borderRadius: 'var(--radius-lg)', zIndex: 10 }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontWeight: 600, color: 'var(--forest)', fontSize: 14 }}>Finding stores...</div>
                <div style={{ color: 'var(--slate-light)', fontSize: 12, marginTop: 4 }}>Powered by Google Places</div>
              </div>
            </div>
          )}

          {/* No location prompt */}
          {!location && !mapError && (
            <div style={{ position: 'absolute', top: 12, left: 12, right: 12, bottom: 12,
              background: 'rgba(255,255,255,0.88)', display: 'flex', alignItems: 'center',
              justifyContent: 'center', borderRadius: 'var(--radius-lg)', zIndex: 10,
              pointerEvents: 'none' }}>
              <div style={{ textAlign: 'center', padding: 28, maxWidth: 320 }}>
                <h3 style={{ fontFamily: "'Fraunces',serif", fontSize: 22, color: 'var(--forest-deep)', marginBottom: 8 }}>
                  Enter a US location
                </h3>
                <p style={{ color: 'var(--slate-light)', fontSize: 14, lineHeight: 1.6 }}>
                  Search your city, address, or zip code above to find real grocery stores, SNAP retailers, and food banks nearby.
                </p>
              </div>
            </div>
          )}

          {/* Score legend */}
          {data?.stores?.length > 0 && (
            <div style={{ position: 'absolute', bottom: 24, left: 24, zIndex: 10,
              background: 'var(--white)', borderRadius: 'var(--radius-sm)',
              boxShadow: 'var(--shadow-md)', padding: '10px 14px', fontSize: 12 }}>
              <div style={{ fontWeight: 700, color: 'var(--forest-deep)', marginBottom: 6 }}>Nutrition Score</div>
              {[['#2d6a4f', '75+  High'], ['#d97706', '50-74  Medium'], ['#dc2626', 'Below 50  Low']].map(([c, l]) => (
                <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
                  <div style={{ width: 12, height: 8, borderRadius: 2, background: c, flexShrink: 0 }} />
                  <span style={{ color: 'var(--slate)' }}>{l}</span>
                </div>
              ))}
              <div style={{ borderTop: '1px solid var(--border)', marginTop: 6, paddingTop: 6, color: 'var(--slate-light)' }}>
                {data.stores.length} locations found
              </div>
            </div>
          )}
        </div>

        {/* Store list sidebar */}
        <div style={{ width: 340, flexShrink: 0, borderLeft: '1px solid var(--border)', overflowY: 'auto', background: 'var(--white)', display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: '12px 14px', borderBottom: '1px solid var(--border)', background: 'var(--sage-pale)', flexShrink: 0 }}>
            <div style={{ fontWeight: 700, color: 'var(--forest-deep)', fontSize: 14 }}>
              {stores.length > 0 ? `${stores.length} locations found` : 'No results yet'}
            </div>
            <div style={{ fontSize: 12, color: 'var(--slate-light)' }}>
              Ranked by nutrition score (highest first)
            </div>
          </div>

          {stores.length === 0 && location && !isLoading && (
            <div style={{ padding: 24, textAlign: 'center', color: 'var(--slate-light)' }}>
              <p style={{ fontSize: 14 }}>No stores found. Try a different location.</p>
            </div>
          )}

          {stores.map(store => (
            <div
              key={store.id}
              onClick={() => setSelectedStore(store)}
              style={{ padding: '12px 14px', borderBottom: '1px solid var(--border)', cursor: 'pointer',
                transition: 'background 0.15s',
                background: selectedStore?.id === store.id ? 'var(--sage-pale)' : 'var(--white)',
                borderLeft: `3px solid ${selectedStore?.id === store.id ? 'var(--teal)' : 'transparent'}` }}>

              <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--forest-deep)', marginBottom: 2 }}>
                    {store.name}
                  </div>
                  <p style={{ fontSize: 12, color: 'var(--slate-light)', marginBottom: 4 }}>
                    {store.address}
                  </p>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                    <span style={{ fontSize: 11, color: 'var(--slate-light)' }}>
                      {TYPE_LABEL[store.type] || 'Store'}
                    </span>
                    {store.distance != null && (
                      <span style={{ fontSize: 11, color: 'var(--slate-light)' }}>
                        {(store.distance / 1609.34).toFixed(1)} mi
                      </span>
                    )}
                    {store.rating && (
                      <span style={{ fontSize: 11, color: 'var(--slate-light)' }}>
                        {store.rating} stars
                      </span>
                    )}
                    {store.openNow === true  && <span className="bb-badge bb-badge--green"  style={{ fontSize: 10 }}>Open</span>}
                    {store.openNow === false && <span className="bb-badge bb-badge--orange" style={{ fontSize: 10 }}>Closed</span>}
                    {store.acceptsEBT && <span className="bb-badge bb-badge--teal" style={{ fontSize: 10 }}>EBT</span>}
                    {store.isFree     && <span className="bb-badge bb-badge--green" style={{ fontSize: 10 }}>Free</span>}
                  </div>
                </div>

                {/* Score badge */}
                <div style={{ width: 44, height: 44, borderRadius: 'var(--radius-sm)', flexShrink: 0,
                  border: `2px solid ${SCORE_COLOR(store.nutritionScore)}`,
                  display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                  background: 'var(--sage-pale)' }}>
                  <span style={{ fontWeight: 800, fontSize: 15, color: SCORE_COLOR(store.nutritionScore), lineHeight: 1 }}>
                    {store.nutritionScore || '?'}
                  </span>
                  <span style={{ fontSize: 9, color: 'var(--slate-light)' }}>score</span>
                </div>
              </div>

              {/* Action buttons on selected */}
              {selectedStore?.id === store.id && (
                <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(store.name + ' ' + store.address)}&travelmode=driving`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bb-btn bb-btn--primary"
                    style={{ flex: 1, fontSize: 12, padding: '8px', textDecoration: 'none', textAlign: 'center' }}
                    onClick={e => e.stopPropagation()}>
                    Get Directions
                  </a>
                  <button
                    className="bb-btn bb-btn--soft"
                    style={{ flex: 1, fontSize: 12, padding: '8px' }}
                    onClick={e => { e.stopPropagation(); setShowCompare(true) }}>
                    Compare Prices
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
