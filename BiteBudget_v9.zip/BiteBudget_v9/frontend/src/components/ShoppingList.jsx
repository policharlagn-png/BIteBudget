// src/components/ShoppingList.jsx
import React, { useState, useRef, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { fetchStores, geocodeAddress } from '../utils/api.js'

// ── Large grocery item database for autocomplete ──────────────────────
const GROCERY_ITEMS = [
  // Fresh Produce
  "Apples", "Fuji apples", "Gala apples", "Granny Smith apples", "Honeycrisp apples",
  "Bananas", "Oranges", "Navel oranges", "Blood oranges", "Clementines", "Mandarins",
  "Grapes (red)", "Grapes (green)", "Grapes (black)", "Strawberries", "Blueberries",
  "Raspberries", "Blackberries", "Cranberries", "Cherries", "Pomegranate",
  "Lemons", "Limes", "Grapefruit", "Tangerines",
  "Avocados", "Hass avocados", "Tomatoes", "Cherry tomatoes", "Roma tomatoes",
  "Heirloom tomatoes", "Grape tomatoes", "Sun-dried tomatoes",
  "Broccoli", "Broccolini", "Cauliflower", "Romanesco", "Spinach", "Baby spinach",
  "Kale", "Curly kale", "Lacinato kale", "Swiss chard", "Arugula", "Watercress",
  "Romaine lettuce", "Iceberg lettuce", "Butter lettuce", "Mixed greens", "Spring mix",
  "Cabbage (green)", "Cabbage (red)", "Napa cabbage", "Bok choy", "Brussels sprouts",
  "Carrots", "Baby carrots", "Celery", "Cucumbers", "Persian cucumbers", "English cucumber",
  "Zucchini", "Yellow squash", "Butternut squash", "Acorn squash", "Spaghetti squash",
  "Bell peppers (red)", "Bell peppers (green)", "Bell peppers (yellow)", "Bell peppers (orange)",
  "Jalapenos", "Serrano peppers", "Habanero peppers", "Anaheim peppers", "Poblano peppers",
  "Red onion", "Yellow onion", "White onion", "Green onions", "Shallots", "Leeks",
  "Garlic", "Garlic (minced jar)", "Ginger root", "Turmeric root",
  "Sweet potatoes", "Russet potatoes", "Red potatoes", "Yukon gold potatoes",
  "Fingerling potatoes", "Purple potatoes",
  "Corn", "Corn on the cob", "Green beans", "Asparagus", "Sugar snap peas", "Snow peas",
  "Edamame (fresh)", "Artichokes", "Beets", "Turnips", "Parsnips", "Radishes",
  "Mushrooms (white)", "Mushrooms (cremini)", "Mushrooms (portobello)", "Shiitake mushrooms",
  "Oyster mushrooms", "Chanterelle mushrooms",
  "Pineapple", "Mango", "Peaches", "Nectarines", "Pears", "Bartlett pears", "Bosc pears",
  "Plums", "Apricots", "Figs", "Dates", "Kiwi", "Papaya", "Guava", "Starfruit",
  "Watermelon", "Cantaloupe", "Honeydew melon",
  "Rhubarb", "Plantains", "Jackfruit", "Dragon fruit", "Lychee",
  // Herbs
  "Fresh basil", "Fresh cilantro", "Fresh parsley", "Fresh rosemary", "Fresh thyme",
  "Fresh mint", "Fresh dill", "Fresh chives", "Fresh sage", "Fresh tarragon",
  "Fresh oregano", "Fresh lemongrass",
  // Dairy & Eggs
  "Milk (whole)", "Milk (2%)", "Milk (skim)", "Milk (1%)", "Lactaid whole milk",
  "Almond milk", "Oat milk (Oatly)", "Oat milk (Califia)", "Soy milk",
  "Cashew milk", "Pea milk (Ripple)",
  "Eggs (dozen)", "Eggs (18 ct)", "Eggs (cage-free)", "Eggs (organic)", "Egg whites (carton)",
  "Butter (salted)", "Butter (unsalted)", "Kerrygold butter", "Land O Lakes butter",
  "Margarine", "Ghee", "Vegan butter (Earth Balance)",
  "Heavy cream", "Heavy whipping cream", "Half and half", "Coffee creamer",
  "International Delight creamer", "Coffee-Mate creamer",
  "Shredded cheddar", "Shredded mozzarella", "Shredded Mexican blend",
  "Shredded Colby-Jack", "Shredded Parmesan", "Parmesan (block)", "Parmigiano-Reggiano",
  "Cream cheese", "Philadelphia cream cheese", "Neufchatel cream cheese",
  "Ricotta cheese", "Feta cheese", "Goat cheese", "Brie", "Camembert", "Gouda",
  "Swiss cheese", "Provolone", "American cheese", "Havarti", "Manchego",
  "Cheddar (block)", "Sharp cheddar", "Colby Jack (block)", "Pepper Jack",
  "String cheese", "Babybel cheese", "Laughing Cow wedges",
  "Sour cream", "Daisy sour cream",
  "Greek yogurt (Chobani plain)", "Greek yogurt (Fage 0%)", "Greek yogurt (Fage 2%)",
  "Greek yogurt (Fage 5%)", "Greek yogurt (Oikos)", "Greek yogurt (Stonyfield)", "Siggi yogurt",
  "Regular yogurt (Yoplait)", "Regular yogurt (Dannon)", "Activia yogurt",
  "Skyr (Icelandic Provisions)", "Kefir", "Cottage cheese", "Good Culture cottage cheese",
  "Whipped cream (Reddi Whip)", "Cool Whip",
  // Meat & Seafood
  "Chicken breast (boneless)", "Chicken thighs (boneless)", "Chicken thighs (bone-in)",
  "Chicken drumsticks", "Chicken wings", "Whole rotisserie chicken", "Ground chicken",
  "Ground beef (80/20)", "Ground beef (90/10)", "Ground beef (93/7)", "Ground beef (85/15)",
  "Beef sirloin steak", "Beef ribeye steak", "Beef NY strip", "Beef flank steak",
  "Beef skirt steak", "Beef chuck roast", "Beef stew meat", "Beef short ribs",
  "Pork chops (boneless)", "Pork chops (bone-in)", "Pork tenderloin", "Pork shoulder",
  "Pork ribs", "Ground pork", "Italian sausage", "Andouille sausage",
  "Bacon (Oscar Mayer)", "Bacon (Applegate)", "Bacon (thick-cut)", "Turkey bacon",
  "Ham (deli)", "Ham (whole)", "Canadian bacon", "Prosciutto", "Pancetta",
  "Hot dogs (Nathan Famous)", "Hot dogs (Ball Park)",
  "Salmon fillet (Atlantic)", "Salmon fillet (sockeye)", "Tilapia", "Cod", "Halibut",
  "Mahi-mahi", "Swordfish", "Trout", "Sea bass", "Snapper", "Catfish", "Flounder",
  "Shrimp (frozen, large)", "Shrimp (frozen, jumbo)", "Scallops", "Lobster tail",
  "Crab legs", "Clams", "Mussels", "Oysters",
  "Canned tuna (Starkist)", "Canned tuna (Bumble Bee)", "Canned tuna (Wild Planet)",
  "Canned salmon (Wild Planet)", "Canned sardines", "Canned mackerel", "Canned anchovies",
  "Turkey breast (boneless)", "Ground turkey (93/7)", "Ground turkey (85/15)",
  "Turkey sausage", "Turkey hot dogs",
  "Deli turkey (Boars Head)", "Deli turkey (Land O Lakes)", "Deli ham (Boars Head)",
  "Deli salami", "Deli pepperoni", "Deli roast beef",
  "Lamb chops", "Ground lamb", "Venison", "Bison ground", "Duck breast",
  "Tofu (firm)", "Tofu (extra firm)", "Tofu (silken)", "Tempeh", "Seitan",
  "Beyond Burger", "Impossible Burger", "Morning Star veggie burgers",
  // Bakery & Bread
  "Daves Killer Bread (whole wheat)", "Natures Own whole wheat bread",
  "Wonder white bread", "Sara Lee white bread", "White sandwich bread",
  "Sourdough bread", "Sourdough boule", "Rye bread", "Pumpernickel",
  "Multigrain bread", "Potato bread", "Brioche", "Ciabatta", "Focaccia",
  "Hamburger buns", "Brioche buns", "Potato buns", "Hot dog buns", "Slider buns",
  "Dinner rolls", "Kings Hawaiian rolls", "Croissants", "Baguette",
  "Thomas bagels (plain)", "Thomas bagels (everything)", "Thomas bagels (sesame)",
  "Thomas English muffins", "English muffins (plain)",
  "Mission flour tortillas", "Old El Paso flour tortillas",
  "Corn tortillas", "Whole wheat tortillas", "Mission Carb Balance tortillas",
  "Pita bread", "Naan", "Flatbread", "Lavash", "Pita chips",
  // Pantry & Dry Goods
  "Brown rice", "White rice", "Jasmine rice", "Basmati rice", "Wild rice blend",
  "Cauliflower rice (frozen)", "Minute rice (instant)",
  "Quaker rolled oats", "Bobs Red Mill steel cut oats", "Quaker instant oatmeal",
  "Overnight oats mix",
  "Whole wheat pasta", "Barilla spaghetti", "Barilla penne", "Fettuccine",
  "Rotini", "Elbow macaroni", "Rigatoni", "Farfalle", "Linguine", "Angel hair",
  "Orzo", "Gnocchi", "Egg noodles", "Ramen noodles", "Udon noodles", "Rice noodles",
  "Soba noodles", "Pad Thai noodles", "Chickpea pasta", "Lentil pasta", "Protein pasta",
  "Quinoa (Bobs Red Mill)", "Ancient Harvest quinoa", "Bulgur wheat", "Farro", "Freekeh",
  "Barley", "Millet", "Polenta", "Cornmeal", "Grits",
  "Lentils (red)", "Lentils (green)", "Lentils (French)", "Split peas",
  "Chickpeas (canned)", "Black beans (canned)", "Pinto beans (canned)",
  "Kidney beans (canned)", "White cannellini beans", "Navy beans",
  "Great Northern beans", "Lima beans", "Black-eyed peas", "Refried beans (canned)",
  "Hunts canned tomatoes", "Muir Glen canned tomatoes", "Diced tomatoes",
  "Crushed tomatoes", "Whole peeled tomatoes", "Fire-roasted tomatoes",
  "Tomato paste", "Tomato sauce", "Raos marinara sauce", "Prego marinara sauce",
  "Classico pasta sauce", "Arrabiata sauce", "Buitoni pesto", "Alfredo sauce",
  "Pace salsa", "Tostitos salsa", "Salsa verde",
  "Swanson chicken broth", "Kitchen Basics beef broth", "Pacific vegetable broth",
  "Kettle and Fire bone broth", "Thai Kitchen coconut milk (canned)", "Coconut cream",
  "California Olive Ranch olive oil", "Extra virgin olive oil", "Light olive oil",
  "Vegetable oil", "Canola oil", "Chosen Foods avocado oil", "Nutiva coconut oil",
  "Sesame oil", "Peanut oil", "Grapeseed oil", "Sunflower oil",
  "Kikkoman soy sauce", "Low-sodium soy sauce", "San-J tamari", "Coconut aminos",
  "Worcestershire sauce", "Fish sauce", "Oyster sauce", "Hoisin sauce",
  "Tabasco hot sauce", "Franks RedHot sauce", "Huy Fong Sriracha",
  "Gochujang", "Sambal oelek", "Chili garlic sauce",
  "Heinz ketchup", "French yellow mustard", "Dijon mustard", "Whole grain mustard",
  "Hellmanns mayonnaise", "Dukes mayo", "Primal Kitchen avocado mayo",
  "Hidden Valley ranch dressing", "Caesar dressing", "Wishbone Italian dressing",
  "Balsamic vinaigrette", "Balsamic vinegar", "Braggs apple cider vinegar",
  "Red wine vinegar", "White wine vinegar", "Rice vinegar",
  "Local honey", "Nates honey", "Pure maple syrup (grade A)",
  "Agave nectar", "Molasses", "Corn syrup", "Simple syrup",
  "C and H sugar", "Brown sugar", "Dark brown sugar", "Powdered sugar",
  "Lakanto monk fruit sweetener", "Truvia stevia", "Splenda", "Erythritol",
  "Gold Medal all-purpose flour", "King Arthur bread flour",
  "King Arthur whole wheat flour", "Bobs Red Mill almond flour",
  "Coconut flour", "Oat flour", "Cup4Cup gluten-free flour",
  "Baking powder", "Baking soda", "Active dry yeast", "Instant yeast",
  "Cornstarch", "Arrowroot powder", "Xanthan gum",
  "McCormick vanilla extract", "Pure vanilla extract", "Vanilla bean paste",
  "Almond extract", "Peppermint extract",
  "Hersheys cocoa powder", "Dutch cocoa powder", "Cacao powder",
  "Nestle Toll House chocolate chips", "Ghirardelli dark chocolate chips",
  "Unsweetened baking chocolate", "Semi-sweet chocolate bar",
  "Jif peanut butter", "Skippy peanut butter", "Smuckers natural peanut butter",
  "Justins almond butter", "Cashew butter", "SunButter sunflower butter",
  "Tahini", "Pumpkin seed butter",
  "Smuckers strawberry jam", "Grape jelly", "Raspberry jam", "Blueberry jam",
  "Orange marmalade", "Honey butter", "Nutella", "Biscoff cookie butter",
  // Canned & Jarred
  "Canned corn", "Canned green beans", "Canned peas", "Libbys canned pumpkin",
  "Canned beets", "Canned artichoke hearts", "Canned roasted red peppers",
  "Black olives (canned)", "Kalamata olives", "Green olives", "Capers",
  "Campbells tomato soup", "Progresso soup", "Campbells chicken noodle soup",
  "Dinty Moore beef stew", "Kraft mac and cheese", "SpaghettiOs", "Chef Boyardee ravioli",
  // Condiments & Sauces
  "Sweet Baby Rays BBQ sauce", "Stubbs BBQ sauce", "Kikkoman teriyaki sauce",
  "Franks buffalo sauce", "A1 steak sauce", "Sabra hummus", "Hope hummus",
  "Guacamole", "Chimichurri", "Tahini sauce", "Enchilada sauce", "Taco sauce", "Mole sauce",
  // Spices & Seasonings
  "Morton salt", "Diamond Crystal kosher salt", "Sea salt", "Himalayan pink salt",
  "Black pepper", "White pepper", "Red pepper flakes", "Cayenne pepper",
  "Garlic powder", "Onion powder", "Smoked paprika", "Sweet paprika",
  "Cumin", "Coriander", "Turmeric", "Cinnamon", "Nutmeg", "Allspice", "Cloves",
  "Oregano (dried)", "Thyme (dried)", "Rosemary (dried)", "Basil (dried)",
  "Bay leaves", "Dill (dried)", "Tarragon (dried)", "Sage (dried)",
  "Italian seasoning", "Herbs de Provence", "Everything bagel seasoning",
  "Old Bay seasoning", "Cajun seasoning", "McCormick taco seasoning",
  "Chili powder", "Curry powder", "Garam masala", "Zaatar",
  "McCormick Montreal steak seasoning", "Lawrys seasoned salt",
  "Lemon pepper seasoning", "Ranch seasoning mix", "Onion soup mix",
  // Snacks
  "Chewy granola bars", "Kind granola bars", "Clif bars", "Larabar",
  "Quest protein bars", "RXBar protein bars", "Kind Protein bars",
  "Nature Valley granola bars", "Fiber One bars",
  "Trail mix", "Planters mixed nuts", "Blue Diamond almonds",
  "Planters cashews", "Walnuts", "Pecans", "Macadamia nuts", "Brazil nuts",
  "Wonderful pistachios", "Sunflower seeds", "Pumpkin seeds (pepitas)",
  "Roasted chickpeas", "Edamame (roasted)",
  "Tostitos tortilla chips", "Mission tortilla chips", "Doritos Nacho Cheese",
  "Doritos Cool Ranch", "Fritos", "Lays potato chips", "Kettle chips",
  "Pringles", "Ruffles", "SunChips", "Baked Lays",
  "Snyders pretzels", "Pretzel crisps", "Pretzel nuggets",
  "Orville Redenbacher popcorn", "SkinnyPop popcorn", "Boom Chicka Pop",
  "Quaker rice cakes (plain)", "Quaker rice cakes (cheddar)",
  "Ritz crackers", "Triscuit crackers", "Wheat Thins", "Cheez-Its",
  "Goldfish crackers", "Animal crackers", "Honey Maid graham crackers",
  "Saltines", "Oyster crackers", "Stacys pita chips", "Veggie straws", "Snap pea crisps",
  "Jack Links beef jerky", "Turkey jerky", "Epic meat bars",
  "Rice Krispies treats", "Welchs fruit snacks", "Fruit by the Foot",
  "Gushers", "Sun-Maid raisins", "Ocean Spray Craisins",
  "Dried mango", "Dried apricots", "Dried blueberries", "Fruit leather",
  "Lindt 70% dark chocolate", "Green and Blacks dark chocolate",
  "Hersheys milk chocolate", "Kit Kat", "Snickers", "Reeses cups",
  "M&Ms", "Skittles", "Sour Patch Kids", "Haribo gummy bears",
  // Cereal & Breakfast
  "Cheerios", "Honey Nut Cheerios", "Multi Grain Cheerios",
  "Frosted Flakes", "Corn Flakes", "Special K",
  "Raisin Bran", "Raisin Bran Crunch", "Grape Nuts",
  "Wheaties", "Total cereal", "Life cereal", "Cap n Crunch",
  "Lucky Charms", "Froot Loops", "Cocoa Puffs", "Cinnamon Toast Crunch",
  "Nature Valley granola", "Bobs Red Mill granola", "Muesli",
  "Quaker instant oatmeal", "Cream of Wheat", "Quick cooking grits",
  "Eggo waffles", "Bisquick pancake mix", "Krusteaz pancake mix",
  // Frozen Foods
  "Frozen broccoli", "Frozen spinach", "Frozen corn", "Frozen peas",
  "Frozen mixed vegetables", "Frozen edamame", "Frozen cauliflower",
  "Frozen green beans", "Frozen Brussels sprouts", "Frozen stir fry vegetables",
  "Frozen mixed berries", "Frozen blueberries", "Frozen strawberries",
  "Frozen mango chunks", "Frozen acai packets",
  "DiGiorno frozen pizza", "California Pizza Kitchen frozen pizza",
  "Amys frozen burritos", "El Monterey frozen burritos",
  "Lean Cuisine frozen meals", "Stouffers frozen meals", "Frozen lasagna",
  "Frozen chicken nuggets", "Gortons fish sticks",
  "Eggo frozen waffles", "Frozen pancakes", "Frozen french toast",
  "Ore-Ida tater tots", "Ore-Ida french fries",
  "Frozen hash browns", "Frozen sweet potato fries",
  "Haagen-Dazs ice cream", "Ben and Jerrys ice cream",
  "Breyers ice cream", "Frozen yogurt", "Sherbet", "Sorbet",
  "Klondike ice cream bars", "Outshine popsicles", "Fudge bars",
  "Kashi frozen waffles", "Morning Star veggie burgers (frozen)",
  // Beverages
  "Tropicana orange juice", "Simply Orange juice", "Motts apple juice",
  "Ocean Spray cranberry juice", "Welchs grape juice", "Pomegranate juice",
  "Simply Lemonade", "Limeade", "Apple cider",
  "Folgers ground coffee", "Maxwell House coffee", "Starbucks ground coffee",
  "Eight OClock coffee", "Dunkin ground coffee", "Lavazza coffee beans",
  "Nespresso pods", "Green Mountain K-cups", "Cold brew coffee",
  "Lipton tea bags", "Bigelow tea bags", "Celestial Seasonings green tea",
  "Chamomile tea", "Peppermint tea", "Earl Grey tea", "Chai tea bags",
  "LaCroix sparkling water", "Bubly sparkling water", "Topo Chico sparkling water",
  "Gatorade sports drink", "Powerade sports drink", "Vita Coco coconut water",
  "GTs Kombucha", "Lifeway kefir",
  "Coca-Cola", "Pepsi", "Sprite", "Diet Coke",
  "Red Bull energy drink", "Monster energy drink",
  // Deli & Prepared
  "Deli roasted chicken", "Prepared salads", "Soup (from deli)",
  "Pre-marinated chicken", "Pre-marinated steak",
  // Baby & Specialty
  "Similac baby formula", "Baby food puree", "Baby oatmeal cereal",
  "Gerber baby puffs", "Happy Baby toddler snacks",
]

const SUGGESTIONS = [...new Set(GROCERY_ITEMS)].sort()

// Chain multipliers for price estimation
const CHAIN_MULTS = {
  walmart: 0.82, aldi: 0.80, lidl: 0.81, kroger: 0.92,
  publix: 1.05, target: 0.97, costco: 0.85, "trader joe": 0.95,
  meijer: 0.91, "h-e-b": 0.88, wegmans: 1.04, safeway: 1.00,
  albertsons: 1.00, "whole foods": 1.30, sprouts: 1.18,
  "save-a-lot": 0.83, "food lion": 0.90, giant: 1.01,
  "market basket": 0.87, winco: 0.83, shoprite: 0.91,
  "stop and shop": 0.98, "harris teeter": 1.02, "hy-vee": 0.94,
}

function getStoreMult(name = '') {
  const lower = name.toLowerCase()
  for (const [key, mult] of Object.entries(CHAIN_MULTS)) {
    if (lower.includes(key)) return mult
  }
  return 1.0
}

// Items with known prices — ONLY these get price estimates
// Items NOT in this set will show no price (user-entered custom items)
const BASE_PRICES = {
  // Produce
  "Apples": 3.49, "Fuji apples": 3.99, "Gala apples": 3.79, "Honeycrisp apples": 5.99,
  "Bananas": 1.29, "Oranges": 3.99, "Clementines": 5.99, "Strawberries": 3.99,
  "Blueberries": 3.49, "Raspberries": 3.99, "Blackberries": 3.99, "Cherries": 5.99,
  "Lemons": 1.99, "Limes": 1.49, "Grapefruit": 1.49, "Avocados": 1.49, "Hass avocados": 1.69,
  "Tomatoes": 2.49, "Cherry tomatoes": 3.49, "Roma tomatoes": 1.99, "Grape tomatoes": 3.29,
  "Broccoli": 2.29, "Broccolini": 2.99, "Cauliflower": 3.49, "Spinach": 2.49, "Baby spinach": 3.99,
  "Kale": 2.49, "Curly kale": 2.49, "Swiss chard": 2.99, "Arugula": 3.49,
  "Romaine lettuce": 2.29, "Iceberg lettuce": 1.99, "Mixed greens": 3.99, "Spring mix": 3.99,
  "Cabbage (green)": 1.49, "Cabbage (red)": 1.99, "Bok choy": 1.99, "Brussels sprouts": 3.49,
  "Carrots": 1.49, "Baby carrots": 1.99, "Celery": 1.49, "Cucumbers": 1.29, "English cucumber": 1.99,
  "Zucchini": 1.49, "Yellow squash": 1.49, "Butternut squash": 3.49, "Spaghetti squash": 2.99,
  "Bell peppers (red)": 1.99, "Bell peppers (green)": 0.99, "Bell peppers (yellow)": 1.99,
  "Jalapenos": 0.99, "Red onion": 1.29, "Yellow onion": 1.49, "White onion": 1.29,
  "Green onions": 0.99, "Shallots": 1.99, "Garlic": 0.99, "Ginger root": 0.99,
  "Sweet potatoes": 3.49, "Russet potatoes": 3.99, "Red potatoes": 3.49, "Yukon gold potatoes": 3.99,
  "Corn": 0.79, "Green beans": 2.49, "Asparagus": 3.99, "Sugar snap peas": 2.99,
  "Mushrooms (white)": 2.99, "Mushrooms (cremini)": 3.49, "Mushrooms (portobello)": 3.99,
  "Pineapple": 3.49, "Mango": 1.49, "Peaches": 2.99, "Pears": 2.99, "Plums": 2.99,
  "Watermelon": 5.99, "Cantaloupe": 3.99, "Honeydew melon": 3.99, "Kiwi": 0.79, "Dates": 5.99,
  "Fresh basil": 2.49, "Fresh cilantro": 0.99, "Fresh parsley": 1.49, "Fresh rosemary": 1.99,
  // Dairy
  "Milk (whole)": 3.99, "Milk (2%)": 3.79, "Milk (skim)": 3.49, "Milk (1%)": 3.59,
  "Lactaid whole milk": 5.99, "Almond milk": 3.99, "Oat milk (Oatly)": 5.99,
  "Oat milk (Califia)": 5.49, "Soy milk": 3.49, "Cashew milk": 3.99, "Pea milk (Ripple)": 5.49,
  "Eggs (dozen)": 3.49, "Eggs (18 ct)": 5.29, "Eggs (cage-free)": 5.99, "Eggs (organic)": 6.99,
  "Egg whites (carton)": 3.99,
  "Butter (salted)": 4.99, "Butter (unsalted)": 4.99, "Kerrygold butter": 6.99,
  "Land O Lakes butter": 5.49, "Ghee": 9.99, "Vegan butter (Earth Balance)": 4.99,
  "Heavy cream": 2.99, "Heavy whipping cream": 3.49, "Half and half": 2.49,
  "Shredded cheddar": 3.99, "Shredded mozzarella": 3.49, "Shredded Mexican blend": 3.99,
  "Shredded Parmesan": 3.99, "Parmigiano-Reggiano": 8.99, "Cream cheese": 2.99,
  "Philadelphia cream cheese": 3.49, "Ricotta cheese": 3.49, "Feta cheese": 4.99,
  "Goat cheese": 4.99, "Brie": 6.99, "Gouda": 5.99, "Swiss cheese": 3.99,
  "Provolone": 3.99, "American cheese": 3.49, "Pepper Jack": 3.99, "Cheddar (block)": 4.99,
  "String cheese": 3.99, "Babybel cheese": 4.99, "Sour cream": 1.99,
  "Greek yogurt (Chobani plain)": 5.99, "Greek yogurt (Fage 0%)": 4.99,
  "Greek yogurt (Fage 2%)": 5.29, "Greek yogurt (Fage 5%)": 5.49,
  "Greek yogurt (Oikos)": 4.99, "Siggi yogurt": 2.49,
  "Regular yogurt (Yoplait)": 1.29, "Activia yogurt": 1.49, "Kefir": 4.99,
  "Cottage cheese": 3.49, "Good Culture cottage cheese": 5.99,
  // Meat
  "Chicken breast (boneless)": 4.99, "Chicken thighs (boneless)": 3.99,
  "Chicken thighs (bone-in)": 2.99, "Chicken drumsticks": 2.49, "Chicken wings": 5.99,
  "Whole rotisserie chicken": 7.99, "Ground chicken": 4.49,
  "Ground beef (80/20)": 5.49, "Ground beef (90/10)": 6.49, "Ground beef (93/7)": 6.99,
  "Beef sirloin steak": 9.99, "Beef ribeye steak": 14.99, "Beef NY strip": 12.99,
  "Beef flank steak": 8.99, "Beef chuck roast": 6.99, "Beef stew meat": 6.49,
  "Pork chops (boneless)": 4.49, "Pork tenderloin": 5.99, "Pork shoulder": 3.99,
  "Ground pork": 3.99, "Italian sausage": 4.99, "Andouille sausage": 4.99,
  "Bacon (Oscar Mayer)": 5.99, "Bacon (thick-cut)": 6.99, "Turkey bacon": 4.49,
  "Prosciutto": 7.99, "Ham (deli)": 4.99, "Canadian bacon": 4.49,
  "Hot dogs (Nathan Famous)": 4.99, "Hot dogs (Ball Park)": 3.99,
  "Salmon fillet (Atlantic)": 8.99, "Salmon fillet (sockeye)": 12.99,
  "Tilapia": 5.99, "Cod": 7.99, "Halibut": 14.99, "Mahi-mahi": 9.99, "Trout": 7.99,
  "Shrimp (frozen, large)": 9.99, "Shrimp (frozen, jumbo)": 12.99, "Scallops": 14.99,
  "Canned tuna (Starkist)": 1.49, "Canned tuna (Bumble Bee)": 1.59,
  "Canned tuna (Wild Planet)": 3.49, "Canned salmon (Wild Planet)": 4.99,
  "Canned sardines": 2.49, "Canned anchovies": 2.99,
  "Turkey breast (boneless)": 5.99, "Ground turkey (93/7)": 5.49,
  "Deli turkey (Boars Head)": 8.99, "Deli ham (Boars Head)": 8.49,
  "Tofu (firm)": 2.49, "Tofu (extra firm)": 2.49, "Tempeh": 3.99,
  "Beyond Burger": 6.99, "Impossible Burger": 7.99,
  // Bread
  "Daves Killer Bread (whole wheat)": 5.99, "Natures Own whole wheat bread": 3.49,
  "Wonder white bread": 3.29, "Sourdough bread": 3.99, "Rye bread": 3.99,
  "Hamburger buns": 2.49, "Brioche buns": 3.99, "Hot dog buns": 2.29,
  "Kings Hawaiian rolls": 3.99, "Croissants": 4.99,
  "Thomas bagels (plain)": 3.99, "Thomas English muffins": 3.49,
  "Mission flour tortillas": 2.99, "Corn tortillas": 2.49, "Pita bread": 2.99, "Naan": 3.49,
  // Pantry
  "Brown rice": 4.49, "White rice": 3.99, "Jasmine rice": 4.99, "Basmati rice": 5.49,
  "Quaker rolled oats": 3.99, "Bobs Red Mill steel cut oats": 4.99, "Quaker instant oatmeal": 3.99,
  "Barilla spaghetti": 1.49, "Barilla penne": 1.49, "Whole wheat pasta": 1.99,
  "Elbow macaroni": 1.49, "Fettuccine": 1.99, "Rotini": 1.49,
  "Quinoa (Bobs Red Mill)": 5.99, "Bulgur wheat": 2.99, "Farro": 4.99, "Barley": 2.49,
  "Black beans (canned)": 1.29, "Pinto beans (canned)": 1.29, "Chickpeas (canned)": 1.49,
  "Kidney beans (canned)": 1.29, "Lentils (red)": 1.99, "Lentils (green)": 1.99,
  "Refried beans (canned)": 1.49,
  "Hunts canned tomatoes": 1.49, "Muir Glen canned tomatoes": 2.49,
  "Diced tomatoes": 1.49, "Crushed tomatoes": 1.79, "Tomato paste": 0.99, "Tomato sauce": 1.29,
  "Raos marinara sauce": 8.99, "Prego marinara sauce": 2.99, "Classico pasta sauce": 3.49,
  "Buitoni pesto": 3.99, "Pace salsa": 3.49, "Tostitos salsa": 3.99,
  "Swanson chicken broth": 1.99, "Kitchen Basics beef broth": 2.49, "Pacific vegetable broth": 2.99,
  "Kettle and Fire bone broth": 7.99, "Thai Kitchen coconut milk (canned)": 1.99,
  "California Olive Ranch olive oil": 9.99, "Extra virgin olive oil": 8.99,
  "Olive oil": 6.99, "Chosen Foods avocado oil": 9.99, "Nutiva coconut oil": 8.99,
  "Sesame oil": 3.99, "Canola oil": 3.99, "Vegetable oil": 3.49,
  "Kikkoman soy sauce": 2.99, "Low-sodium soy sauce": 2.99, "San-J tamari": 4.49,
  "Coconut aminos": 5.99, "Fish sauce": 2.99, "Oyster sauce": 2.99, "Hoisin sauce": 2.49,
  "Tabasco hot sauce": 2.99, "Franks RedHot sauce": 3.49, "Huy Fong Sriracha": 3.99,
  "Heinz ketchup": 3.49, "French yellow mustard": 1.99, "Dijon mustard": 2.99,
  "Hellmanns mayonnaise": 4.99, "Dukes mayo": 4.49, "Primal Kitchen avocado mayo": 6.99,
  "Hidden Valley ranch dressing": 3.49, "Caesar dressing": 3.49, "Wishbone Italian dressing": 2.99,
  "Balsamic vinegar": 3.99, "Braggs apple cider vinegar": 4.99, "Red wine vinegar": 2.99,
  "Local honey": 4.99, "Nates honey": 8.99, "Pure maple syrup (grade A)": 8.99,
  "C and H sugar": 2.99, "Brown sugar": 2.49, "Powdered sugar": 1.99,
  "Gold Medal all-purpose flour": 3.99, "King Arthur bread flour": 5.99,
  "Bobs Red Mill almond flour": 7.99, "Coconut flour": 5.99,
  "Baking powder": 1.99, "Baking soda": 0.99, "Cornstarch": 1.49, "Vanilla extract": 4.99,
  "Hersheys cocoa powder": 3.49, "Cacao powder": 5.99,
  "Nestle Toll House chocolate chips": 3.99, "Ghirardelli dark chocolate chips": 4.99,
  "Jif peanut butter": 3.99, "Skippy peanut butter": 3.99, "Smuckers natural peanut butter": 3.49,
  "Justins almond butter": 9.99, "Cashew butter": 8.99, "Tahini": 5.99,
  "Smuckers strawberry jam": 2.99, "Grape jelly": 2.79, "Raspberry jam": 3.49,
  "Nutella": 4.49, "Biscoff cookie butter": 3.99,
  // Snacks
  "Kind granola bars": 6.99, "Clif bars": 5.99, "Larabar": 1.49,
  "Quest protein bars": 2.49, "RXBar protein bars": 2.49,
  "Nature Valley granola bars": 3.49,
  "Trail mix": 4.99, "Planters mixed nuts": 7.99, "Blue Diamond almonds": 6.99,
  "Planters cashews": 6.99, "Walnuts": 6.99, "Pecans": 7.99, "Wonderful pistachios": 8.99,
  "Sunflower seeds": 2.99, "Pumpkin seeds (pepitas)": 3.99, "Roasted chickpeas": 3.49,
  "Tostitos tortilla chips": 4.49, "Doritos Nacho Cheese": 4.49,
  "Lays potato chips": 4.29, "Kettle chips": 4.49, "Pringles": 2.99,
  "Snyders pretzels": 3.99, "Pretzel crisps": 3.99,
  "Orville Redenbacher popcorn": 3.49, "SkinnyPop popcorn": 4.49,
  "Quaker rice cakes (plain)": 2.99, "Ritz crackers": 4.49, "Triscuit crackers": 4.29,
  "Wheat Thins": 3.99, "Cheez-Its": 4.29, "Goldfish crackers": 3.49,
  "Honey Maid graham crackers": 3.49, "Saltines": 2.49, "Stacys pita chips": 3.99,
  "Veggie straws": 3.99, "Jack Links beef jerky": 6.99, "Turkey jerky": 5.99,
  "Sun-Maid raisins": 2.99, "Ocean Spray Craisins": 4.49,
  "Dried mango": 4.99, "Dried apricots": 3.99,
  "Lindt 70% dark chocolate": 3.49, "Hersheys milk chocolate": 1.99,
  // Cereal
  "Cheerios": 4.49, "Honey Nut Cheerios": 4.49, "Frosted Flakes": 4.29,
  "Raisin Bran": 4.49, "Special K": 4.29, "Cinnamon Toast Crunch": 4.49,
  "Lucky Charms": 4.49, "Nature Valley granola": 4.99,
  // Frozen
  "Frozen broccoli": 1.99, "Frozen spinach": 1.79, "Frozen corn": 1.79, "Frozen peas": 1.79,
  "Frozen mixed vegetables": 1.99, "Frozen edamame": 2.99, "Frozen cauliflower": 2.49,
  "Frozen mixed berries": 4.99, "Frozen blueberries": 4.49, "Frozen strawberries": 3.99,
  "Frozen mango chunks": 3.99,
  "DiGiorno frozen pizza": 7.99, "California Pizza Kitchen frozen pizza": 7.49,
  "Lean Cuisine frozen meals": 3.49, "Stouffers frozen meals": 5.99, "Frozen lasagna": 6.99,
  "Frozen chicken nuggets": 6.99, "Gortons fish sticks": 6.49,
  "Eggo frozen waffles": 3.99, "Ore-Ida tater tots": 4.49, "Ore-Ida french fries": 3.99,
  "Frozen hash browns": 3.49,
  "Haagen-Dazs ice cream": 4.99, "Ben and Jerrys ice cream": 5.49,
  "Breyers ice cream": 4.49, "Klondike ice cream bars": 4.99, "Outshine popsicles": 4.99,
  // Beverages
  "Tropicana orange juice": 4.29, "Simply Orange juice": 4.49, "Motts apple juice": 3.49,
  "Ocean Spray cranberry juice": 3.99, "Simply Lemonade": 3.99,
  "Folgers ground coffee": 9.99, "Maxwell House coffee": 8.99, "Starbucks ground coffee": 11.99,
  "Cold brew coffee": 5.99, "Lipton tea bags": 3.99, "Bigelow tea bags": 4.49,
  "LaCroix sparkling water": 5.99, "Bubly sparkling water": 5.49, "Topo Chico sparkling water": 3.99,
  "Gatorade sports drink": 1.49, "Vita Coco coconut water": 2.49, "GTs Kombucha": 3.99,
  // Condiments
  "Sweet Baby Rays BBQ sauce": 2.99, "Stubbs BBQ sauce": 3.99, "Kikkoman teriyaki sauce": 2.99,
  "A1 steak sauce": 3.49, "Sabra hummus": 3.99, "Hope hummus": 4.49,
  // Spices
  "Morton salt": 1.49, "Diamond Crystal kosher salt": 3.99, "Sea salt": 3.49,
  "Black pepper": 2.99, "Garlic powder": 2.49, "Onion powder": 2.49,
  "Smoked paprika": 2.99, "Cumin": 2.49, "Coriander": 2.49, "Turmeric": 2.99,
  "Cinnamon": 2.49, "Italian seasoning": 2.49, "Everything bagel seasoning": 3.49,
  "Old Bay seasoning": 3.99, "Cajun seasoning": 2.49, "McCormick taco seasoning": 1.49,
  "Chili powder": 2.49, "Curry powder": 2.99, "Garam masala": 3.49,
  "McCormick Montreal steak seasoning": 3.99, "Lawrys seasoned salt": 3.49,
}

function getBasePrice(item) {
  if (BASE_PRICES[item]) return BASE_PRICES[item]
  const low = item.toLowerCase()
  if (low.includes('steak') || low.includes('fillet') || low.includes('salmon')) return 9.99
  if (low.includes('chicken') || low.includes('beef') || low.includes('pork')) return 5.49
  if (low.includes('milk') || low.includes('yogurt') || low.includes('cream')) return 3.99
  if (low.includes('frozen')) return 3.49
  if (low.includes('bread') || low.includes('bun') || low.includes('bagel')) return 2.99
  if (low.includes('oil') || low.includes('sauce') || low.includes('vinegar')) return 3.99
  if (low.includes('nuts') || low.includes('butter')) return 4.49
  return 2.99
}

function getPrice(item, storeName) {
  const base   = getBasePrice(item)
  const mult   = getStoreMult(storeName)
  const hash   = (item + storeName).split('').reduce((a, c) => a + c.charCodeAt(0), 0)
  const jitter = 0.93 + (hash % 100) / 700
  return +(base * mult * jitter).toFixed(2)
}

// ── Autocomplete Input ────────────────────────────────────────────────
function AutocompleteInput({ value, onChange, onSelect, placeholder }) {
  const [open, setOpen]             = useState(false)
  const [highlighted, setHighlighted] = useState(0)
  const wrapRef = useRef(null)

  const matches = value.trim().length >= 1
    ? SUGGESTIONS.filter(s => s.toLowerCase().includes(value.toLowerCase())).slice(0, 8)
    : []

  useEffect(() => { setHighlighted(0) }, [value])

  useEffect(() => {
    const handler = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const select = (item) => { onSelect(item); setOpen(false) }

  const handleKeyDown = (e) => {
    if (!open || matches.length === 0) {
      if (e.key === 'Enter') { onSelect(value); setOpen(false) }
      return
    }
    if (e.key === 'ArrowDown')  { e.preventDefault(); setHighlighted(h => Math.min(h+1, matches.length-1)) }
    else if (e.key === 'ArrowUp')   { e.preventDefault(); setHighlighted(h => Math.max(h-1, 0)) }
    else if (e.key === 'Enter')  { e.preventDefault(); select(matches[highlighted]) }
    else if (e.key === 'Escape') setOpen(false)
  }

  return (
    <div ref={wrapRef} style={{ position:'relative', flex:1, minWidth:200 }}>
      <input
        className="bb-input"
        placeholder={placeholder}
        value={value}
        onChange={e => { onChange(e.target.value); setOpen(true) }}
        onFocus={() => value.trim().length >= 1 && setOpen(true)}
        onKeyDown={handleKeyDown}
        autoComplete="off"
        style={{ width:'100%' }}
      />
      {open && matches.length > 0 && (
        <div style={{
          position:'absolute', top:'calc(100% + 4px)', left:0, right:0, zIndex:1000,
          background:'var(--white)', border:'1.5px solid var(--teal)', borderRadius:'var(--radius-md)',
          boxShadow:'0 8px 24px rgba(0,0,0,0.12)', overflow:'hidden', maxHeight:280, overflowY:'auto'
        }}>
          {matches.map((item, i) => {
            const idx    = item.toLowerCase().indexOf(value.toLowerCase())
            const before = item.slice(0, idx)
            const match  = item.slice(idx, idx + value.length)
            const after  = item.slice(idx + value.length)
            return (
              <div
                key={item}
                onMouseDown={() => select(item)}
                onMouseEnter={() => setHighlighted(i)}
                style={{
                  padding:'9px 14px', cursor:'pointer', fontSize:14,
                  background: i === highlighted ? 'var(--sage-pale)' : 'var(--white)',
                  borderBottom: i < matches.length-1 ? '1px solid var(--border)' : 'none',
                  color:'var(--slate)', transition:'background .1s',
                }}>
                {before}<strong style={{ color:'var(--forest-deep)' }}>{match}</strong>{after}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

// ── Location input with geocoding ─────────────────────────────────────
function LocationBar({ location, setLocation, address, setAddress }) {
  const [input, setInput]       = useState(address || '')
  const [geocoding, setGeocoding] = useState(false)
  const [error, setError]       = useState('')

  const handleSearch = async () => {
    const trimmed = input.trim()
    if (!trimmed) return
    setError(''); setGeocoding(true)
    try {
      const result = await geocodeAddress(trimmed)
      setLocation({ ...result, display: result.displayName || trimmed })
      setAddress(trimmed)
    } catch {
      setError('Location not found — try a city name or zip code.')
    } finally {
      setGeocoding(false)
    }
  }

  return (
    <div className="bb-card" style={{ marginBottom:16, padding:'14px 16px' }}>
      <div style={{ display:'flex', gap:10, alignItems:'center', flexWrap:'wrap' }}>
        <div style={{ flex:1, minWidth:200 }}>
          <label className="bb-label" style={{ fontSize:11, marginBottom:4 }}>
            Your location — used to find real nearby stores
          </label>
          <div style={{ display:'flex', gap:8 }}>
            <input
              className="bb-input"
              placeholder="City, zip code, or address..."
              value={input}
              onChange={e => { setInput(e.target.value); setError('') }}
              onKeyDown={e => e.key === 'Enter' && !geocoding && handleSearch()}
              style={{ flex:1, marginBottom:0 }}
            />
            <button className="bb-btn bb-btn--primary" onClick={handleSearch} disabled={geocoding}
              style={{ padding:'8px 16px', whiteSpace:'nowrap', flexShrink:0 }}>
              {geocoding ? 'Locating...' : 'Set Location'}
            </button>
          </div>
        </div>
        {location && (
          <div style={{ fontSize:12, color:'var(--teal-dark)', fontWeight:600, alignSelf:'flex-end', paddingBottom:2 }}>
            {location.display || location.displayName}
          </div>
        )}
      </div>
      {error && <p style={{ fontSize:12, color:'#dc2626', marginTop:6 }}>{error}</p>}
    </div>
  )
}

// ── Main ShoppingList ─────────────────────────────────────────────────
export default function ShoppingList({ cart, setCart, location, setLocation, address, setAddress }) {
  const [input, setInput]             = useState('')
  const [checked, setChecked]         = useState(new Set())
  const [showCompare, setShowCompare] = useState(false)
  const [filter, setFilter]           = useState('all')

  // Fetch real nearby stores when location is set
  const { data: storeData, isLoading: storesLoading } = useQuery({
    queryKey: ['stores-shopping', location?.lat, location?.lng],
    queryFn:  () => fetchStores({ lat: location.lat, lng: location.lng, radius: 8000 }),
    enabled:  !!location,
    staleTime: 10 * 60 * 1000,
  })

  // Build store list: real nearby stores if available, else prompt user
  const nearbyStores = (storeData?.stores || [])
    .filter(s => s.type === 'grocery' || s.type === 'market' || s.type === 'snap_retailer')
    .slice(0, 5)
    .map(s => ({ name: s.name, mult: getStoreMult(s.name), ebt: s.acceptsEBT }))

  const hasStores = nearbyStores.length > 0

  const addItem = (name, fromSuggestion = false) => {
    const trimmed = name.trim()
    if (!trimmed) return
    if (cart.find(i => i.name.toLowerCase() === trimmed.toLowerCase())) { setInput(''); return }
    // Track whether item has a known price (exists in SUGGESTIONS/BASE_PRICES)
    const isKnown = fromSuggestion || SUGGESTIONS.some(s => s.toLowerCase() === trimmed.toLowerCase())
    setCart(c => [...c, { name: trimmed, qty: 1, id: Date.now(), isKnown }])
    setInput('')
  }

  const removeItem   = id => setCart(c => c.filter(i => i.id !== id))
  const updateQty    = (id, q) => setCart(c => c.map(i => i.id===id ? {...i, qty: Math.max(1,q)} : i))
  const toggleCheck  = id => setChecked(prev => {
    const next = new Set(prev)
    next.has(id) ? next.delete(id) : next.add(id)
    return next
  })
  const clearChecked = () => { setCart(c => c.filter(i => !checked.has(i.id))); setChecked(new Set()) }

  const visible = filter === 'unchecked' ? cart.filter(i => !checked.has(i.id)) : cart

  const storeTotals = hasStores
    ? nearbyStores.map(s => ({
        ...s,
        total: +cart
          .filter(item => item.isKnown)
          .reduce((sum, item) => sum + getPrice(item.name, s.name) * item.qty, 0)
          .toFixed(2)
      })).sort((a, b) => a.total - b.total)
    : []

  const cheapestStore = (item) => {
    if (!hasStores || !item.isKnown) return null
    let best = null, bestPrice = Infinity
    nearbyStores.forEach(s => {
      const p = getPrice(item.name, s.name)
      if (p < bestPrice) { bestPrice = p; best = s.name }
    })
    return { store: best, price: bestPrice }
  }

  return (
    <div className="bb-page" style={{ maxWidth:740 }}>
      <div style={{ marginBottom:20 }}>
        <h1 className="bb-section-title" style={{ fontSize:26 }}>Shopping List</h1>
        <p className="bb-section-sub">
          Build your grocery list, check off items as you shop, and compare prices at stores near you.
        </p>
      </div>

      {/* Location bar */}
      <LocationBar
        location={location} setLocation={setLocation}
        address={address}   setAddress={setAddress}
      />

      {!location && (
        <div style={{ background:'var(--sage-pale)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-md)',
          padding:'14px 18px', marginBottom:16, fontSize:13, color:'var(--slate)' }}>
          Enter your location above to see real grocery stores near you and compare their prices.
        </div>
      )}

      {location && storesLoading && (
        <div style={{ fontSize:13, color:'var(--slate-light)', marginBottom:12, padding:'8px 0' }}>
          Finding stores near {location.display || location.displayName}...
        </div>
      )}

      {location && !storesLoading && hasStores && (
        <div style={{ fontSize:12, color:'var(--teal-dark)', marginBottom:14, fontWeight:600 }}>
          Showing prices from {nearbyStores.length} stores near {location.display || location.displayName}:
          {' '}{nearbyStores.map(s => s.name).join(', ')}
        </div>
      )}

      {location && !storesLoading && !hasStores && (
        <div style={{ fontSize:12, color:'var(--slate-light)', marginBottom:14 }}>
          No grocery stores found near this location. Price comparison unavailable.
        </div>
      )}

      {/* Add item */}
      <div className="bb-card" style={{ marginBottom:20 }}>
        <h2 style={{ fontWeight:700, color:'var(--forest-deep)', fontSize:15, marginBottom:12 }}>Add Item</h2>
        <div style={{ display:'flex', gap:10, flexWrap:'wrap', alignItems:'flex-start' }}>
          <AutocompleteInput
            value={input}
            onChange={setInput}
            onSelect={(item) => addItem(item, true)}
            placeholder="Search for a grocery item..."
          />
          <button className="bb-btn bb-btn--primary" onClick={() => addItem(input)}
            style={{ padding:'9px 22px', whiteSpace:'nowrap', flexShrink:0 }}>
            Add
          </button>
        </div>

        <div style={{ marginTop:14 }}>
          <div className="bb-label" style={{ marginBottom:8 }}>Quick add</div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
            {['Eggs (dozen)','Milk (whole)','Chicken breast','Bananas','Brown rice',
              'Spinach','Peanut butter','Greek yogurt (plain)','Olive oil','Rolled oats'
            ].filter(s => !cart.find(i => i.name === s)).slice(0, 10).map(s => (
              <button key={s} className="bb-pill" onClick={() => addItem(s, true)} style={{ fontSize:12 }}>
                + {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* List */}
      {cart.length > 0 && (
        <div className="bb-card" style={{ marginBottom:20 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
            marginBottom:14, flexWrap:'wrap', gap:8 }}>
            <div style={{ display:'flex', gap:8 }}>
              <button className={`bb-pill ${filter==='all' ? 'active' : ''}`} onClick={() => setFilter('all')}>
                All ({cart.length})
              </button>
              <button className={`bb-pill ${filter==='unchecked' ? 'active' : ''}`} onClick={() => setFilter('unchecked')}>
                Remaining ({cart.length - checked.size})
              </button>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              {checked.size > 0 && (
                <button className="bb-btn bb-btn--soft" style={{ fontSize:12, padding:'6px 14px' }} onClick={clearChecked}>
                  Remove checked ({checked.size})
                </button>
              )}
              {hasStores && (
                <button
                  className={`bb-btn ${showCompare ? 'bb-btn--primary' : 'bb-btn--soft'}`}
                  style={{ fontSize:12, padding:'6px 14px' }}
                  onClick={() => setShowCompare(s => !s)}>
                  {showCompare ? 'Hide Price Compare' : 'Compare Prices'}
                </button>
              )}
            </div>
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {visible.length === 0 && (
              <p style={{ color:'var(--slate-light)', fontSize:13, textAlign:'center', padding:'16px 0' }}>
                All items checked off.
              </p>
            )}
            {visible.map(item => {
              const isChecked = checked.has(item.id)
              const best = cheapestStore(item)
              return (
                <div key={item.id} style={{
                  display:'flex', alignItems:'center', gap:10, padding:'10px 12px',
                  borderRadius:'var(--radius-sm)', border:'1px solid var(--border)',
                  background: isChecked ? 'var(--sage-pale)' : 'var(--white)',
                  opacity: isChecked ? 0.55 : 1, transition:'all .15s'
                }}>
                  <button onClick={() => toggleCheck(item.id)}
                    style={{ width:22, height:22, borderRadius:5, flexShrink:0, cursor:'pointer',
                      border:`2px solid ${isChecked ? 'var(--teal)' : 'var(--border)'}`,
                      background: isChecked ? 'var(--teal)' : 'transparent',
                      display:'flex', alignItems:'center', justifyContent:'center' }}>
                    {isChecked && (
                      <svg width="11" height="9" viewBox="0 0 11 9" fill="none">
                        <path d="M1 4L4 7L10 1" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    )}
                  </button>

                  <span style={{ flex:1, fontWeight:500, fontSize:14, color:'var(--forest-deep)',
                    textDecoration: isChecked ? 'line-through' : 'none' }}>
                    {item.name}
                  </span>

                  {!isChecked && best && (
                    <span style={{ fontSize:11, color:'var(--teal-dark)', background:'var(--sage-pale)',
                      padding:'2px 10px', borderRadius:99, whiteSpace:'nowrap', border:'1px solid var(--border)', flexShrink:0 }}>
                      Best: {best.store} ${best.price.toFixed(2)}
                    </span>
                  )}

                  <div style={{ display:'flex', alignItems:'center', gap:4, flexShrink:0 }}>
                    <button onClick={() => updateQty(item.id, item.qty - 1)}
                      style={{ width:22, height:22, borderRadius:4, border:'1px solid var(--border)',
                        background:'var(--white)', cursor:'pointer', fontSize:14, color:'var(--slate)',
                        display:'flex', alignItems:'center', justifyContent:'center' }}>
                      −
                    </button>
                    <span style={{ fontSize:13, fontWeight:600, color:'var(--forest-deep)', minWidth:18, textAlign:'center' }}>
                      {item.qty}
                    </span>
                    <button onClick={() => updateQty(item.id, item.qty + 1)}
                      style={{ width:22, height:22, borderRadius:4, border:'1px solid var(--border)',
                        background:'var(--white)', cursor:'pointer', fontSize:14, color:'var(--slate)',
                        display:'flex', alignItems:'center', justifyContent:'center' }}>
                      +
                    </button>
                  </div>

                  <button onClick={() => removeItem(item.id)}
                    style={{ color:'var(--slate-light)', fontSize:18, cursor:'pointer',
                      background:'none', border:'none', padding:'0 2px', flexShrink:0, lineHeight:1 }}>
                    ×
                  </button>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Price comparison — only shows when location set and stores found */}
      {showCompare && hasStores && cart.length > 0 && (
        <div className="bb-card fade-up">
          <h3 style={{ fontWeight:700, color:'var(--forest-deep)', marginBottom:4, fontSize:16 }}>
            Store Price Comparison
          </h3>
          <p style={{ fontSize:12, color:'var(--slate-light)', marginBottom:16 }}>
            Based on stores near {location?.display || location?.displayName}
          </p>

          <div style={{ display:'flex', gap:10, flexWrap:'wrap', marginBottom:20 }}>
            {storeTotals.map((s, i) => (
              <div key={s.name} style={{ flex:1, minWidth:120, padding:'12px 14px',
                borderRadius:'var(--radius-md)', textAlign:'center',
                background: i===0 ? 'var(--forest)' : 'var(--sage-pale)',
                border: i===0 ? 'none' : '1px solid var(--border)' }}>
                <div style={{ fontWeight:700, fontSize:13, color: i===0 ? 'white' : 'var(--forest-deep)', marginBottom:2 }}>
                  {s.name}
                </div>
                {s.ebt && (
                  <div style={{ fontSize:10, color: i===0 ? 'rgba(255,255,255,.65)' : 'var(--teal-dark)', marginBottom:6 }}>
                    EBT accepted
                  </div>
                )}
                <div style={{ fontWeight:800, fontSize:22, color: i===0 ? 'var(--mint)' : 'var(--forest)' }}>
                  ${s.total}
                </div>
                {i===0 && <div style={{ fontSize:11, color:'rgba(255,255,255,.7)', marginTop:2 }}>Lowest total</div>}
                {i>0 && <div style={{ fontSize:11, color:'var(--slate-light)', marginTop:2 }}>+${(s.total-storeTotals[0].total).toFixed(2)} more</div>}
              </div>
            ))}
          </div>

          <div style={{ overflowX:'auto' }}>
            <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
              <thead>
                <tr style={{ background:'var(--sage-pale)' }}>
                  <th style={{ padding:'8px 12px', textAlign:'left', color:'var(--forest-deep)', fontWeight:700, borderBottom:'2px solid var(--border)' }}>Item</th>
                  {nearbyStores.map(s => (
                    <th key={s.name} style={{ padding:'8px 10px', textAlign:'center', color:'var(--forest)', fontWeight:600, borderBottom:'2px solid var(--border)' }}>
                      {s.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {cart.map((item, ri) => {
                  if (!item.isKnown) return (
                    <tr key={item.id} style={{ borderBottom:'1px solid var(--border)',
                      background: ri%2===0 ? 'var(--white)' : 'var(--sage-pale)' }}>
                      <td style={{ padding:'8px 12px', color:'var(--slate)' }}>
                        {item.name}
                        {item.qty > 1 && <span style={{ color:'var(--slate-light)', marginLeft:6 }}>x{item.qty}</span>}
                      </td>
                      {nearbyStores.map((_, pi) => (
                        <td key={pi} style={{ padding:'8px 10px', textAlign:'center', color:'var(--slate-light)', fontSize:12 }}>
                          —
                        </td>
                      ))}
                    </tr>
                  )
                  const prices = nearbyStores.map(s => getPrice(item.name, s.name))
                  const minP   = Math.min(...prices)
                  return (
                    <tr key={item.id} style={{ borderBottom:'1px solid var(--border)',
                      background: ri%2===0 ? 'var(--white)' : 'var(--sage-pale)' }}>
                      <td style={{ padding:'8px 12px', color:'var(--slate)' }}>
                        {item.name}
                        {item.qty > 1 && <span style={{ color:'var(--slate-light)', marginLeft:6 }}>x{item.qty}</span>}
                      </td>
                      {prices.map((p, pi) => (
                        <td key={pi} style={{ padding:'8px 10px', textAlign:'center',
                          fontWeight: p===minP ? 700 : 400,
                          color: p===minP ? 'var(--forest)' : 'var(--slate)',
                          background: p===minP ? 'rgba(82,183,136,.14)' : 'transparent' }}>
                          ${(p * item.qty).toFixed(2)}
                          {p===minP && <div style={{ fontSize:10, color:'var(--teal)' }}>best</div>}
                        </td>
                      ))}
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {cart.length === 0 && (
        <div style={{ textAlign:'center', padding:'48px 24px', color:'var(--slate-light)' }}>
          <h3 style={{ fontFamily:"'Fraunces',serif", fontSize:20, color:'var(--forest-deep)', marginBottom:8 }}>
            Your list is empty
          </h3>
          <p style={{ fontSize:14 }}>Search for a grocery item above or use quick add to get started</p>
        </div>
      )}
    </div>
  )
}
