// src/App.jsx — BiteBudget
import React, { useState } from 'react'
import MealPlanTab from './components/MealPlanTab.jsx'
import GoalsPanel from './components/GoalsPanel.jsx'
import FoodMap from './components/FoodMap.jsx'
import EducationPanel from './components/EducationPanel.jsx'
import ShoppingList from './components/ShoppingList.jsx'
import './bitebudget.css'

const TABS = [
  { id: 'map',      label: 'Food Map'          },
  { id: 'mealplan', label: 'Meal Planner'       },
  { id: 'shopping', label: 'Shopping List'      },
  { id: 'goals',    label: 'My Personal Goals'  },
  { id: 'learn',    label: 'Learn'              },
]

export default function App() {
  const [activeTab, setActiveTab] = useState('map')
  const [goals, setGoals]         = useState(null)
  const [cart, setCart]           = useState([])
  const [address, setAddress]     = useState('')
  const [location, setLocation]   = useState(null)
  const [budget, setBudget]       = useState(75)
  const [mealPlan, setMealPlan]   = useState(null)

  return (
    <div className="bb-root">
      <header className="bb-header">
        <div className="bb-logo">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#52b788" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22V12M12 12C12 7 17 3 21 3c0 4-2 9-9 9zM12 12C12 7 7 3 3 3c0 4 2 9 9 9z"/>
          </svg>
          <span className="bb-logo-text">BiteBudget</span>
        </div>
        <nav className="bb-nav">
          {TABS.map(tab => (
            <button
              key={tab.id}
              className={`bb-tab ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="bb-main">
        {activeTab === 'map' && (
          <FoodMap
            cart={cart} setCart={setCart}
            goals={goals}
            location={location} setLocation={setLocation}
            address={address} setAddress={setAddress}
            mealPlan={mealPlan}
          />
        )}
        {activeTab === 'mealplan' && (
          <MealPlanTab
            address={address} setAddress={setAddress}
            location={location} setLocation={setLocation}
            budget={budget} setBudget={setBudget}
            goals={goals}
            mealPlan={mealPlan} setMealPlan={setMealPlan}
            onViewMap={() => setActiveTab('map')}
          />
        )}
        {activeTab === 'shopping' && (
          <ShoppingList
            cart={cart} setCart={setCart}
            location={location} setLocation={setLocation}
            address={address} setAddress={setAddress}
          />
        )}
        {activeTab === 'goals' && <GoalsPanel goals={goals} setGoals={setGoals} />}
        {activeTab === 'learn' && <EducationPanel goals={goals} />}
      </main>
    </div>
  )
}
