// src/utils/api.js — centralized API calls
import axios from 'axios'

const api = axios.create({ baseURL: '/api', timeout: 60000 })

// ── Stores ──────────────────────────────────────────────────────────
export const fetchStores = ({ lat, lng, radius = 5000, ebt = false }) =>
  api.get('/stores', { params: { lat, lng, radius, ebt } }).then(r => r.data)

// ── Nutrition ───────────────────────────────────────────────────────
export const searchNutrition = (q, budget) =>
  api.get('/nutrition/search', { params: { q, budget } }).then(r => r.data)

// ── Meal Plan ───────────────────────────────────────────────────────
// Always pass a fresh seed so every call returns a different plan
export const generateMealPlan = (params) =>
  api.post('/mealplan/generate', { ...params, seed: Date.now() }).then(r => r.data)

// ── Transit ─────────────────────────────────────────────────────────
export const getDirections = ({ fromLat, fromLng, toLat, toLng, mode = 'driving' }) =>
  api.get('/transit/directions', { params: { fromLat, fromLng, toLat, toLng, mode } }).then(r => r.data)

// ── Geocoding ────────────────────────────────────────────────────────
// Handled client-side in FoodMap.jsx using window.google.maps.Geocoder
// (loaded with the Google Maps JS API script)
export const geocodeAddress = async (address) => {
  // Fallback for non-map contexts — uses Nominatim
  const { data } = await axios.get('https://nominatim.openstreetmap.org/search', {
    params: { q: address, format: 'json', limit: 1, countrycodes: 'us' },
    headers: { 'Accept-Language': 'en-US' },
    timeout: 8000,
  })
  if (!data.length) throw new Error('Address not found')
  const r = data[0]
  return {
    lat:         parseFloat(r.lat),
    lng:         parseFloat(r.lon),
    displayName: r.display_name,
  }
}

export default api
