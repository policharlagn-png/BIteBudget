/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        forest: '#1B4332',
        green:  '#2D6A4F',
        lime:   '#52B788',
        mint:   '#95D5B2',
        gold:   '#E9C46A',
        cream:  '#F8F4E9',
      }
    }
  },
  plugins: []
}
