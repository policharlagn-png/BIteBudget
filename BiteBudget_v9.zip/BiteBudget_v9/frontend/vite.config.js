import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import fs from 'fs'
import path from 'path'

// Read whichever port the backend actually started on.
// Falls back to 3001 if the .port file doesn't exist yet.
function getBackendPort() {
  try {
    const portFile = path.resolve(__dirname, '../backend/.port')
    const p = fs.readFileSync(portFile, 'utf8').trim()
    return Number(p) || 3001
  } catch (_) {
    return 3001
  }
}

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: `http://localhost:${getBackendPort()}`,
        changeOrigin: true,
        // Retry on connection failure
        configure: (proxy) => {
          proxy.on('error', (err, req, res) => {
            console.error('[proxy] Backend connection failed:', err.message)
            if (!res.headersSent) {
              res.writeHead(503, { 'Content-Type': 'application/json' })
              res.end(JSON.stringify({
                error: 'Backend is not running. Please start the server first.',
                hint: 'Run: bash start.sh  (from the BiteBudget folder)'
              }))
            }
          })
        }
      }
    }
  }
})
