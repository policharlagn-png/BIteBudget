// backend/routes/transit.js
// OSRM (Open Source Routing Machine) — completely free, no key needed
// Public demo server: router.project-osrm.org
const express = require('express');
const axios   = require('axios');
const router  = express.Router();

// GET /api/transit/directions?fromLat=&fromLng=&toLat=&toLng=&mode=driving|walking|cycling
router.get('/directions', async (req, res) => {
  const { fromLat, fromLng, toLat, toLng, mode = 'driving' } = req.query;
  if (!fromLat || !fromLng || !toLat || !toLng)
    return res.status(400).json({ error: 'from and to coordinates required' });

  try {
    const profile = mode === 'walking' ? 'foot'
                  : mode === 'cycling' ? 'bike'
                  : 'car';

    // OSRM public demo server — free, no key
    const url = `https://router.project-osrm.org/route/v1/${profile}/${fromLng},${fromLat};${toLng},${toLat}`;
    const { data } = await axios.get(url, {
      params: { overview: 'false', steps: true, annotations: false },
      timeout: 8000,
    });

    if (data.code !== 'Ok' || !data.routes?.length)
      throw new Error('No route found');

    const route    = data.routes[0];
    const leg      = route.legs[0];
    const meters   = Math.round(route.distance);
    const seconds  = Math.round(route.duration);
    const miles    = (meters / 1609.34).toFixed(1);
    const minutes  = Math.round(seconds / 60);

    const steps = (leg.steps || [])
      .filter(s => s.maneuver?.type !== 'depart' || s.name)
      .slice(0, 12)
      .map(s => ({
        instruction: buildInstruction(s),
        distance:    `${(s.distance / 1609.34).toFixed(2)} mi`,
        duration:    `${Math.round(s.duration / 60)} min`,
        mode:        mode.toUpperCase(),
      }));

    res.json({
      source:          'osrm',
      mode,
      duration:        `${minutes} min`,
      durationSeconds: seconds,
      distance:        `${miles} mi`,
      distanceMeters:  meters,
      steps,
    });
  } catch (err) {
    // Graceful fallback — straight-line estimate
    const dist = Math.round(haversine(fromLat, fromLng, toLat, toLng));
    const speed = { driving: 40, walking: 5, cycling: 15 }[mode] || 40;
    const minutes = Math.round((dist / 1000) / speed * 60);
    res.json({
      source:          'estimate',
      mode,
      duration:        `${minutes} min (estimated)`,
      durationSeconds: minutes * 60,
      distance:        `${(dist / 1609).toFixed(1)} mi`,
      distanceMeters:  dist,
      steps:           [],
      note:            'Routing service unavailable — showing straight-line estimate',
    });
  }
});

function buildInstruction(step) {
  const type   = step.maneuver?.type || '';
  const mod    = step.maneuver?.modifier || '';
  const street = step.name ? `onto ${step.name}` : '';
  if (type === 'turn')     return `Turn ${mod} ${street}`.trim();
  if (type === 'depart')   return `Head ${mod} ${street}`.trim();
  if (type === 'arrive')   return 'Arrive at destination';
  if (type === 'continue') return `Continue ${street}`.trim();
  return `${type} ${mod} ${street}`.trim() || 'Continue';
}

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2
    + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

module.exports = router;
