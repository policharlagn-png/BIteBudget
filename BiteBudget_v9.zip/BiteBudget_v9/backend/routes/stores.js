// backend/routes/stores.js
// Google Places API (Nearby Search) — real store names, ratings, addresses
const express    = require('express');
const axios      = require('axios');
const NodeCache  = require('node-cache');

const router = express.Router();
const cache  = new NodeCache({ stdTTL: 600 }); // cache 10 min

// GET /api/stores?lat=&lng=&radius=&ebt=true
router.get('/', async (req, res) => {
  const { lat, lng, radius = 8000, ebt } = req.query;
  if (!lat || !lng) return res.status(400).json({ error: 'lat and lng required' });

  const cacheKey = `stores_${lat}_${lng}_${radius}_${ebt}`;
  if (cache.has(cacheKey)) return res.json(cache.get(cacheKey));

  const key = process.env.GOOGLE_MAPS_API_KEY;
  if (!key || key === 'your_google_maps_key_here') {
    return res.json({ stores: getMockStores(lat, lng) });
  }

  try {
    // Run grocery + food bank searches in parallel
    const [groceryRes, foodBankRes] = await Promise.allSettled([
      fetchGooglePlaces(lat, lng, radius, 'grocery_or_supermarket', key),
      fetchGooglePlaces(lat, lng, radius, 'food',                   key),
    ]);

    let stores = [];
    if (groceryRes.status === 'fulfilled')  stores.push(...groceryRes.value);
    if (foodBankRes.status === 'fulfilled') stores.push(...foodBankRes.value);

    // Deduplicate by place_id
    const seen = new Set();
    stores = stores.filter(s => {
      if (seen.has(s.id)) return false;
      seen.add(s.id);
      return true;
    });

    // FILTER: only grocery stores and markets (no food banks, misc stores)
    stores = stores.filter(s => s.type === 'grocery' || s.type === 'market' || s.type === 'snap_retailer');

    // Filter EBT if requested
    if (ebt === 'true') stores = stores.filter(s => s.acceptsEBT);

    // Sort by nutrition score highest->lowest, then distance as tiebreaker
    stores = stores
      .map(s => ({ ...s, distance: haversine(lat, lng, s.lat, s.lng) }))
      .sort((a, b) => {
        const scoreDiff = (b.nutritionScore || 0) - (a.nutritionScore || 0);
        if (scoreDiff !== 0) return scoreDiff;
        return a.distance - b.distance;
      })
      .slice(0, 40);

    const result = { stores };
    cache.set(cacheKey, result);
    res.json(result);
  } catch (err) {
    console.error('Google Places error:', err.message);
    res.json({ stores: getMockStores(lat, lng) });
  }
});

// ── Google Places Nearby Search ──────────────────────────────────────
async function fetchGooglePlaces(lat, lng, radius, type, key) {
  const { data } = await axios.get(
    'https://maps.googleapis.com/maps/api/place/nearbysearch/json',
    {
      params: {
        location: `${lat},${lng}`,
        radius,
        type,
        key,
      },
      timeout: 10000,
    }
  );

  if (data.status !== 'OK' && data.status !== 'ZERO_RESULTS') {
    throw new Error(`Google Places API: ${data.status} — ${data.error_message || ''}`);
  }

  // Strict grocery/market filter — block irrelevant businesses
  const BLOCKED_KEYWORDS = [
    'dealership','car dealer','auto dealer','toyota','honda','ford dealer','chevrolet',
    'department store','school','university','college','church','hospital','clinic','medical center','urgent care',
    'pharmacy','cvs','walgreens','rite aid','dollar tree','dollar general','family dollar',
    'dollar store','gas station','shell','bp ','chevron','exxon','mobil ','speedway',
    'wawa','7-eleven','7 eleven','circle k','caseys','kwik trip','quik trip',
    'liquor','wine store','beer ','tobacco','vape','pet store','hardware',
    'home depot','lowes','auto zone','advance auto',"o'reilly",
    'gym','fitness','yoga','salon','barber','nail salon',
    'restaurant','cafe','coffee','starbucks','mcdonald','subway','pizza',
    'food bank','pantry','food shelf','charity'
  ];
  const REQUIRED_GROCERY_TYPES = [
    'grocery_or_supermarket','supermarket','food','health','convenience_store'
  ];

  const filtered = (data.results || []).filter(place => {
    const nameLower = (place.name || '').toLowerCase();
    const placeTypes = place.types || [];

    // Block anything matching irrelevant keywords
    if (BLOCKED_KEYWORDS.some(kw => nameLower.includes(kw))) return false;

    // Block hospital/medical place types at the API level
    const BLOCKED_TYPES = ['hospital','doctor','health','pharmacy','physiotherapist','dentist'];
    if (BLOCKED_TYPES.some(t => placeTypes.includes(t))) return false;

    // Must have at least one grocery-adjacent type
    const hasGroceryType = placeTypes.some(t => REQUIRED_GROCERY_TYPES.includes(t));
    if (!hasGroceryType) return false;

    // Block pure convenience stores unless they're known grocery chains
    if (placeTypes.includes('convenience_store') && !placeTypes.includes('grocery_or_supermarket') && !placeTypes.includes('supermarket')) {
      const knownChains = ['aldi','kroger','walmart','publix','safeway','albertsons','meijer',
        'heb','h-e-b','target','costco','trader joe','whole foods','sprouts','wegmans',
        'shoprite','stop & shop','giant','harris teeter','hy-vee','market basket',
        'food lion','save-a-lot','lidl','winco','piggly','stater bros'];
      if (!knownChains.some(c => nameLower.includes(c))) return false;
    }

    return true;
  });

  return filtered.map(place => ({
    id:             place.place_id,
    name:           place.name,
    lat:            place.geometry.location.lat,
    lng:            place.geometry.location.lng,
    address:        place.vicinity || 'See map',
    type:           classifyType(place.name, place.types),
    rating:         place.rating || null,
    ratingCount:    place.user_ratings_total || 0,
    acceptsEBT:     isKnownSnapChain(place.name),
    openNow:        place.opening_hours?.open_now ?? null,
    source:         'google',
    nutritionScore: scoreStore(place.name),
    photoRef:       place.photos?.[0]?.photo_reference || null,
  }));
}

// ── Helpers ──────────────────────────────────────────────────────────

function classifyType(name, types = []) {
  const lower = name.toLowerCase();
  if (lower.includes('food bank') || lower.includes('pantry') || lower.includes('food shelf')) return 'food_bank';
  if (lower.includes('farmer') || lower.includes('market') || lower.includes('farm stand')) return 'market';
  if (types.includes('grocery_or_supermarket') || types.includes('supermarket')) return 'grocery';
  return 'grocery';
}

function isKnownSnapChain(name = '') {
  const lower = name.toLowerCase();
  const snapChains = [
    'walmart','kroger','aldi','publix','safeway','albertsons','meijer',
    'h-e-b','food lion','giant','stop & shop','winn-dixie','save-a-lot',
    'lidl','winco','price chopper','market basket','stater bros',
    'piggly wiggly','food 4 less','smart & final','shoprite','wegmans',
    'harris teeter','hy-vee','jewel','ralphs','vons','fry\'s','king soopers',
  ];
  return snapChains.some(c => lower.includes(c));
}

function scoreStore(name = '') {
  const lower = name.toLowerCase();
  if (lower.includes('whole foods') || lower.includes('sprouts'))     return 90;
  if (lower.includes('trader joe'))                                    return 87;
  if (lower.includes('wegmans'))                                       return 82;
  if (lower.includes('publix') || lower.includes('harris teeter'))    return 79;
  if (lower.includes('kroger') || lower.includes('king soopers'))     return 76;
  if (lower.includes('h-e-b')  || lower.includes('hy-vee'))          return 76;
  if (lower.includes('meijer') || lower.includes('shoprite'))         return 75;
  if (lower.includes('safeway')|| lower.includes('albertsons'))       return 74;
  if (lower.includes('walmart')|| lower.includes('target'))           return 70;
  if (lower.includes('aldi')   || lower.includes('lidl'))             return 73;
  if (lower.includes('food lion')|| lower.includes('giant'))          return 72;
  if (lower.includes('save-a-lot')|| lower.includes('winco'))         return 64;
  if (lower.includes('dollar') || lower.includes('convenience'))      return 40;
  if (lower.includes('food bank')|| lower.includes('pantry'))         return 83;
  if (lower.includes('farmer') || lower.includes('market'))           return 93;
  return 68;
}

function haversine(lat1, lon1, lat2, lon2) {
  const R    = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a    = Math.sin(dLat / 2) ** 2
    + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180)
    * Math.sin(dLon / 2) ** 2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

function getMockStores(lat, lng) {
  const chains = [
    { name: 'Walmart Supercenter',    type: 'grocery',      rating: 4.0, acceptsEBT: true,  nutritionScore: 70 },
    { name: 'Kroger',                 type: 'grocery',      rating: 4.1, acceptsEBT: true,  nutritionScore: 76 },
    { name: 'Aldi',                   type: 'grocery',      rating: 4.3, acceptsEBT: true,  nutritionScore: 73 },
    { name: 'Publix Super Market',    type: 'grocery',      rating: 4.5, acceptsEBT: true,  nutritionScore: 79 },
    { name: 'Target',                 type: 'grocery',      rating: 4.2, acceptsEBT: true,  nutritionScore: 68 },
    { name: 'Whole Foods Market',     type: 'grocery',      rating: 4.4, acceptsEBT: false, nutritionScore: 90 },
    { name: "Trader Joe's",           type: 'grocery',      rating: 4.6, acceptsEBT: false, nutritionScore: 87 },
    { name: 'Save-A-Lot',             type: 'snap_retailer',rating: 3.7, acceptsEBT: true,  nutritionScore: 64 },
    // food bank removed - only grocery/market locations shown
    { name: 'Downtown Farmers Market',type: 'market',       rating: 4.8, acceptsEBT: true,  nutritionScore: 93 },
  ];
  return chains
    .map((s, i) => ({
      ...s,
      id:       `mock_${i}`,
      lat:      parseFloat(lat) + (Math.random() - 0.5) * 0.05,
      lng:      parseFloat(lng) + (Math.random() - 0.5) * 0.05,
      address:  `${100 + i * 37} ${['Main St', 'Oak Ave', 'Market Blvd', 'Center Rd', 'Commerce Dr'][i % 5]}`,
      source:   'demo',
      distance: 200 + i * 350,
    }))
    .sort((a, b) => (b.nutritionScore || 0) - (a.nutritionScore || 0));
}

module.exports = router;
