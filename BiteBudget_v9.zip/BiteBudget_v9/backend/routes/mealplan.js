// backend/routes/mealplan.js
// APIs: Groq (nutrition data) + Google Places (real nearby stores + ingredients)
const express = require('express');
const axios   = require('axios');
const router  = express.Router();

// ─────────────────────────────────────────────────────────────────────
// DIET CONFIGS — what each restriction blocks
// ─────────────────────────────────────────────────────────────────────
const DIET_RULES = {
  'No Restriction': { label: 'No Restriction', blocks: [] },
  'Vegan':          { label: 'Vegan',          blocks: ['chicken','beef','pork','tuna','salmon','shrimp','fish','seafood','eggs','egg','dairy','yogurt','cheese','cottage cheese','honey'] },
  'Vegetarian':     { label: 'Vegetarian',     blocks: ['chicken','beef','pork','tuna','salmon','shrimp','fish','seafood','ground beef','chicken thighs'] },
  'Pescatarian':    { label: 'Pescatarian',    blocks: ['chicken','beef','pork','ground beef','chicken thighs'] },
  'Keto':           { label: 'Keto',           blocks: ['rice','oats','bread','pasta','tortillas','banana','potato','sweet potato','beans','lentils','corn','quinoa','rice cakes'] },
  'Gluten-Free':    { label: 'Gluten-Free',    blocks: ['bread','pasta','tortillas','wheat'] },
  'High Protein':   { label: 'High Protein',   blocks: [] },
  'Mediterranean':  { label: 'Mediterranean',  blocks: [] },
};

// ─────────────────────────────────────────────────────────────────────
// MASTER INGREDIENT LIST — diet-tagged
// ─────────────────────────────────────────────────────────────────────
const MASTER_INGREDIENTS = {
  proteins: [
    { name: 'Eggs (dozen)',              unit: '1 dozen',   basePrice: 3.49, tags: ['vegetarian','gluten-free','keto'] },
    { name: 'Canned tuna (5oz)',         unit: '2 cans',    basePrice: 2.58, tags: ['pescatarian','gluten-free','keto'] },
    { name: 'Chicken thighs (2lb)',      unit: '1 pack',    basePrice: 4.99, tags: ['gluten-free','keto'] },
    { name: 'Ground beef 90% (1lb)',     unit: '1lb',       basePrice: 5.49, tags: ['gluten-free','keto'] },
    { name: 'Black beans (15oz can)',    unit: '2 cans',    basePrice: 1.78, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Lentils dried (1lb)',       unit: '1 bag',     basePrice: 1.99, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Cottage cheese (16oz)',     unit: '1 tub',     basePrice: 2.99, tags: ['vegetarian','gluten-free','keto'] },
    { name: 'Greek yogurt plain (32oz)', unit: '1 tub',     basePrice: 4.49, tags: ['vegetarian','gluten-free','keto'] },
    { name: 'Peanut butter (16oz)',      unit: '1 jar',     basePrice: 2.99, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Canned salmon (14.75oz)',   unit: '1 can',     basePrice: 3.99, tags: ['pescatarian','gluten-free','keto'] },
    { name: 'Tofu firm (14oz)',          unit: '1 block',   basePrice: 2.49, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Chickpeas (15oz can)',      unit: '2 cans',    basePrice: 1.98, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Edamame frozen (12oz)',     unit: '1 bag',     basePrice: 2.29, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Shrimp frozen (1lb)',       unit: '1 bag',     basePrice: 6.99, tags: ['pescatarian','gluten-free','keto'] },
    { name: 'Almond butter (12oz)',      unit: '1 jar',     basePrice: 4.49, tags: ['vegan','vegetarian','gluten-free','keto'] },
  ],
  carbs: [
    { name: 'Rolled oats (42oz)',        unit: '1 canister', basePrice: 3.99, tags: ['vegan','vegetarian'] },
    { name: 'Brown rice (5lb)',          unit: '1 bag',      basePrice: 4.49, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Whole wheat bread (loaf)',  unit: '1 loaf',     basePrice: 2.99, tags: ['vegan','vegetarian'] },
    { name: 'Sweet potatoes (3lb)',      unit: '1 bag',      basePrice: 3.49, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Russet potatoes (5lb)',     unit: '1 bag',      basePrice: 3.99, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Whole wheat pasta (16oz)',  unit: '1 box',      basePrice: 1.49, tags: ['vegan','vegetarian'] },
    { name: 'Corn tortillas (30ct)',     unit: '1 pack',     basePrice: 2.49, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Banana bunch',             unit: '1 bunch',    basePrice: 1.29, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Quinoa (1lb)',             unit: '1 bag',      basePrice: 3.99, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Rice cakes (plain)',        unit: '1 pack',     basePrice: 2.49, tags: ['vegan','vegetarian','gluten-free'] },
  ],
  vegetables: [
    { name: 'Frozen broccoli (12oz)',         unit: '2 bags',  basePrice: 2.58, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Frozen spinach (10oz)',          unit: '2 bags',  basePrice: 2.38, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Carrots (2lb bag)',              unit: '1 bag',   basePrice: 1.49, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Cabbage head',                  unit: '1 head',  basePrice: 1.29, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Canned diced tomatoes (14oz)',  unit: '2 cans',  basePrice: 1.78, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Frozen mixed vegetables (12oz)', unit: '2 bags', basePrice: 2.98, tags: ['vegan','vegetarian','gluten-free'] },
    { name: 'Onions (3lb bag)',              unit: '1 bag',   basePrice: 2.49, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Garlic bulb',                  unit: '1 bulb',  basePrice: 0.79, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Bell peppers (3-pack)',         unit: '1 pack',  basePrice: 2.99, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Cucumber',                     unit: '2 count', basePrice: 1.38, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Avocado',                      unit: '2 count', basePrice: 1.78, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Celery bunch',                 unit: '1 bunch', basePrice: 1.29, tags: ['vegan','vegetarian','gluten-free','keto'] },
  ],
  fats: [
    { name: 'Olive oil (16oz)',        unit: '1 bottle', basePrice: 4.99, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Shredded cheese (8oz)',   unit: '1 bag',    basePrice: 2.49, tags: ['vegetarian','gluten-free','keto'] },
    { name: 'Cream cheese (8oz)',      unit: '1 block',  basePrice: 2.29, tags: ['vegetarian','gluten-free','keto'] },
    { name: 'Coconut oil (14oz)',      unit: '1 jar',    basePrice: 4.49, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Walnuts (8oz)',           unit: '1 bag',    basePrice: 3.49, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Sunflower seeds (1lb)',   unit: '1 bag',    basePrice: 2.99, tags: ['vegan','vegetarian','gluten-free','keto'] },
  ],
  pantry: [
    { name: 'Soy sauce (10oz)',        unit: '1 bottle', basePrice: 1.29, tags: ['vegan','vegetarian'] },
    { name: 'Hot sauce',               unit: '1 bottle', basePrice: 1.49, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Vegetable broth (32oz)', unit: '1 carton', basePrice: 1.99, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Chicken broth (32oz)',    unit: '1 carton', basePrice: 1.99, tags: ['gluten-free','keto'] },
    { name: 'Salsa jar (16oz)',        unit: '1 jar',    basePrice: 1.99, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Coconut aminos (8oz)',    unit: '1 bottle', basePrice: 3.49, tags: ['vegan','vegetarian','gluten-free','keto'] },
    { name: 'Canned coconut milk',     unit: '2 cans',   basePrice: 3.18, tags: ['vegan','vegetarian','gluten-free','keto'] },
  ],
};

// ─────────────────────────────────────────────────────────────────────
// DIET FILTER
// ─────────────────────────────────────────────────────────────────────
function filterIngredients(restrictions) {
  const activeBlocks = restrictions === 'none' ? [] :
    restrictions.split(', ').flatMap(r => {
      const rule = Object.values(DIET_RULES).find(d => d.label.toLowerCase() === r.toLowerCase().trim());
      return rule?.blocks || [];
    });

  const result = {};
  for (const [cat, items] of Object.entries(MASTER_INGREDIENTS)) {
    result[cat] = items.filter(item => {
      const n = item.name.toLowerCase();
      return !activeBlocks.some(b => n.includes(b));
    });
  }
  return result;
}

// ─────────────────────────────────────────────────────────────────────
// 10 PLANS × 2 VARIATIONS PER NUTRITION CATEGORY
// varA = standard | varB is generated dynamically via swaps
// ─────────────────────────────────────────────────────────────────────
const PLAN_LIBRARY = {
  balanced: [
    { varA: { breakfast:'Scrambled eggs + whole wheat toast',       lunch:'Tuna wrap + salsa + carrots',             dinner:'Brown rice + black beans + sautéed cabbage' }},
    { varA: { breakfast:'Oatmeal + banana + peanut butter',         lunch:'Peanut butter sandwich + carrot sticks',  dinner:'Chicken thighs + sweet potato + frozen broccoli' }},
    { varA: { breakfast:'Greek yogurt + banana',                    lunch:'Lentil soup + canned tomatoes + onion',   dinner:'Ground beef tacos + corn tortillas + salsa' }},
    { varA: { breakfast:'Eggs + sweet potato hash',                 lunch:'Cottage cheese + carrots',                dinner:'Pasta + ground beef + canned tomatoes' }},
    { varA: { breakfast:'Oatmeal + peanut butter + banana',         lunch:'Canned tuna + brown rice bowl',           dinner:'Chicken thighs + frozen broccoli + brown rice' }},
    { varA: { breakfast:'Scrambled eggs + salsa',                   lunch:'Black bean + cheese quesadilla',          dinner:'Beef + frozen mixed veg stir fry + rice' }},
    { varA: { breakfast:'Banana + peanut butter toast',             lunch:'Greek yogurt + carrots',                  dinner:'Lentil + vegetable soup + bread' }},
    { varA: { breakfast:'Cottage cheese + banana',                  lunch:'Tuna + crackers + celery',                dinner:'Chicken thighs + sweet potato + spinach' }},
    { varA: { breakfast:'Oatmeal + walnuts + banana',               lunch:'Chickpea salad wrap',                     dinner:'Shrimp stir fry + brown rice + broccoli' }},
    { varA: { breakfast:'Eggs + avocado toast',                     lunch:'Lentil soup + bread',                     dinner:'Ground beef + brown rice + frozen mixed veg' }},
  ],
  highProtein: [
    { varA: { breakfast:'4 eggs scrambled + cottage cheese',        lunch:'Chicken thighs + rice + broccoli',        dinner:'Ground beef + black beans + rice bowl' }},
    { varA: { breakfast:'Greek yogurt + oats mixed',                lunch:'Canned salmon + rice + spinach',          dinner:'Tuna pasta + canned tomatoes' }},
    { varA: { breakfast:'3 eggs + black beans',                     lunch:'Cottage cheese + banana + peanut butter', dinner:'Chicken thighs + lentils + carrots' }},
    { varA: { breakfast:'Oatmeal + Greek yogurt + banana',          lunch:'Ground beef tacos + corn tortillas',      dinner:'Salmon + brown rice + frozen spinach' }},
    { varA: { breakfast:'3 eggs + whole wheat toast',               lunch:'Lentil soup + bread',                     dinner:'Chicken thighs + sweet potato + broccoli' }},
    { varA: { breakfast:'Cottage cheese + banana + peanut butter',  lunch:'Tuna wrap + avocado',                     dinner:'Beef stir fry + rice + mixed vegetables' }},
    { varA: { breakfast:'4 eggs + oatmeal',                         lunch:'Shrimp + rice + broccoli',                dinner:'Ground beef + pasta + canned tomatoes' }},
    { varA: { breakfast:'Greek yogurt + banana + walnuts',          lunch:'Chicken thighs + sweet potato',           dinner:'Canned salmon + brown rice + spinach' }},
    { varA: { breakfast:'Eggs + cottage cheese + toast',            lunch:'Black beans + rice + cheese',             dinner:'Chicken + frozen mixed veg + rice bowl' }},
    { varA: { breakfast:'Oatmeal + peanut butter + 2 boiled eggs',  lunch:'Tuna + crackers + carrots',               dinner:'Ground beef + lentils + canned tomatoes' }},
  ],
  weightLoss: [
    { varA: { breakfast:'2 eggs + cottage cheese',                  lunch:'Tuna + cabbage slaw + carrots',           dinner:'Chicken thighs + frozen broccoli' }},
    { varA: { breakfast:'Greek yogurt + banana (small)',            lunch:'Lentil soup',                             dinner:'Ground beef + cabbage stir fry' }},
    { varA: { breakfast:'2 eggs + spinach scramble',                lunch:'Canned salmon + carrots + celery',        dinner:'Chicken + frozen vegetables + small sweet potato' }},
    { varA: { breakfast:'Small oatmeal + Greek yogurt',             lunch:'Tuna wrap (no mayo)',                     dinner:'Black beans + cabbage + salsa' }},
    { varA: { breakfast:'Cottage cheese + banana',                  lunch:'Egg salad on toast (2 eggs)',             dinner:'Chicken + frozen broccoli + small brown rice' }},
    { varA: { breakfast:'2 eggs + salsa + spinach',                 lunch:'Greek yogurt + carrots',                  dinner:'Ground beef + frozen mixed vegetables' }},
    { varA: { breakfast:'Oatmeal + 1 tbsp peanut butter',          lunch:'Tuna + sweet potato',                     dinner:'Large lentil soup + bread' }},
    { varA: { breakfast:'Eggs + cucumber + salsa',                  lunch:'Chickpea + cucumber salad',               dinner:'Shrimp + frozen broccoli' }},
    { varA: { breakfast:'Greek yogurt + celery sticks',             lunch:'Cottage cheese + carrots + hot sauce',    dinner:'Chicken + cabbage + onion stir fry' }},
    { varA: { breakfast:'2 eggs + avocado (half)',                  lunch:'Canned tuna + bell pepper strips',        dinner:'Ground beef + spinach + canned tomatoes' }},
  ],
  muscleBuild: [
    { varA: { breakfast:'4 eggs + oatmeal + banana',                lunch:'Chicken thighs + rice + broccoli',        dinner:'Ground beef + pasta + canned tomatoes' }},
    { varA: { breakfast:'Greek yogurt + oats + peanut butter',      lunch:'Canned salmon + rice + spinach',          dinner:'Chicken thighs + sweet potato + mixed veg' }},
    { varA: { breakfast:'4 eggs + 2 toast + banana',                lunch:'Ground beef + rice + black beans',        dinner:'Chicken thighs + pasta + canned tomatoes' }},
    { varA: { breakfast:'Oatmeal + Greek yogurt + banana',          lunch:'Tuna + rice + broccoli',                  dinner:'Beef stir fry + rice + veg + soy sauce' }},
    { varA: { breakfast:'Cottage cheese + oats + banana',           lunch:'Chicken thighs + sweet potato',           dinner:'Ground beef + black beans + rice + cheese' }},
    { varA: { breakfast:'4 eggs + cottage cheese + toast',          lunch:'Salmon + rice + spinach',                 dinner:'Chicken thighs + pasta + tomatoes' }},
    { varA: { breakfast:'Oatmeal + peanut butter + 2 boiled eggs',  lunch:'Ground beef + rice + broccoli',           dinner:'Tuna pasta + canned tomatoes + spinach' }},
    { varA: { breakfast:'5 eggs scrambled + oatmeal',               lunch:'Chicken + quinoa + frozen mixed veg',     dinner:'Ground beef + sweet potato mash' }},
    { varA: { breakfast:'Greek yogurt + banana + walnuts + oats',   lunch:'Shrimp + brown rice + broccoli',          dinner:'Chicken thighs + lentils + canned tomatoes' }},
    { varA: { breakfast:'4 eggs + avocado + toast',                 lunch:'Cottage cheese + banana + peanut butter', dinner:'Ground beef tacos + black beans + cheese' }},
  ],
  vegan: [
    { varA: { breakfast:'Oatmeal + banana + peanut butter',         lunch:'Lentil soup + whole wheat bread',         dinner:'Black beans + rice + sautéed cabbage' }},
    { varA: { breakfast:'Banana + almond butter toast',             lunch:'Chickpea wrap + carrots',                 dinner:'Vegetable fried rice (rice + frozen veg + soy sauce)' }},
    { varA: { breakfast:'Oatmeal + walnuts + banana',               lunch:'Tofu + rice + frozen broccoli',           dinner:'Lentil + tomato stew + bread' }},
    { varA: { breakfast:'Banana + peanut butter + rice cakes',      lunch:'Black bean quesadilla (corn tortillas)',  dinner:'Pasta + canned tomatoes + spinach + olive oil' }},
    { varA: { breakfast:'Oatmeal + coconut milk + banana',          lunch:'Lentil soup',                             dinner:'Sweet potato + black beans + salsa' }},
    { varA: { breakfast:'Peanut butter toast + banana',             lunch:'Chickpea + cucumber + tomato salad',      dinner:'Vegetable stir fry + rice + soy sauce' }},
    { varA: { breakfast:'Oatmeal + sunflower seeds + banana',       lunch:'Tofu stir fry + rice',                   dinner:'Black bean tacos + salsa + cabbage' }},
    { varA: { breakfast:'Banana + almond butter + rice cakes',      lunch:'Lentil + vegetable soup',                dinner:'Chickpea coconut curry + rice' }},
    { varA: { breakfast:'Oatmeal + walnuts + peanut butter',        lunch:'Black beans + rice bowl + avocado',       dinner:'Tofu + frozen mixed veg + brown rice' }},
    { varA: { breakfast:'Banana + oatmeal + coconut milk',          lunch:'Vegetable soup + bread',                 dinner:'Lentils + sweet potato + spinach' }},
  ],
  vegetarian: [
    { varA: { breakfast:'Scrambled eggs + whole wheat toast',       lunch:'Lentil soup + bread',                     dinner:'Black beans + rice + cabbage slaw' }},
    { varA: { breakfast:'Greek yogurt + banana',                    lunch:'Peanut butter wrap + carrots',            dinner:'Vegetable fried rice (rice + eggs + mixed veg)' }},
    { varA: { breakfast:'Eggs + sweet potato hash',                 lunch:'Cottage cheese + carrots',                dinner:'Lentil + canned tomato stew + bread' }},
    { varA: { breakfast:'Oatmeal + peanut butter + banana',         lunch:'Black bean quesadilla + salsa',           dinner:'Pasta + canned tomatoes + spinach' }},
    { varA: { breakfast:'Banana + peanut butter toast',             lunch:'Lentil soup',                             dinner:'Sweet potato + black beans + shredded cheese' }},
    { varA: { breakfast:'Greek yogurt + oats + banana',            lunch:'Cottage cheese + banana',                 dinner:'Vegetable stir fry + rice + soy sauce' }},
    { varA: { breakfast:'Scrambled eggs + spinach',                 lunch:'Peanut butter sandwich',                  dinner:'Black bean tacos + salsa + cabbage' }},
    { varA: { breakfast:'Oatmeal + walnuts + banana',               lunch:'Chickpea salad wrap',                     dinner:'Egg fried rice + frozen mixed veg' }},
    { varA: { breakfast:'Eggs + avocado toast',                     lunch:'Greek yogurt + carrots',                  dinner:'Tofu stir fry + brown rice + broccoli' }},
    { varA: { breakfast:'Cottage cheese + banana + oats',           lunch:'Black bean soup + bread',                dinner:'Pasta + eggs + canned tomatoes + cheese' }},
  ],
  keto: [
    { varA: { breakfast:'3 eggs scrambled + avocado',               lunch:'Tuna + celery + olive oil',               dinner:'Chicken thighs + frozen broccoli' }},
    { varA: { breakfast:'Eggs + cottage cheese',                    lunch:'Canned salmon + cucumber + olive oil',    dinner:'Ground beef + cabbage + canned tomatoes' }},
    { varA: { breakfast:'2 eggs + avocado + hot sauce',             lunch:'Chicken thighs + spinach',                dinner:'Beef + frozen mixed veg stir fry' }},
    { varA: { breakfast:'4 eggs scrambled + shredded cheese',       lunch:'Tuna + bell pepper strips',               dinner:'Ground beef + cheese + spinach skillet' }},
    { varA: { breakfast:'Eggs + cream cheese + cucumber',           lunch:'Salmon + celery + olive oil',             dinner:'Chicken thighs + frozen broccoli + cheese' }},
    { varA: { breakfast:'3 eggs + avocado',                         lunch:'Cottage cheese + cucumber + hot sauce',   dinner:'Ground beef + cabbage + olive oil' }},
    { varA: { breakfast:'Eggs + shredded cheese + hot sauce',       lunch:'Canned tuna + avocado',                   dinner:'Chicken + frozen spinach + cream cheese sauce' }},
    { varA: { breakfast:'4 eggs + cream cheese',                    lunch:'Salmon + cucumber + olive oil',           dinner:'Ground beef + bell peppers + canned tomatoes' }},
    { varA: { breakfast:'2 eggs + cottage cheese + avocado',        lunch:'Chicken + spinach + olive oil',           dinner:'Beef stir fry + frozen broccoli + coconut aminos' }},
    { varA: { breakfast:'3 eggs + avocado + hot sauce',             lunch:'Tuna + celery + walnuts',                 dinner:'Chicken thighs + cabbage + garlic + olive oil' }},
  ],
  glutenFree: [
    { varA: { breakfast:'Eggs + sweet potato hash + hot sauce',     lunch:'Tuna + rice + carrots',                   dinner:'Chicken thighs + brown rice + frozen broccoli' }},
    { varA: { breakfast:'Greek yogurt + banana',                    lunch:'Black beans + rice bowl',                 dinner:'Ground beef + sweet potato + canned tomatoes' }},
    { varA: { breakfast:'Eggs + avocado',                           lunch:'Lentil soup',                             dinner:'Chicken + frozen veg + rice' }},
    { varA: { breakfast:'Rice cakes + peanut butter + banana',      lunch:'Canned salmon + rice + spinach',          dinner:'Ground beef + cabbage + rice' }},
    { varA: { breakfast:'Oatmeal (certified GF) + banana',          lunch:'Chickpea salad + olive oil',              dinner:'Chicken thighs + quinoa + frozen broccoli' }},
    { varA: { breakfast:'Eggs + cottage cheese',                    lunch:'Tuna + carrots + celery',                 dinner:'Ground beef + black beans + rice' }},
    { varA: { breakfast:'Greek yogurt + banana + sunflower seeds',  lunch:'Lentil soup (no bread)',                  dinner:'Chicken + sweet potato + frozen mixed veg' }},
    { varA: { breakfast:'Eggs + rice cakes + avocado',              lunch:'Salmon + cucumber + rice',                dinner:'Beef stir fry + rice + frozen veg + coconut aminos' }},
    { varA: { breakfast:'Cottage cheese + banana + rice cakes',     lunch:'Black bean + avocado rice bowl',          dinner:'Chicken + quinoa + frozen spinach' }},
    { varA: { breakfast:'Oatmeal + peanut butter + banana',         lunch:'Tuna + sweet potato',                     dinner:'Shrimp + brown rice + frozen broccoli' }},
  ],
  pescatarian: [
    { varA: { breakfast:'Eggs + whole wheat toast',                 lunch:'Tuna wrap + carrots',                     dinner:'Shrimp stir fry + brown rice + broccoli' }},
    { varA: { breakfast:'Greek yogurt + banana',                    lunch:'Canned salmon + rice + spinach',          dinner:'Tuna pasta + canned tomatoes' }},
    { varA: { breakfast:'Eggs + avocado toast',                     lunch:'Tuna + crackers + carrots',               dinner:'Shrimp + sweet potato + frozen mixed veg' }},
    { varA: { breakfast:'Oatmeal + banana + peanut butter',         lunch:'Canned salmon + brown rice',              dinner:'Fish tacos (tuna + corn tortillas + cabbage + salsa)' }},
    { varA: { breakfast:'Cottage cheese + banana',                  lunch:'Shrimp + rice + frozen broccoli',         dinner:'Tuna pasta + spinach + olive oil' }},
    { varA: { breakfast:'Eggs + sweet potato hash',                 lunch:'Tuna + black beans + rice bowl',          dinner:'Salmon + quinoa + frozen spinach' }},
    { varA: { breakfast:'Greek yogurt + oats + banana',             lunch:'Tuna wrap + avocado',                     dinner:'Shrimp + frozen veg stir fry + rice + soy sauce' }},
    { varA: { breakfast:'Eggs + cottage cheese + toast',            lunch:'Canned salmon + cucumber + olive oil',    dinner:'Tuna + sweet potato + frozen broccoli' }},
    { varA: { breakfast:'Oatmeal + walnuts + banana',               lunch:'Tuna + celery + carrots',                 dinner:'Shrimp + brown rice + canned tomatoes' }},
    { varA: { breakfast:'Eggs + avocado',                           lunch:'Salmon + brown rice + spinach',           dinner:'Tuna tacos + corn tortillas + cabbage + salsa' }},
  ],
  mediterranean: [
    { varA: { breakfast:'Greek yogurt + banana + walnuts',          lunch:'Canned salmon + olive oil + bread',       dinner:'Lentils + olive oil + tomatoes + onion' }},
    { varA: { breakfast:'Eggs + olive oil + toast',                 lunch:'Tuna wrap + avocado',                     dinner:'Chicken thighs + sweet potato + olive oil' }},
    { varA: { breakfast:'Oatmeal + olive oil + banana',             lunch:'Cottage cheese + carrots + olive oil',    dinner:'Pasta + canned tomatoes + olive oil + spinach' }},
    { varA: { breakfast:'Greek yogurt + banana + sunflower seeds',  lunch:'Lentil soup + bread + olive oil',         dinner:'Chicken + rice + frozen broccoli + olive oil' }},
    { varA: { breakfast:'Eggs + canned tomatoes + olive oil',       lunch:'Tuna + rice',                             dinner:'Ground beef + lentils + canned tomatoes' }},
    { varA: { breakfast:'Greek yogurt + oats',                      lunch:'Avocado + eggs on rice cakes',            dinner:'Salmon + sweet potato + frozen spinach + olive oil' }},
    { varA: { breakfast:'Banana + peanut butter + oatmeal',         lunch:'Cottage cheese + olive oil + carrots',    dinner:'Lentil stew + bread + olive oil' }},
    { varA: { breakfast:'Eggs + spinach + olive oil',               lunch:'Chickpea salad + cucumber + olive oil',   dinner:'Chicken thighs + quinoa + frozen veg' }},
    { varA: { breakfast:'Greek yogurt + walnuts + banana',          lunch:'Tuna + canned tomatoes + olive oil',      dinner:'Pasta + chickpeas + spinach + olive oil' }},
    { varA: { breakfast:'Oatmeal + olive oil + walnuts',            lunch:'Salmon + brown rice + cucumber',          dinner:'Lentils + sweet potato + canned tomatoes + olive oil' }},
  ],
};

// ─────────────────────────────────────────────────────────────────────
// VARIATION B — diet-safe protein/style swaps
// ─────────────────────────────────────────────────────────────────────
const SWAP_PAIRS = [
  ['eggs','cottage cheese'],['cottage cheese','greek yogurt'],
  ['tuna','canned salmon'],['canned salmon','tuna'],
  ['chicken thighs','ground beef'],['ground beef','chicken thighs'],
  ['lentil soup','black bean soup'],['black beans','chickpeas'],['chickpeas','black beans'],
  ['tofu','edamame'],['peanut butter','almond butter'],['almond butter','peanut butter'],
  ['brown rice','quinoa'],['pasta','brown rice'],['oatmeal','greek yogurt + oats'],
  ['shrimp','canned tuna'],['canned tuna','shrimp'],
];

function buildVarB(varA, activeBlocks) {
  const applySwap = (meal) => {
    for (const [from, to] of SWAP_PAIRS) {
      if (meal.toLowerCase().includes(from)) {
        const blocked = activeBlocks.some(b => to.toLowerCase().includes(b));
        if (!blocked) return meal.replace(new RegExp(from, 'i'), to);
      }
    }
    return meal;
  };
  return {
    breakfast: applySwap(varA.breakfast),
    lunch:     applySwap(varA.lunch),
    dinner:    applySwap(varA.dinner),
  };
}

// ─────────────────────────────────────────────────────────────────────
// CATEGORY SELECTION
// ─────────────────────────────────────────────────────────────────────
function selectCategory(goals, restrictions) {
  const d = restrictions.toLowerCase();
  if (d.includes('vegan'))          return 'vegan';
  if (d.includes('keto'))           return 'keto';
  if (d.includes('gluten'))         return 'glutenFree';
  if (d.includes('vegetarian'))     return 'vegetarian';
  if (d.includes('pescatarian'))    return 'pescatarian';
  if (d.includes('mediterranean'))  return 'mediterranean';
  if (d.includes('high protein'))   return 'highProtein';
  const g = goals?.goal || '';
  if (g === 'muscle')               return 'muscleBuild';
  if (g === 'lose')                 return 'weightLoss';
  if (g === 'athletic')             return 'highProtein';
  return 'balanced';
}

// ─────────────────────────────────────────────────────────────────────
// NUTRITION TARGETS
// ─────────────────────────────────────────────────────────────────────
const CATEGORY_NUTRITION = {
  balanced:      { calories: 1950, protein: 110, carbs: 220, fat: 65 },
  highProtein:   { calories: 2100, protein: 160, carbs: 190, fat: 70 },
  weightLoss:    { calories: 1500, protein: 130, carbs: 120, fat: 55 },
  muscleBuild:   { calories: 2600, protein: 185, carbs: 280, fat: 80 },
  vegan:         { calories: 1850, protein: 80,  carbs: 260, fat: 60 },
  vegetarian:    { calories: 1900, protein: 90,  carbs: 240, fat: 65 },
  keto:          { calories: 1700, protein: 130, carbs: 30,  fat: 130 },
  glutenFree:    { calories: 1900, protein: 110, carbs: 200, fat: 65 },
  pescatarian:   { calories: 1950, protein: 120, carbs: 200, fat: 65 },
  mediterranean: { calories: 1950, protein: 105, carbs: 210, fat: 75 },
};

// ─────────────────────────────────────────────────────────────────────
// GROQ — enrich with real calorie/cost data
// ─────────────────────────────────────────────────────────────────────
async function enrichWithGroq(key, selectedDays, budget, restrictions, goals, seed, familyMembers = [], hasBabies = false) {
  const goalLine = goals?.goal
    ? `Goal: ${goals.goal}, ~${goals.calorieTarget} kcal/day, ${goals.macros?.protein}g protein.`
    : 'Average adult, ~2000 kcal/day, 100g+ protein.';
  const dietLine = restrictions !== 'none'
    ? `Diet restriction: ${restrictions}. All meals must comply.`
    : '';
  const familyLine = familyMembers.length > 0
    ? `Family: ${familyMembers.map(m => `${m.ageGroup || 'Adult'}(${m.age || '?'}yo,${m.activity || 'moderate'},${m.dietary || 'no restriction'})`).join(', ')}.${hasBabies ? ' Include soft/pureed baby-safe foods (no honey, no whole nuts).' : ''}`
    : '';
  const SNACKS = {
    standard:    ['Greek yogurt + berries','Apple + peanut butter','Banana + almond butter','Trail mix (1oz)','Cottage cheese + pineapple','String cheese + grapes','Rice cakes + hummus','Boiled egg + crackers','Dark chocolate (1oz) + almonds','Oatmeal energy ball'],
    vegan:       ['Apple + peanut butter','Banana + almond butter','Roasted chickpeas','Hummus + veggies','Trail mix','Fruit salad','Edamame','Rice cakes + avocado','Dark chocolate + nuts','Dates + almond butter'],
    keto:        ['String cheese','Hard-boiled egg','Celery + almond butter','Cucumber + cream cheese','Pork rinds','Almonds (1oz)','Dark chocolate (85%+, 1oz)','Avocado slices + salt','Pepperoni + cheese','Olives'],
    dessert:     ['Fresh fruit salad','Greek yogurt parfait','Banana ice cream','Chia pudding','Dark chocolate squares','Baked cinnamon apples','Frozen yogurt bark','Rice pudding (light)','Peanut butter banana bites','Coconut milk panna cotta'],
  };
  const snackPool = SNACKS[restrictions === 'keto' ? 'keto' : restrictions === 'vegan' ? 'vegan' : 'standard'];
  const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  const dayList = selectedDays.map((d, i) =>
    `${DAYS[i]}: B="${d.breakfast}" L="${d.lunch}" D="${d.dinner}" S="${d.snack || 'fruit or yogurt or small treat'}"`
  ).join('\n');

  const prompt = `Budget dietitian for a family. Estimate calories, protein(g), carbs(g), fat(g), cost(USD) per meal AND snack/dessert. Budget $${budget}/week. ${goalLine} ${dietLine} ${familyLine} Seed:${seed}.

${dayList}

JSON array of 7 items only:
[{"day":"Monday","totalCalories":0,"totalProtein":0,"totalCarbs":0,"totalFat":0,"breakfast":{"name":"","calories":0,"protein":0,"carbs":0,"fat":0,"cost":0},"lunch":{"name":"","calories":0,"protein":0,"carbs":0,"fat":0,"cost":0},"dinner":{"name":"","calories":0,"protein":0,"carbs":0,"fat":0,"cost":0},"snack":{"name":"","calories":0,"protein":0,"carbs":0,"fat":0,"cost":0}}]`;

  const { data } = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
    model: 'llama-3.1-8b-instant',
    max_tokens: 3500,
    temperature: 0.3,
    messages: [
      { role: 'system', content: 'Output ONLY a valid complete JSON array. No markdown. No explanation. Close all brackets.' },
      { role: 'user', content: prompt },
    ],
  }, {
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    timeout: 40000,
  });

  const text    = data.choices[0].message.content;
  const cleaned = text.replace(/```json\n?/g,'').replace(/```\n?/g,'').trim();
  const match   = cleaned.match(/\[[\s\S]*\]/);
  if (!match) throw new Error('No JSON array in Groq response');
  return JSON.parse(match[0]);
}

// ─────────────────────────────────────────────────────────────────────
// GOOGLE PLACES — nearby grocery stores
// ─────────────────────────────────────────────────────────────────────
async function findNearbyStores(lat, lng) {
  const key = process.env.GOOGLE_MAPS_API_KEY;
  if (!key) return [];
  try {
    const { data } = await axios.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json', {
      params: { location: `${lat},${lng}`, radius: 6000, type: 'grocery_or_supermarket', key },
      timeout: 8000,
    });
    const GROCERY_TYPES = ['grocery_or_supermarket', 'supermarket', 'market', 'food_market'];
    return (data.results || [])
      .filter(p => {
        const types = p.types || [];
        const name = (p.name || '').toLowerCase();
        // Exclude food banks, convenience stores, etc.
        if (name.includes('food bank') || name.includes('pantry') || name.includes('convenience') || name.includes('gas station')) return false;
        return types.some(t => GROCERY_TYPES.includes(t)) || types.includes('grocery_or_supermarket');
      })
      .slice(0, 8)
      .map(p => ({
        name:    p.name,
        address: p.vicinity,
        rating:  p.rating || null,
        lat:     p.geometry.location.lat,
        lng:     p.geometry.location.lng,
        placeId: p.place_id,
        type:    'grocery',
      }));
  } catch (e) {
    console.error('Places API error:', e.message);
    return [];
  }
}

// ─────────────────────────────────────────────────────────────────────
// BUILD SHOPPING LIST — filtered by diet, labeled with nearby stores
// ─────────────────────────────────────────────────────────────────────
function buildShoppingList(filteredIngredients, nearbyStores) {
  const storeNames = nearbyStores.slice(0, 4).map(s => s.name);
  // Use real local stores; only fall back to generics if none found for this location
  const stores     = storeNames.length >= 2 ? storeNames : ['Local Grocery Store','Nearby Market'];

  const list = [];
  let idx = 0;
  const takes = { proteins: 3, carbs: 3, vegetables: 3, fats: 2, pantry: 2 };

  for (const [cat, items] of Object.entries(filteredIngredients)) {
    items.slice(0, takes[cat] || 2).forEach(item => {
      list.push({
        item:          item.name,
        quantity:      item.unit,
        estimatedCost: item.basePrice,
        store:         stores[idx % stores.length],
        category:      cat,
      });
      idx++;
    });
  }
  return list;
}

// ─────────────────────────────────────────────────────────────────────
// MAIN ROUTE
// ─────────────────────────────────────────────────────────────────────
router.post('/generate', async (req, res) => {
  const {
    budget              = 75,
    dietaryRestrictions = [],
    goals               = null,
    lat                 = null,
    lng                 = null,
    seed                = Date.now(),
    familyMembers       = [],
    hasBabies           = false,
    familyPlan          = false,
    locationAddress     = '',
  } = req.body;

  const groqKey      = process.env.GROQ_API_KEY;
  const restrictions = dietaryRestrictions.length > 0 ? dietaryRestrictions.join(', ') : 'none';

  // Derive active blocks for variation B swaps
  const activeBlocks = restrictions === 'none' ? [] :
    restrictions.split(', ').flatMap(r => {
      const rule = Object.values(DIET_RULES).find(d => d.label.toLowerCase() === r.toLowerCase().trim());
      return rule?.blocks || [];
    });

  // Select category and plan
  const category = selectCategory(goals, restrictions);
  const library  = PLAN_LIBRARY[category];

  // Pick 1 of 10 plans + variation A or B using seed
  const planIdx   = seed % 10;
  const variation = (Math.floor(seed / 1000) % 2 === 0) ? 'A' : 'B';

  // Build all 7 days with both variations
  const selectedDays = library.map(p => {
    const varB = buildVarB(p.varA, activeBlocks);
    return variation === 'A' ? p.varA : varB;
  });

  // Filter ingredients by diet
  const filteredIngredients = filterIngredients(restrictions);

  // Nutrition defaults
  const nutrition  = CATEGORY_NUTRITION[category] || CATEGORY_NUTRITION.balanced;
  const dailyCal   = Math.round(goals?.calorieTarget || nutrition.calories);
  const dailyProt  = Math.round(goals?.macros?.protein || nutrition.protein);
  const costPerDay = +(budget / 7).toFixed(2);

  // Run Groq + Places in parallel
  const [nearbyStores, enrichedDays] = await Promise.all([
    (lat && lng) ? findNearbyStores(lat, lng) : Promise.resolve([]),
    groqKey
      ? enrichWithGroq(groqKey, selectedDays, budget, restrictions, goals, seed, familyMembers, hasBabies).catch(e => {
          console.error('Groq error:', e.message);
          return null;
        })
      : Promise.resolve(null),
  ]);

  // Build shopping list with nearby store labels
  const shoppingList = buildShoppingList(filteredIngredients, nearbyStores);
  const subtotal     = +shoppingList.reduce((s, i) => s + i.estimatedCost, 0).toFixed(2);

  // Build final 7 days
  const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  const days = DAYS.map((dayName, i) => {
    const tDay    = selectedDays[i];
    const gDay    = enrichedDays?.[i];
    const perMeal = {
      calories: Math.round(dailyCal / 3),
      protein:  Math.round(dailyProt / 3),
      carbs:    Math.round(nutrition.carbs / 3),
      fat:      Math.round(nutrition.fat / 3),
    };
    return {
      day:           dayName,
      totalCalories: gDay?.totalCalories || dailyCal,
      totalProtein:  gDay?.totalProtein  || dailyProt,
      totalCarbs:    gDay?.totalCarbs    || nutrition.carbs,
      totalFat:      gDay?.totalFat      || nutrition.fat,
      breakfast: {
        name:        gDay?.breakfast?.name || tDay.breakfast,
        calories:    gDay?.breakfast?.calories || perMeal.calories,
        protein:     gDay?.breakfast?.protein  || Math.round(perMeal.protein * 0.8),
        carbs:       gDay?.breakfast?.carbs    || Math.round(perMeal.carbs   * 1.2),
        fat:         gDay?.breakfast?.fat      || Math.round(perMeal.fat     * 0.8),
        cost:        gDay?.breakfast?.cost     || +(costPerDay * 0.28).toFixed(2),
        prepTime:    '5-10 min',
        ingredients: [],
      },
      lunch: {
        name:        gDay?.lunch?.name || tDay.lunch,
        calories:    gDay?.lunch?.calories || perMeal.calories,
        protein:     gDay?.lunch?.protein  || perMeal.protein,
        carbs:       gDay?.lunch?.carbs    || perMeal.carbs,
        fat:         gDay?.lunch?.fat      || perMeal.fat,
        cost:        gDay?.lunch?.cost     || +(costPerDay * 0.30).toFixed(2),
        prepTime:    '5-10 min',
        ingredients: [],
      },
      dinner: {
        name:        gDay?.dinner?.name || tDay.dinner,
        calories:    gDay?.dinner?.calories || perMeal.calories,
        protein:     gDay?.dinner?.protein  || Math.round(perMeal.protein * 1.2),
        carbs:       gDay?.dinner?.carbs    || perMeal.carbs,
        fat:         gDay?.dinner?.fat      || Math.round(perMeal.fat     * 1.2),
        cost:        gDay?.dinner?.cost     || +(costPerDay * 0.38).toFixed(2),
        prepTime:    '15-20 min',
        ingredients: [],
      },
      snack: {
        name:        gDay?.snack?.name || (snackPool ? snackPool[i % snackPool.length] : 'Fruit + nuts'),
        calories:    gDay?.snack?.calories || Math.round(perMeal.calories * 0.35),
        protein:     gDay?.snack?.protein  || Math.round(perMeal.protein  * 0.25),
        carbs:       gDay?.snack?.carbs    || Math.round(perMeal.carbs    * 0.30),
        fat:         gDay?.snack?.fat      || Math.round(perMeal.fat      * 0.25),
        cost:        gDay?.snack?.cost     || +(costPerDay * 0.12).toFixed(2),
        prepTime:    '0-5 min',
        ingredients: [],
      },
    };
  });

  // Tips per category
  const tipMap = {
    vegan:         ['Lentils + rice = complete protein for under $2 a meal','Frozen veg costs half of fresh and has the same nutrients','Bulk oats + peanut butter = cheapest calorie-dense breakfast'],
    keto:          ['Eggs are the best keto protein at ~$0.29 each','Cabbage fills your plate for under $0.50','Buy olive oil in bulk — essential for hitting daily fat goals'],
    muscleBuild:   ['Eat within 30 min of waking — oats + eggs + banana is ideal','Chicken thighs have more protein per dollar than breast','4 eggs + oatmeal = ~40g protein and 600 cal for under $2'],
    weightLoss:    ['Fill half your plate with frozen broccoli — 30 cal, very filling','Cottage cheese is the most satiating cheap protein','Lentil soup: $2 to make, 4 servings, 18g protein per bowl'],
    balanced:      ['Aldi prices are 20-30% below most chains for staples','Buy oats, rice, and lentils in the largest bags available','Batch cook rice + proteins Sunday — saves 30 min every day'],
    highProtein:   ['Greek yogurt has 17g protein per cup — best cheap breakfast','Canned tuna: 25g protein for $1.29 — best protein-per-dollar','Eggs + cottage cheese = 35g protein for under $1.50'],
    vegetarian:    ['Lentils + brown rice = complete protein for $0.60 per serving','Eggs are the most complete cheap protein for vegetarians','Greek yogurt has more protein per gram than most meat'],
    pescatarian:   ['Canned tuna and salmon are the cheapest seafood proteins','Shrimp freezes well — buy bulk when on sale','Fish tacos with corn tortillas + cabbage = $2 meal, 30g protein'],
    glutenFree:    ['Rice + potatoes replace bread cheaply for GF eating','Look for certified GF oats specifically','Corn tortillas are naturally GF and cheaper than GF bread'],
    mediterranean: ['Olive oil is essential — buy extra virgin in bulk','Lentils are the Mediterranean superfood: protein + fiber + iron','Canned tuna and salmon are the affordable Mediterranean proteins'],
  };

  res.json({
    weeklyBudget:           budget,
    estimatedCost:          Math.min(subtotal, budget),
    calorieTarget:          dailyCal,
    totalNutritionScore:    88,
    planName:               category,
    planVariation:          variation,
    planIndex:              planIdx,
    days,
    shoppingList,
    nutritionTips:          tipMap[category] || tipMap.balanced,
    nearbyStores,
    recommendedIngredients: filteredIngredients,
    dietCategory:           category,
  });
});

module.exports = router;
