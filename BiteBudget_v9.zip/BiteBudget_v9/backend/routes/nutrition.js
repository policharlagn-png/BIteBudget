// backend/routes/nutrition.js
// APIs used: USDA FoodData Central, Open Food Facts
const express = require('express');
const axios = require('axios');
const NodeCache = require('node-cache');

const router = express.Router();
const cache = new NodeCache({ stdTTL: 3600 }); // cache 1 hour

// ── GET /api/nutrition/search?q=apples&budget=50 ────────────────────
router.get('/search', async (req, res) => {
  const { q, budget = 50 } = req.query;
  if (!q) return res.status(400).json({ error: 'Search query required' });

  const cacheKey = `nutrition_${q}`;
  if (cache.has(cacheKey)) return res.json(cache.get(cacheKey));

  try {
    const [usdaResults, offResults] = await Promise.allSettled([
      searchUSDA(q),
      searchOpenFoodFacts(q),
    ]);

    let foods = [];
    if (usdaResults.status === 'fulfilled') foods.push(...usdaResults.value);
    if (offResults.status === 'fulfilled') foods.push(...offResults.value);

    // Score each food: nutrition density per estimated dollar
    foods = foods.map(f => ({
      ...f,
      nutritionScore: calcNutritionScore(f),
      valueScore: calcValueScore(f, budget),
    })).sort((a, b) => b.nutritionScore - a.nutritionScore).slice(0, 20);

    const result = { foods, query: q };
    cache.set(cacheKey, result);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Nutrition search failed', details: err.message });
  }
});

// ── GET /api/nutrition/score-store?storeId= ─────────────────────────
router.get('/score-store', async (req, res) => {
  // Returns a nutrition score for a store based on typical inventory
  const { storeType = 'grocery' } = req.query;
  const scores = {
    food_bank: 82, market: 93, snap_retailer: 67,
    grocery: 71, organic: 90, convenience: 35,
  };
  res.json({ score: scores[storeType] || 65 });
});

// ── USDA FoodData Central API ───────────────────────────────────────
async function searchUSDA(query) {
  const key = process.env.USDA_API_KEY;
  if (!key || key === 'your_usda_key_here') return getMockFoods(query);

  const { data } = await axios.get('https://api.nal.usda.gov/fdc/v1/foods/search', {
    params: { query, api_key: key, pageSize: 15, dataType: 'Foundation,SR Legacy' },
    timeout: 8000
  });

  return (data.foods || []).map(f => {
    const nutrients = {};
    (f.foodNutrients || []).forEach(n => {
      if (n.nutrientName.includes('Protein')) nutrients.protein = n.value;
      if (n.nutrientName.includes('Fiber')) nutrients.fiber = n.value;
      if (n.nutrientName.includes('Vitamin C')) nutrients.vitaminC = n.value;
      if (n.nutrientName.includes('Iron')) nutrients.iron = n.value;
      if (n.nutrientName.includes('Energy')) nutrients.calories = n.value;
      if (n.nutrientName.includes('Sugars')) nutrients.sugar = n.value;
    });
    return {
      id: `usda_${f.fdcId}`,
      name: f.description,
      category: f.foodCategory || 'Food',
      nutrients,
      source: 'USDA',
      estimatedPricePerLb: estimatePrice(f.description),
    };
  });
}

// ── Open Food Facts API (Free, no key) ──────────────────────────────
async function searchOpenFoodFacts(query) {
  try {
    const { data } = await axios.get('https://world.openfoodfacts.org/cgi/search.pl', {
      params: {
        search_terms: query, search_simple: 1, action: 'process',
        json: 1, page_size: 10, fields: 'product_name,nutriments,categories,nutriscore_grade'
      },
      timeout: 6000
    });

    return (data.products || [])
      .filter(p => p.product_name && p.nutriments)
      .map(p => ({
        id: `off_${p.id || Math.random()}`,
        name: p.product_name,
        category: p.categories?.split(',')[0] || 'Packaged Food',
        nutriScore: p.nutriscore_grade?.toUpperCase(),
        nutrients: {
          calories: p.nutriments['energy-kcal_100g'],
          protein: p.nutriments.proteins_100g,
          fiber: p.nutriments.fiber_100g,
          sugar: p.nutriments.sugars_100g,
          sodium: p.nutriments.sodium_100g,
        },
        source: 'OpenFoodFacts',
        estimatedPricePerLb: 2.5,
      }));
  } catch {
    return [];
  }
}

// ── Nutrition scoring algorithm ──────────────────────────────────────
function calcNutritionScore(food) {
  const n = food.nutrients || {};
  let score = 50;
  if (n.protein > 5)  score += Math.min(n.protein * 1.5, 20);
  if (n.fiber > 2)    score += Math.min(n.fiber * 2, 15);
  if (n.vitaminC > 10) score += 10;
  if (n.iron > 1)     score += 8;
  if (n.sugar > 20)   score -= Math.min(n.sugar * 0.5, 15);
  if (n.sodium > 500) score -= 10;
  // Bonus for whole foods
  const wholeFoods = ['bean', 'lentil', 'spinach', 'broccoli', 'kale', 'egg', 'oat', 'sweet potato'];
  if (wholeFoods.some(w => food.name?.toLowerCase().includes(w))) score += 10;
  return Math.max(0, Math.min(100, Math.round(score)));
}

function calcValueScore(food, budget) {
  const price = food.estimatedPricePerLb || 3;
  const nutrition = calcNutritionScore(food);
  return Math.round((nutrition / price) * 10);
}

function estimatePrice(name) {
  const lowerName = name.toLowerCase();
  if (lowerName.includes('beef') || lowerName.includes('salmon')) return 7;
  if (lowerName.includes('chicken')) return 4;
  if (lowerName.includes('bean') || lowerName.includes('lentil')) return 1.5;
  if (lowerName.includes('egg')) return 2;
  if (lowerName.includes('spinach') || lowerName.includes('broccoli')) return 2.5;
  return 3;
}

function getMockFoods(query) {
  return [
    { id: 'mock_1', name: 'Black Beans (dry)', category: 'Legumes', source: 'USDA',
      nutrients: { protein: 21, fiber: 15, iron: 5, calories: 341, sugar: 0.3 }, estimatedPricePerLb: 1.2 },
    { id: 'mock_2', name: 'Spinach (raw)', category: 'Vegetables', source: 'USDA',
      nutrients: { protein: 2.9, fiber: 2.2, vitaminC: 28, iron: 2.7, calories: 23, sugar: 0.4 }, estimatedPricePerLb: 2.5 },
    { id: 'mock_3', name: 'Rolled Oats', category: 'Grains', source: 'USDA',
      nutrients: { protein: 13, fiber: 10, iron: 4.7, calories: 389, sugar: 0.9 }, estimatedPricePerLb: 0.9 },
    { id: 'mock_4', name: 'Eggs (whole)', category: 'Protein', source: 'USDA',
      nutrients: { protein: 13, fiber: 0, vitaminC: 0, iron: 1.8, calories: 155, sugar: 0.7 }, estimatedPricePerLb: 2.2 },
    { id: 'mock_5', name: 'Sweet Potato', category: 'Vegetables', source: 'USDA',
      nutrients: { protein: 1.6, fiber: 3, vitaminC: 19, iron: 0.6, calories: 86, sugar: 4.2 }, estimatedPricePerLb: 1.5 },
  ];
}

module.exports = router;
