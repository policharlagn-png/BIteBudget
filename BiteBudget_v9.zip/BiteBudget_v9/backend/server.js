// backend/server.js
require('dotenv').config();
const express   = require('express');
const cors      = require('cors');
const rateLimit = require('express-rate-limit');
const fs        = require('fs');
const path      = require('path');

const app = express();

// ── Middleware ──────────────────────────────────────────────────────
app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200 }));

// ── Routes ──────────────────────────────────────────────────────────
app.use('/api/stores',    require('./routes/stores'));
app.use('/api/nutrition', require('./routes/nutrition'));
app.use('/api/mealplan',  require('./routes/mealplan'));
app.use('/api/transit',   require('./routes/transit'));

// ── Health check ────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => res.json({ status: 'ok', message: 'BiteBudget backend running' }));

// ── Auto-find free port ─────────────────────────────────────────────
function startServer(port) {
  const server = app.listen(port, () => {
    console.log(`\n🍎  BiteBudget backend running at http://localhost:${port}`);
    console.log(`📋  Health check: http://localhost:${port}/api/health\n`);
    // Save port so start.sh can pass it to the frontend
    fs.writeFileSync(path.join(__dirname, '.port'), String(port));
  });
  server.on('error', err => {
    if (err.code === 'EADDRINUSE') {
      console.log(`⚠️  Port ${port} busy — trying ${port + 1}...`);
      startServer(port + 1);
    } else { throw err; }
  });
}

startServer(Number(process.env.PORT) || 3001);
