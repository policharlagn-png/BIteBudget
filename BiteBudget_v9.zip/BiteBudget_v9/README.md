# 🍎 BiteBudget

**Find the most nutritious food you can afford, near you — with AI meal planning.**

---

## ⚡ Quick Start — ONE command

### Step 1 — Install Node.js (one time only)
Download **Node.js LTS** from https://nodejs.org

### Step 2 — Unzip to your Desktop
Unzip `BiteBudget.zip` so you have a `BiteBudget` folder on your Desktop.

### Step 3 — Open Terminal and run

```bash
cd ~/Desktop/BiteBudget
bash start.sh
```

That's it. The script clears any old ports, installs packages, and starts both servers automatically.

Then open **http://localhost:5173** in your browser.

---

## 🛠️ If you prefer to run manually

**Terminal 1 — Backend:**
```bash
cd ~/Desktop/BiteBudget/backend
npm install
npm run dev
```

**Terminal 2 — Frontend:**
```bash
cd ~/Desktop/BiteBudget/frontend
npm install
npm run dev
```

---

## ❓ Troubleshooting

**"Port already in use"** → Run `bash start.sh` instead of starting manually — it clears old ports automatically.

**"Cannot find module"** → Run `npm install` inside both `backend` and `frontend` folders.
