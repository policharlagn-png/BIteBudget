#!/bin/bash
# BiteBudget — one-command startup
# Usage: bash start.sh  (run from inside the BiteBudget folder)

set -e
cd "$(dirname "$0")"

echo ""
echo "  BiteBudget"
echo "================================"

# ── Check Node ──────────────────────────────────────────────────────
if ! command -v node &> /dev/null; then
  echo "ERROR: Node.js not found. Install from nodejs.org"
  exit 1
fi
echo "Node.js $(node -v) found"

# ── Kill anything on our ports ───────────────────────────────────────
echo "Clearing ports 3001 and 5173..."
lsof -ti:3001 | xargs kill -9 2>/dev/null || true
lsof -ti:5173 | xargs kill -9 2>/dev/null || true
sleep 1

# ── Backend ──────────────────────────────────────────────────────────
echo ""
echo "Installing backend packages..."
cd backend
npm install --silent 2>/dev/null

echo "Starting backend..."
# Prefer nodemon if available, fall back to plain node
if ./node_modules/.bin/nodemon --version &>/dev/null 2>&1; then
  node_modules/.bin/nodemon server.js &
else
  node server.js &
fi
BACKEND_PID=$!
cd ..

# ── Wait for backend to actually be ready ────────────────────────────
echo "Waiting for backend to be ready..."
MAX_WAIT=20
COUNT=0
until curl -sf http://localhost:3001/api/health > /dev/null 2>&1; do
  sleep 1
  COUNT=$((COUNT+1))
  if [ $COUNT -ge $MAX_WAIT ]; then
    echo ""
    echo "ERROR: Backend failed to start after ${MAX_WAIT}s."
    echo "Check for errors above. Common causes:"
    echo "  - Port 3001 already in use (close other apps)"
    echo "  - Missing .env file in backend/"
    kill $BACKEND_PID 2>/dev/null || true
    exit 1
  fi
  echo "  ...waiting ($COUNT/${MAX_WAIT})"
done
echo "Backend is up at http://localhost:3001"

# ── Frontend ─────────────────────────────────────────────────────────
echo ""
echo "Installing frontend packages..."
cd frontend
npm install --silent 2>/dev/null

echo ""
echo "================================"
echo "  Open in browser:"
echo "  http://localhost:5173"
echo "================================"
echo ""

npm run dev

# Cleanup on exit
trap "kill $BACKEND_PID 2>/dev/null; exit" EXIT INT TERM
